/* tslint:disable */
/* eslint-disable */

/** How `Account.importKdbx` / `importVault` brings a database in. */
export type ImportMode =
| { kind: "newVault"; name?: string; orgId?: string }
| { kind: "merge"; vaultId: string }
| { kind: "copies"; vaultId: string };
export interface ImportOutcome { vault: Vault; uploaded: boolean; uploadError?: OvError; report?: SyncReport }
/** Who `Account.shareVault` grants to. */
export type Grantee = { kind: "email"; email: string } | { kind: "principal"; principal: Principal };
/** `keep` leaves the expiry as it is, `never` clears it. */
export type ExpiryChange = { kind: "keep" } | { kind: "never" } | { kind: "at"; at: Rfc3339 };
/** Entry expiry edit; `at` is Unix seconds. */
export type EntryExpiry = { kind: "keep" } | { kind: "never" } | { kind: "at"; at: number };
export type LoginStep = { kind: "needsTotp"; challenge: TotpChallenge } | { kind: "unlocked"; unlocked: Unlocked };
export interface Unlocked { auk: Uint8Array; offline: boolean; deletionScheduledFor?: Rfc3339 }
export interface RegisterInput { email: string; password: Uint8Array; kdf?: KdfOverrides; trustDevice: boolean }
export interface LoginInput { email: string; password: Uint8Array; secretKey?: Uint8Array; totp?: string; trustDevice: boolean }
export type AccountEvent =
| { kind: "vaultChanged"; vaultId: string; etag?: string; revision?: number; deleted: boolean }
| { kind: "vaultsChanged"; vaults: VaultInfo[] }
| { kind: "sessionEnded"; reason: SignedOutReason; at?: Rfc3339 }
| { kind: "databaseChanged"; databaseId: string; etag?: string; revision?: number; deleted: boolean };



/** Why a request failed without a response; `fetchTransport` rejects with these. */
export interface TransportFailure { kind: "offline" | "timeout" | "tls" | "cancelled" | "other"; message?: string }
/** An open server-sent events body. */
export interface ByteStream { readonly status: number; nextChunk(): Promise<Uint8Array | null | undefined>; close(): void }
/** HTTP. Must not follow redirects, add cookies or log header values. Rejects with a `TransportFailure` (or a `TypeError` = offline, `AbortError` = cancelled). */
export interface HttpTransport { send(req: HttpRequest): Promise<HttpResponse>; openStream(req: HttpRequest): Promise<ByteStream> }
/** Small persistent secrets (sessions, Secret Keys). Keys are short ASCII strings. */
export interface SecureStore { get(key: string): Promise<Uint8Array | null | undefined>; set(key: string, value: Uint8Array): Promise<void>; delete(key: string): Promise<void> }
/** The offline cache (SPEC §20), keyed by user and vault. Everything in it is ciphertext or public. */
export interface BlobCache {
    load(userId: string, vaultId: string): Promise<CachedVault | null | undefined>;
    save(userId: string, vaultId: string, v: CachedVault): Promise<void>;
    remove(userId: string, vaultId: string): Promise<void>;
    list(userId: string): Promise<string[]>;
    loadMeta(userId: string, name: string): Promise<Uint8Array | null | undefined>;
    saveMeta(userId: string, name: string, value: Uint8Array): Promise<void>;
    clearUser(userId: string): Promise<void>;
}
export interface Clock { nowUnixMs(): number }
export interface LogSink { log(level: LogLevel, target: string, msg: string): void }
/** The platform services the core runs on. */
export interface Host { http: HttpTransport; store: SecureStore; cache: BlobCache; clock: Clock; log: LogSink }


export interface AppleEligibility {
    eligible: boolean;
    reason?: string;
}


export interface AppleTransactionResult {
    subject: string;
    plan: Plan;
}


export interface AttachmentInfo {
    name: string;
    size: number;
}


export interface AuditEvent {
    id: string;
    at: Rfc3339;
    actor: Principal;
    action: string;
    target?: string;
    ip?: string;
    details?: string;
}


export interface AuditPage {
    events: AuditEvent[];
    next?: string;
}


export interface AutoFillEdit {
    entry: EntryRecord;
    groupPath: string;
}


export interface AutoFillEdits {
    vaultId: string;
    entries: AutoFillEdit[];
    version: string;
}


export interface Billing {
    source: string;
    interval: string;
    status: string;
    renewsAt?: Rfc3339;
    endsAt?: Rfc3339;
    manage: string;
}


export interface BlobMeta {
    id: string;
    etag: string;
    revision: number;
    size: number;
    updatedAt: Rfc3339;
}


export interface CachedVault {
    state: Uint8Array;
    base?: Uint8Array;
    pending?: Uint8Array;
    autofill?: Uint8Array;
}


export interface ClientConfig {
    device: DeviceInfo;
    offline: boolean;
    server?: ServerConfig;
}


export interface CreatedServiceAccount {
    serviceAccount: ServiceAccountInfo;
    token: Uint8Array;
}


export interface CreatedShare {
    id: string;
    url: Uint8Array;
    expiresAt: Rfc3339;
}


export interface DeletionCandidate {
    id: string;
    email: string;
    role: OrgRole;
}


export interface DeletionOrg {
    id: string;
    name: string;
    role: OrgRole;
    outcome: DeletionOutcome;
    members: DeletionCandidate[];
}


export interface DeletionPreview {
    scheduledFor?: Rfc3339;
    eraseOn: Rfc3339;
    vaults: DeletionVault[];
    orgs: DeletionOrg[];
    subscription?: DeletionSubscription;
    shareLinks: number;
    blocked: boolean;
}


export interface DeletionShare {
    principal: Principal;
    display?: string;
    role: VaultRole;
}


export interface DeletionSubscription {
    plan: string;
    periodEnd?: Rfc3339;
    source: string;
    manage: string;
}


export interface DeletionVault {
    id: string;
    name?: string;
    sharedWith: DeletionShare[];
}


export interface Device {
    id: string;
    name: string;
    platform: string;
    createdAt: Rfc3339;
    lastSeenAt: Rfc3339;
    current: boolean;
}


export interface DeviceInfo {
    id?: string;
    name: string;
    platform: Platform;
}


export interface EmergencyKit {
    email: string;
    issuer: string;
    web?: string;
}


export interface EntryInput {
    fields: FieldInput[];
    removeFields: string[];
    tags?: string[];
    iconId?: number;
    expiry: EntryExpiry;
}


export interface EntryRecord {
    id: string;
    groupId: string;
    groupPath: string[];
    fields: FieldRecord[];
    tags: string[];
    iconId: number;
    customIcon?: string;
    foregroundColor: string;
    backgroundColor: string;
    overrideUrl: string;
    createdAt: number;
    modifiedAt: number;
    expiresAt?: number;
    attachments: AttachmentInfo[];
    historyCount: number;
    qualityCheck: boolean;
}


export interface EntrySummary {
    id: string;
    groupId: string;
    groupPath: string[];
    title: string;
    username: string;
    url: string;
    tags: string[];
    protectedFields: string[];
    iconId: number;
    customIcon?: string;
    modifiedAt: number;
    expiresAt?: number;
    inRecycleBin: boolean;
}


export interface FieldInput {
    name: string;
    value: Uint8Array;
    protected?: boolean;
}


export interface FieldRecord {
    name: string;
    value: Uint8Array;
    protected: boolean;
}


export interface GrantResult {
    principal: Principal;
    fingerprint: string;
}


export interface GroupInfo {
    id: string;
    name: string;
    parentId?: string;
    path: string[];
    iconId: number;
    notes: string;
    isRecycleBin: boolean;
    entryCount: number;
}


export interface HttpRequest {
    method: HttpMethod;
    url: string;
    headers: [string, string][];
    body?: Uint8Array;
    keepalive: boolean;
}


export interface HttpResponse {
    status: number;
    headers: [string, string][];
    body: Uint8Array;
}


export interface Injected {
    text: Uint8Array;
    secrets: Uint8Array[];
}


export interface Invitation {
    id: string;
    email: string;
    role: OrgRole;
    expiresAt: Rfc3339;
    invitedBy: Principal;
}


export interface IssuedSecret {
    token: Uint8Array;
    id: string;
    prefix: string;
}


export interface KdbxCredentials {
    password?: Uint8Array;
    keyFile?: Uint8Array;
}


export interface KdfMin {
    m: number;
    t: number;
}


export interface KdfOverrides {
    m?: number;
    t?: number;
    p?: number;
}


export interface KdfParams {
    alg: string;
    salt: string;
    m: number;
    t: number;
    p: number;
}


export interface Member {
    userId: string;
    email: string;
    name?: string;
    role: OrgRole;
    status: MemberStatus;
    publicKeys?: PublicKeys;
}


export interface MergeChange {
    change: ChangeType;
    uuid?: string;
    title?: string;
    group?: string;
    details: string;
}


export interface NewAccount {
    userId: string;
    secretKey: Uint8Array;
    emergencyKit: EmergencyKit;
    auk: Uint8Array;
}


export interface NewServiceAccount {
    name: string;
    vaults: VaultGrantRequest[];
    expiresAt?: Rfc3339;
    secretName?: string;
}


export interface OpaqueConfig {
    lib: string;
    version: string;
    context: string;
    ids: string;
}


export interface OpenedShare {
    payload: SharePayload;
    opensLeft?: number;
}


export interface Org {
    id: string;
    name: string;
    role: OrgRole;
    plan?: Plan;
    itemShareLinks?: ShareLinkPolicy;
    createdAt: Rfc3339;
}


export interface OrgMembership {
    id: string;
    name: string;
    role: OrgRole;
    status: MemberStatus;
    plan?: Plan;
    itemShareLinks?: ShareLinkPolicy;
}


export interface PairingCode {
    code: string;
    expiresAt: Rfc3339;
}


export interface Plan {
    id?: string;
    limits: PlanLimit[];
    billing?: Billing;
}


export interface PlanLimit {
    name: string;
    value?: number;
}


export interface Profile {
    id: string;
    email: string;
    name?: string;
    totpEnabled: boolean;
    plan?: Plan;
    orgs: OrgMembership[];
    deletionScheduledFor?: Rfc3339;
}


export interface PublicKeys {
    encPk: Uint8Array;
    signPk: Uint8Array;
    sig: Uint8Array;
    fingerprint: string;
}


export interface ReconnectResult {
    vaults: VaultInfo[];
    dropped: string[];
}


export interface RecoveryReset {
    email: string;
    notBefore: Rfc3339;
    expiresAt: Rfc3339;
    archiveDays: number;
    personalVaults: number;
    sharedGrants: number;
    soleAdminOrgs: string[];
}


export interface RecoveryStatus {
    archived: boolean;
    email?: string;
    expiresAt?: Rfc3339;
    vaults?: number;
    locked: boolean;
}


export interface RememberedAccount {
    email: string;
    issuer: string;
    userId: string;
    lastUsedAt: Rfc3339;
    checkedAt?: Rfc3339;
    deletionScheduledFor?: Rfc3339;
}


export interface RotationFailure {
    vaultId: string;
    error: OvError;
}


export interface RotationReport {
    rotated: string[];
    failed: RotationFailure[];
}


export interface SaSecretInfo {
    id: string;
    prefix: string;
    name?: string;
    createdAt: Rfc3339;
    lastUsedAt?: Rfc3339;
    expiresAt?: Rfc3339;
}


export interface SaVault {
    id: string;
    name: string;
    role: VaultRole;
}


export interface SelfHostedSyncResult {
    kdbx: Uint8Array;
    report: SyncReport;
}


export interface ServerConfig {
    issuer: string;
    api: string;
    sync: string;
    jwksUri: string;
    opaque: OpaqueConfig;
    kdfMin?: KdfMin;
    web?: string;
    share?: string;
}


export interface ServiceAccountInfo {
    id: string;
    orgId: string;
    name: string;
    publicKeys?: PublicKeys;
    createdBy?: Principal;
    createdAt?: Rfc3339;
    expiresAt?: Rfc3339;
    disabled: boolean;
}


export interface ServiceAccountUpdate {
    name?: string;
    expiresAt: ExpiryChange;
    disabled?: boolean;
}


export interface SetFieldsResult {
    entry: EntryRecord;
    created: boolean;
}


export interface ShareField {
    k: string;
    label: string;
    value: Uint8Array;
    protected: boolean;
}


export interface ShareInfo {
    expiresAt: Rfc3339;
    opensLeft?: number;
    kdf?: KdfParams;
}


export interface ShareListing {
    id: string;
    vaultId?: string;
    reference?: ShareRef;
    passcode: boolean;
    maxOpens?: number;
    opens: number;
    openedAt: Rfc3339[];
    createdAt: Rfc3339;
    expiresAt: Rfc3339;
    status: string;
    endedAt?: Rfc3339;
    endReason?: string;
}


export interface ShareOptions {
    expiresIn: number;
    maxOpens?: number;
    passcode?: Uint8Array;
    vaultId?: string;
    entryId?: string;
}


export interface SharePayload {
    v: number;
    kind: string;
    title?: string;
    sharedBy?: string;
    fields: ShareField[];
}


export interface ShareRecipient {
    principal: Principal;
    email?: string;
    name?: string;
    publicKeys: PublicKeys;
}


export interface ShareRef {
    vault?: string;
    entry?: string;
    title: string;
}


export interface ShareableField {
    name: string;
    kind: string;
    label: string;
    value: Uint8Array;
    protected: boolean;
}


export interface StoredSession {
    issuer: string;
    userId: string;
    email: string;
    deviceId: string;
}


export interface SyncConflict {
    uuid: string;
    kind: ConflictKind;
    title: string;
    fields: string[];
}


export interface SyncOptions {
    localChanged: boolean;
}


export interface SyncReport {
    outcome: SyncOutcome;
    conflicts: SyncConflict[];
    changes: MergeChange[];
    attempts: number;
    etag?: string;
    clockOffsetMs?: number;
    clockSkewed: boolean;
}


export interface TotpCode {
    code: Uint8Array;
    remaining: number;
}


export interface TotpParams {
    secret: Uint8Array;
    digits: number;
    period: number;
    algorithm: TotpAlgorithm;
    encoder?: string;
}


export interface TotpSetup {
    secret: Uint8Array;
    uri: Uint8Array;
}


export interface VaultGrantRequest {
    vaultId: string;
    role: VaultRole;
}


export interface VaultInfo {
    id: string;
    name: string;
    role: VaultRole;
    orgId?: string;
    currentKeyVersion: number;
    pendingKeyVersion?: number;
    rotationRequired: boolean;
}


export interface VaultMember {
    principal: Principal;
    role: VaultRole;
    display: string;
    keyVersion: number;
    isYou: boolean;
}


export interface VaultVersion {
    revision: number;
    etag: string;
    size?: number;
    savedAt?: Rfc3339;
    isCurrent: boolean;
}


export type ChangeType = "added" | "modified" | "moved" | "deleted" | "metadata";


export type ConflictKind = "edited-on-both" | "deleted-here-edited-there" | "edited-here-deleted-there";


export type CreateMode = "must_exist" | "create_if_missing" | "create_only";


export type DeletionOutcome = "leave" | "delete" | "blocked";


export type ExportFormat = "csv" | "json";


export type HttpMethod = "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";


export type LogLevel = "error" | "warn" | "info" | "debug" | "trace";


export type MemberStatus = "invited" | "accepted" | "confirmed";


export type OrgRole = "owner" | "admin" | "member";


export type ParkedCheck = "valid" | "ended" | "no_answer";


export type Platform = "qt-linux" | "qt-macos" | "qt-windows" | "web" | "cli" | "connect" | "ios";


export type SessionState = "active" | "parked" | "signed_out";


export type ShareLinkPolicy = "on" | "managers" | "off";


export type SignedOutReason = "token_reused" | "session_expired" | "unauthorized" | "logout" | "deletion_scheduled" | "account_deleted";


export type SyncOutcome = "unchanged" | "pulled" | "uploaded" | "created";


export type TotpAlgorithm = "SHA1" | "SHA256" | "SHA512";


export type VaultRole = "read" | "write" | "manage";


export type VersionDifference = "same" | "changed" | "deleted";


import type { OvError } from "../index.js";
/** Server times: RFC 3339 strings. KDBX times: Unix seconds. Secrets: Uint8Array (UTF-8 for text); wipe them when done. */
export type Rfc3339 = string;
/** `user:<id>`, `sa:<id>`. */
export type Principal = string;



/**
 * An account on one server: signed out, signed in but locked, or unlocked.
 */
export class Account {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * r" Accepts an invitation.
     */
    acceptInvitation(token: Uint8Array | number[], signal?: any | null): Promise<Member>;
    /**
     * r" Whether In-App Purchase is possible.
     */
    appleEligibility(org_id?: string | null, signal?: any | null): Promise<AppleEligibility>;
    /**
     * r" One page of an org's audit log.
     */
    auditLog(org_id: string, before?: string | null, limit?: number | null, signal?: any | null): Promise<AuditPage>;
    /**
     * r" What AutoFill saved for a vault and the app hasn't taken yet.
     */
    autofillEdits(vault_id: string): Promise<AutoFillEdits | undefined>;
    /**
     * r" The KDF parameters cached at the last sign-in or unlock.
     */
    cachedKdf(): Promise<KdfParams | undefined>;
    /**
     * r" The vault list from the last successful call, without the network.
     */
    cachedVaults(): Promise<VaultInfo[] | undefined>;
    /**
     * r" Cancels an invitation.
     */
    cancelInvitation(org_id: string, invitation_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Changes the email with the code that was sent.
     */
    changeEmail(email: string, code: string, password: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * Changes the master password; returns the new AUK.
     */
    changePassword(current: Uint8Array | number[], next: Uint8Array | number[], kdf: KdfOverrides | undefined, signal?: any | null): Promise<Uint8Array>;
    /**
     * Changes a member's role on a vault.
     */
    changeRole(vault_id: string, principal: string, role: VaultRole, signal?: any | null): Promise<void>;
    /**
     * r" Asks the server about a parked session.
     */
    checkParkedSession(user_id: string, signal?: any | null): Promise<ParkedCheck>;
    /**
     * Removes AutoFill edits once taken.
     */
    clearAutofillEdits(edits: AutoFillEdits): Promise<void>;
    /**
     * How far this device's clock is ahead of the sync server's (ms).
     */
    clockOffsetMs(): number | undefined;
    /**
     * Confirms an accepted member and grants vaults.
     */
    confirmMember(org_id: string, member: Member, vaults: VaultGrantRequest[], signal?: any | null): Promise<Member>;
    /**
     * r" Confirms two-step setup with a code.
     */
    confirmTwoStep(code: string, signal?: any | null): Promise<void>;
    /**
     * r" Creates an org.
     */
    createOrg(name: string, signal?: any | null): Promise<Org>;
    /**
     * Creates a service account (SPEC §9).
     */
    createServiceAccount(org_id: string, input: NewServiceAccount, signal?: any | null): Promise<CreatedServiceAccount>;
    /**
     * Creates a share link (SPEC §22).
     */
    createShare(payload: SharePayload, options: ShareOptions, signal?: any | null): Promise<CreatedShare>;
    /**
     * r" Creates a vault (SPEC §7, §13).
     */
    createVault(name: string, org_id?: string | null, signal?: any | null): Promise<Vault>;
    /**
     * r" Schedules the account's deletion; returns the erase date.
     */
    deleteAccount(password: Uint8Array | number[], confirm: string, signal?: any | null): Promise<Rfc3339>;
    /**
     * r" Deletes an org.
     */
    deleteOrg(org_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Deletes a service account.
     */
    deleteServiceAccount(sa_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Deletes a vault for everyone (needs `manage`).
     */
    deleteVault(vault_id: string, signal?: any | null): Promise<void>;
    /**
     * r" What deleting the account would do (SPEC §23).
     */
    deletionPreview(signal?: any | null): Promise<DeletionPreview>;
    /**
     * The erase date while the account is pending deletion (SPEC §23).
     */
    deletionScheduledFor(): string | undefined;
    /**
     * r" Signed-in devices.
     */
    devices(signal?: any | null): Promise<Device[]>;
    /**
     * r" Turns two-step sign-in off.
     */
    disableTwoStep(code: string, signal?: any | null): Promise<void>;
    /**
     * The signed-in email.
     */
    email(): string | undefined;
    /**
     * This account's public-key fingerprint (SPEC §5).
     */
    fingerprint(): string;
    /**
     * r" Removes the kept Secret Key and device id for `email`.
     */
    forgetDevice(email: string): Promise<void>;
    /**
     * r" Whether any vault has edits waiting on this device.
     */
    hasAnyPendingEdits(): Promise<boolean>;
    /**
     * r" Whether a vault has edits waiting on this device.
     */
    hasPendingEdits(vault_id: string): Promise<boolean>;
    /**
     * r" Whether this device keeps the Secret Key for `email`.
     */
    hasSecretKey(email: string): Promise<boolean>;
    /**
     * Imports a `.kdbx` into the account (new vault, merge or copies).
     */
    importKdbx(kdbx: Uint8Array | number[], credentials: KdbxCredentials, mode: ImportMode, signal?: any | null): Promise<ImportOutcome>;
    /**
     * Imports an already open vault.
     */
    importVault(source: Vault, mode: ImportMode, signal?: any | null): Promise<ImportOutcome>;
    /**
     * r" An org's open invitations.
     */
    invitations(org_id: string, signal?: any | null): Promise<Invitation[]>;
    /**
     * Invites an email to an org.
     */
    invite(org_id: string, email: string, role: OrgRole, signal?: any | null): Promise<Invitation>;
    /**
     * Working from the offline cache (SPEC §20).
     */
    isOffline(): boolean;
    /**
     * A session is loaded (it may be locked).
     */
    isSignedIn(): boolean;
    /**
     * The keyset is in memory.
     */
    isUnlocked(): boolean;
    /**
     * r" Issues a new secret for a service account.
     */
    issueServiceAccountSecret(sa_id: string, name?: string | null, expires_at?: string | null, signal?: any | null): Promise<IssuedSecret>;
    /**
     * Keeps an entry the AutoFill extension saved, for the app to merge later.
     */
    keepAutofillEdit(vault_id: string, entry: EntryRecord, group_path: string): Promise<void>;
    /**
     * r" Your share links.
     */
    listShares(signal?: any | null): Promise<ShareListing[]>;
    /**
     * Clears the keyset and vault keys from memory. The session stays.
     */
    lock(): void;
    /**
     * OPAQUE sign-in (SPEC §8), then unlock.
     */
    login(input: LoginInput, signal?: any | null): Promise<LoginStep>;
    /**
     * r" Looks a user up by email for sharing.
     */
    lookUp(email: string, signal?: any | null): Promise<ShareRecipient>;
    /**
     * r" The org's vaults an admin manages.
     */
    managedOrgVaults(org_id: string, signal?: any | null): Promise<VaultInfo[]>;
    /**
     * r" `GET /me` (SPEC §16).
     */
    me(signal?: any | null): Promise<Profile>;
    /**
     * r" A vault's members.
     */
    members(vault_id: string, signal?: any | null): Promise<VaultMember[]>;
    /**
     * r" Opens this device's copy of a vault, without AutoFill's edits.
     */
    openCopy(vault_id: string): Promise<Vault>;
    /**
     * r" Opens a vault from this device's copies only, plus AutoFill's edits.
     */
    openOffline(vault_id: string): Promise<Vault>;
    /**
     * Opens one saved version, read-only. `revision` is an integer.
     */
    openVaultVersion(vault_id: string, revision: number, signal?: any | null): Promise<Vault>;
    /**
     * r" Downloads and opens a vault.
     */
    openVault(vault_id: string, signal?: any | null): Promise<Vault>;
    /**
     * r" An org's members.
     */
    orgMembers(org_id: string, signal?: any | null): Promise<Member[]>;
    /**
     * r" One org.
     */
    org(org_id: string, signal?: any | null): Promise<Org>;
    /**
     * r" The orgs this account belongs to (SPEC §12).
     */
    orgs(signal?: any | null): Promise<OrgMembership[]>;
    /**
     * r" Locks and sets this session aside (SPEC §21).
     */
    parkSession(): Promise<boolean>;
    /**
     * r" The account's plan (SPEC §19).
     */
    plan(signal?: any | null): Promise<Plan | undefined>;
    /**
     * `user:<id>`; `signed_out` without a session.
     */
    principal(): Principal;
    /**
     * r" A known principal as a share recipient.
     */
    recipient(principal: string, display?: string | null, signal?: any | null): Promise<ShareRecipient>;
    /**
     * r" Goes back online after working offline.
     */
    reconnect(signal?: any | null): Promise<ReconnectResult>;
    /**
     * r" What a recovery link resets (SPEC §18).
     */
    recoverInfo(token: Uint8Array | number[], signal?: any | null): Promise<RecoveryReset>;
    /**
     * Resets the account from a recovery link (SPEC §18).
     */
    recover(token: Uint8Array | number[], password: Uint8Array | number[], kdf: KdfOverrides | undefined, trust_device: boolean, signal?: any | null): Promise<NewAccount>;
    /**
     * r" Whether an archive from a reset can be restored.
     */
    recoveryStatus(signal?: any | null): Promise<RecoveryStatus>;
    /**
     * Creates an account (SPEC §2, §3, §5, §8). Show the returned Secret Key once.
     */
    register(input: RegisterInput, signal?: any | null): Promise<NewAccount>;
    /**
     * r" Removes a member (rotating the vaults they could open).
     */
    removeMember(org_id: string, user_id: string, signal?: any | null): Promise<RotationReport>;
    /**
     * r" Renames an org.
     */
    renameOrg(org_id: string, name: string, signal?: any | null): Promise<Org>;
    /**
     * r" Renames a vault (needs `manage`).
     */
    renameVault(vault_id: string, name: string, signal?: any | null): Promise<VaultInfo>;
    /**
     * r" Reports an App Store transaction.
     */
    reportAppleTransaction(jws: string, signal?: any | null): Promise<AppleTransactionResult>;
    /**
     * r" Sends a code to a new email address.
     */
    requestEmailChange(email: string, signal?: any | null): Promise<void>;
    /**
     * r" Cancels a scheduled deletion.
     */
    restoreAccount(password: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * r" Restores vaults from the archive with the old credentials.
     */
    restoreFromArchive(old_password: Uint8Array | number[], old_secret_key: Uint8Array | number[], signal?: any | null): Promise<number>;
    /**
     * r" Makes a parked session the active one.
     */
    resumeSession(user_id: string): Promise<boolean>;
    /**
     * r" Unlocks from keyset secrets saved by `unlockedKeysetSecret`.
     */
    resumeUnlocked(keyset_secret: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * r" Signs a device out.
     */
    revokeDevice(device_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Revokes a service-account secret.
     */
    revokeSecret(sa_id: string, secret_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Ends a share link.
     */
    revokeShare(share_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Revokes members from a vault (rotating its key).
     */
    revoke(vault_id: string, principals: string[], signal?: any | null): Promise<SyncReport>;
    /**
     * r" Rotates every vault flagged for rotation.
     */
    rotateFlagged(org_id: string, signal?: any | null): Promise<RotationReport>;
    /**
     * r" Rotates a vault's key, optionally removing principals.
     */
    rotateVaultKey(vault_id: string, remove: string[], signal?: any | null): Promise<SyncReport>;
    /**
     * r" The Secret Key, to show again in settings.
     */
    secretKey(): Promise<Uint8Array | undefined>;
    /**
     * The server's discovery document.
     */
    serverConfig(): ServerConfig;
    /**
     * r" A service account's secrets.
     */
    serviceAccountSecrets(sa_id: string, signal?: any | null): Promise<SaSecretInfo[]>;
    /**
     * r" An org's service accounts.
     */
    serviceAccounts(org_id: string, signal?: any | null): Promise<ServiceAccountInfo[]>;
    /**
     * Promotes or demotes a member.
     */
    setMemberRole(org_id: string, member: Member, role: OrgRole, signal?: any | null): Promise<Member>;
    /**
     * Sets an org's item share-link policy.
     */
    setOrgShareLinks(org_id: string, policy: ShareLinkPolicy, signal?: any | null): Promise<Org>;
    /**
     * Changes a service-account secret's expiry.
     */
    setSecretExpiry(sa_id: string, secret_id: string, expires_at: ExpiryChange, signal?: any | null): Promise<SaSecretInfo>;
    /**
     * The share page's base URL, if the server has one.
     */
    shareBase(): string | undefined;
    /**
     * r" Why share links are blocked for an org (or personal vaults), if they are.
     */
    shareBlockedReason(org_id?: string | null): Promise<string | undefined>;
    /**
     * Shares a vault with a user (SPEC §7).
     */
    shareVault(vault_id: string, grantee: Grantee, role: VaultRole, signal?: any | null): Promise<GrantResult>;
    /**
     * For a page closing on a shared session: locks and returns the logout request to fire.
     */
    signOutOnUnload(): HttpRequest | undefined;
    /**
     * r" Signs a parked session out.
     */
    signOutParked(user_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Signs this device out (and with `forgetDevice` drops the kept Secret Key).
     */
    signOut(forget_device: boolean, signal?: any | null): Promise<void>;
    /**
     * r" Completes the next time the server ends this session. Await it in a loop.
     */
    signedOut(signal?: any | null): Promise<SignedOutReason>;
    /**
     * r" Starts two-step sign-in setup (SPEC §8).
     */
    startTwoStep(signal?: any | null): Promise<TotpSetup>;
    /**
     * r" The Secret Key this device keeps for `email`.
     */
    storedSecretKey(email: string): Promise<Uint8Array | undefined>;
    /**
     * r" The stored session (without tokens).
     */
    storedSession(): Promise<StoredSession | undefined>;
    /**
     * Sends a TOTP code for a waiting sign-in.
     */
    submitTotp(challenge: TotpChallenge, code: string, signal?: any | null): Promise<LoginStep>;
    /**
     * r" Live updates (SPEC §11).
     */
    subscribe(signal?: any | null): Promise<EventStream>;
    /**
     * r" Hands a vault to another member before deletion.
     */
    transferVault(vault_id: string, to: string, signal?: any | null): Promise<void>;
    /**
     * r" Unlocks with an AUK kept behind biometrics.
     */
    unlockWithAuk(auk: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * r" Unlocks a signed-in session with the master password (offline: from the cache).
     */
    unlock(password: Uint8Array | number[], secret_key?: Uint8Array | number[] | null, signal?: any | null): Promise<Unlocked>;
    /**
     * The unlocked keyset's private halves (64 bytes), for the web's `sealUnlocked`.
     */
    unlockedKeysetSecret(): Uint8Array;
    /**
     * Updates a service account.
     */
    updateServiceAccount(sa_id: string, update: ServiceAccountUpdate, signal?: any | null): Promise<ServiceAccountInfo>;
    /**
     * The upgrade page for a `plan_limit` / `quota_exceeded` error.
     */
    upgradeUrl(error: OvError): string | undefined;
    /**
     * The signed-in user's id.
     */
    userId(): string | undefined;
    /**
     * r" The saved versions of a vault, newest first.
     */
    vaultHistory(vault_id: string, signal?: any | null): Promise<VaultVersion[]>;
    /**
     * r" A vault's storage quota in bytes.
     */
    vaultQuota(vault_id: string): Promise<number | undefined>;
    /**
     * r" Every vault this account can open (SPEC §7).
     */
    vaults(signal?: any | null): Promise<VaultInfo[]>;
    /**
     * r" A principal's public keys, verified.
     */
    verifiedPublicKeys(principal: string, signal?: any | null): Promise<PublicKeys>;
    /**
     * r" Asks the server whether this device's session still stands.
     */
    verifySession(signal?: any | null): Promise<void>;
    /**
     * r" A one-time URL that signs the web app in.
     */
    webSessionUrl(next?: string | null, signal?: any | null): Promise<Uint8Array>;
}

/**
 * Live updates: `await next()` in a loop until it resolves `undefined`.
 */
export class EventStream {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Closes the stream.
     */
    close(): void;
    /**
     * The next event, or `undefined` once closed.
     */
    next(signal?: any | null): Promise<AccountEvent | undefined>;
    /**
     * Reconnects now (e.g. after the page comes back online).
     */
    reconnect(): void;
}

/**
 * The entry point: one per app (or per test). `new OvClient(config, host)`.
 */
export class OvClient {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The settings this client was made with.
     */
    config(): ClientConfig;
    /**
     * Discovers the server and loads a stored session (signed in but locked).
     */
    connect(issuer: string, signal?: any | null): Promise<Account>;
    /**
     * Fetches and checks the discovery document (SPEC §10).
     */
    discover(issuer: string, signal?: any | null): Promise<ServerConfig>;
    /**
     * Removes an account from the remembered list.
     */
    forgetRemembered(issuer: string, user_id: string): Promise<void>;
    /**
     * Whether a user's offline cache holds edits not yet uploaded.
     */
    hasPendingEdits(user_id: string): Promise<boolean>;
    /**
     * Records that the server confirmed the account's parked session now.
     */
    markRememberedChecked(issuer: string, user_id: string): Promise<void>;
    /**
     * A client over `host` (see `host/` in the package for ready-made adapters). Does no I/O.
     */
    constructor(config: ClientConfig, host: Host);
    /**
     * Opens a share link (SPEC §22).
     */
    openShare(api: string, link: Uint8Array | number[], passcode: Uint8Array | number[] | null | undefined, info: ShareInfo | undefined, signal?: any | null): Promise<OpenedShare>;
    /**
     * Adds or refreshes a remembered account.
     */
    rememberAccount(email: string, issuer: string, user_id: string): Promise<void>;
    /**
     * Remembered accounts, most recently used first (SPEC §21).
     */
    rememberedAccounts(): Promise<RememberedAccount[]>;
    /**
     * Active, parked or no session for a user on this device (no network).
     */
    sessionState(issuer: string, user_id: string): Promise<SessionState>;
    /**
     * Records (or clears) a remembered account's erase date (SPEC §23).
     */
    setRememberedDeletion(issuer: string, user_id: string, at?: string | null): Promise<void>;
    /**
     * What the public share page knows before opening a share (SPEC §22).
     */
    shareInfo(api: string, share_id: string, signal?: any | null): Promise<ShareInfo>;
}

/**
 * A self-hosted sync server (SPEC §13).
 */
export class SelfHosted {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Connects with a device token.
     */
    static connect(client: OvClient, server_url: string, device_token: Uint8Array | number[]): SelfHosted;
    /**
     * A code to pair another device.
     */
    createPairingCode(signal?: any | null): Promise<PairingCode>;
    /**
     * Live updates from the server.
     */
    events(signal?: any | null): Promise<EventStream>;
    /**
     * The server's health text.
     */
    health(signal?: any | null): Promise<string>;
    /**
     * The databases on the server.
     */
    listDatabases(signal?: any | null): Promise<BlobMeta[]>;
    /**
     * Pairs this device with a pairing code.
     */
    static pair(client: OvClient, server_url: string, code: string, device_name: string, signal?: any | null): Promise<SelfHosted>;
    /**
     * Reconnects with the device token kept in the secure store.
     */
    static restore(client: OvClient, server_url: string): Promise<SelfHosted | undefined>;
    /**
     * The server URL.
     */
    serverUrl(): string;
    /**
     * Syncs a local `.kdbx` with the server's copy.
     */
    syncDatabase(database_id: string, kdbx: Uint8Array | number[], credentials: KdbxCredentials, signal?: any | null): Promise<SelfHostedSyncResult>;
}

/**
 * A service account signed in with its token (SPEC §9, §15).
 */
export class ServiceAccount {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Drops the keys from memory.
     */
    close(): void;
    /**
     * Signs in with a service-account token.
     */
    static fromToken(client: OvClient, token: Uint8Array | number[], signal?: any | null): Promise<ServiceAccount>;
    /**
     * Replaces `ov://` references in a template.
     */
    inject(template: Uint8Array | number[], signal?: any | null): Promise<Injected>;
    /**
     * Opens a vault by id or name.
     */
    openVault(id_or_name: string, refresh: boolean, signal?: any | null): Promise<Vault>;
    /**
     * `sa:<id>`.
     */
    principal(): string;
    /**
     * Opens a vault, always downloading it.
     */
    pull(id_or_name: string, signal?: any | null): Promise<Vault>;
    /**
     * Reads a secret by reference.
     */
    read(reference: string, signal?: any | null): Promise<Uint8Array>;
    /**
     * The service account's id.
     */
    saId(): string;
    /**
     * One vault by id or name.
     */
    vault(id_or_name: string, signal?: any | null): Promise<SaVault>;
    /**
     * The vaults it can open.
     */
    vaults(refresh: boolean, signal?: any | null): Promise<SaVault[]>;
    /**
     * Writes a secret by reference.
     */
    write(reference: string, value: Uint8Array | number[], create: boolean, signal?: any | null): Promise<void>;
}

/**
 * A sign-in waiting for a TOTP code. Pass it to `Account.submitTotp`.
 */
export class TotpChallenge {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Which try this is, from 1.
     */
    attempt(): number;
    /**
     * The previous wrong code's error (`invalid_mfa`), if any.
     */
    lastError(): OvError | undefined;
}

/**
 * One open vault: an account vault, a local file, or a read-only saved version.
 */
export class Vault {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * r" Adds a custom icon; returns its id.
     */
    addCustomIcon(png: Uint8Array | number[]): string;
    /**
     * Adds an entry; returns its id.
     */
    addEntry(group_id: string, input: EntryInput): string;
    /**
     * r" Adds a group; returns its id.
     */
    addGroup(parent_id: string | null | undefined, name: string): string;
    /**
     * Merges AutoFill's edits into this vault.
     */
    applyAutofillEdits(edits: AutoFillEdits): boolean;
    /**
     * r" An attachment's bytes.
     */
    attachment(entry_id: string, name: string): Uint8Array;
    /**
     * Conflicts from the last sync.
     */
    conflicts(): SyncConflict[];
    /**
     * Creates a new local database.
     */
    static createLocal(name: string, credentials: KdbxCredentials, signal?: any | null): Promise<Vault>;
    /**
     * r" A custom icon's PNG bytes.
     */
    customIcon(icon_id: string): Uint8Array;
    /**
     * r" Deletes an entry (to the Recycle Bin when enabled).
     */
    deleteEntry(entry_id: string): undefined;
    /**
     * r" Deletes a group.
     */
    deleteGroup(group_id: string): undefined;
    /**
     * Edits an entry (keeping a history copy).
     */
    editEntry(entry_id: string, input: EntryInput): undefined;
    /**
     * r" Empties the Recycle Bin.
     */
    emptyRecycleBin(): undefined;
    /**
     * r" The group at a path, creating missing groups; returns its id.
     */
    ensureGroup(path: string): string;
    /**
     * Every entry (optionally including the Recycle Bin).
     */
    entries(include_recycle_bin: boolean): EntrySummary[];
    /**
     * r" One entry by id.
     */
    entry(entry_id: string): EntryRecord;
    /**
     * The ETag of the last sync.
     */
    etag(): string | undefined;
    /**
     * Exports as a `.kdbx` under new credentials (optionally only some groups).
     */
    exportKdbx(credentials: KdbxCredentials, group_ids?: string[] | null, signal?: any | null): Promise<Uint8Array>;
    /**
     * Exports in the clear (CSV or JSON).
     */
    exportPlain(format: ExportFormat, group_ids?: string[] | null): Uint8Array;
    /**
     * r" One entry by reference (`ov://vault/item/field`, id or title).
     */
    find(reference: string): EntryRecord;
    /**
     * The group at a `/`-separated path.
     */
    groupIdAt(path: string): string | undefined;
    /**
     * Every group.
     */
    groups(): GroupInfo[];
    /**
     * Whether this vault has edits waiting for its next upload.
     */
    hasPendingEdits(): Promise<boolean>;
    /**
     * r" An entry's history, oldest first.
     */
    history(entry_id: string): EntryRecord[];
    /**
     * The vault id (or the local database's id).
     */
    id(): string;
    /**
     * The account vault's info (`undefined` for a local file).
     */
    info(): VaultInfo | undefined;
    /**
     * Whether an entry or group is in the Recycle Bin.
     */
    isInRecycleBin(id: string): boolean;
    /**
     * Opened from this device's copy because the server couldn't be reached.
     */
    isOffline(): boolean;
    /**
     * A saved version, or a vault this account can only read.
     */
    isReadOnly(): boolean;
    /**
     * Keeps local edits in the offline cache without syncing.
     */
    keepEdits(): Promise<void>;
    /**
     * r" Moves an entry to another group.
     */
    moveEntry(entry_id: string, group_id: string): undefined;
    /**
     * r" Moves a group.
     */
    moveGroup(group_id: string, parent_id: string): undefined;
    /**
     * The vault's name.
     */
    name(): string;
    /**
     * Opens a local `.kdbx`.
     */
    static openLocal(kdbx: Uint8Array | number[], credentials: KdbxCredentials, signal?: any | null): Promise<Vault>;
    /**
     * r" One field's value by reference.
     */
    readField(reference: string): Uint8Array;
    /**
     * r" Removes an attachment.
     */
    removeAttachment(entry_id: string, name: string): undefined;
    /**
     * r" Renames a group.
     */
    renameGroup(group_id: string, name: string): undefined;
    /**
     * Restores an entry from a saved version.
     */
    restoreEntry(version: Vault, entry_id: string, group_path: string): undefined;
    /**
     * r" Restores an entry or group from the Recycle Bin.
     */
    restoreFromRecycleBin(id: string): undefined;
    /**
     * The root group's id.
     */
    rootGroupId(): string;
    /**
     * Encrypts a local database for saving.
     */
    saveLocal(signal?: any | null): Promise<Uint8Array>;
    /**
     * r" Adds or replaces an attachment.
     */
    setAttachment(entry_id: string, name: string, data: Uint8Array | number[]): undefined;
    /**
     * Sets several fields of an entry found by reference.
     */
    setFields(reference: string, fields: FieldInput[], create: CreateMode): SetFieldsResult;
    /**
     * r" Sets a group's icon.
     */
    setGroupIcon(group_id: string, icon_id: number): undefined;
    /**
     * Syncs with the server (SPEC §11).
     */
    sync(options: SyncOptions | undefined, signal?: any | null): Promise<SyncReport>;
    /**
     * How an entry differs between this vault and a saved version.
     */
    versionDifference(version: Vault, entry_id: string): VersionDifference;
    /**
     * Writes one field and syncs (TS `AccountVault.write`).
     */
    writeField(reference: string, value: Uint8Array | number[], create: boolean, signal?: any | null): Promise<SyncReport>;
}

/**
 * Called once by `index.js` at load: the `OvError` class to construct errors with, and the
 * callback a panic reports to before the module traps.
 */
export function __install(error_class: Function, on_panic: Function): void;

/**
 * XChaCha20-Poly1305 decryption; `decryption_failed` on a wrong key or tampered input.
 */
export function aeadDecrypt(key: Uint8Array | number[], nonce: Uint8Array | number[], ciphertext: Uint8Array | number[], aad: Uint8Array | number[]): Uint8Array;

/**
 * XChaCha20-Poly1305 encryption: 32-byte key, 24-byte nonce; returns ciphertext ‖ tag.
 */
export function aeadEncrypt(key: Uint8Array | number[], nonce: Uint8Array | number[], plaintext: Uint8Array | number[], aad: Uint8Array | number[]): Uint8Array;

/**
 * Argon2id (v0x13), 32-byte output. `m` in KiB.
 */
export function argon2id(password: Uint8Array | number[], salt: Uint8Array | number[], m: number, t: number, p: number): Uint8Array;

/**
 * The fields an item share includes by default.
 */
export function defaultShareFields(): string[];

/**
 * Whether a remembered account's erase date is more than a day past.
 */
export function deletionExpired(scheduled_for: string | null | undefined, now_ms: number): boolean;

/**
 * An entry's TOTP URI, from its fields (KeePassXC and KeePass conventions).
 */
export function entryTotpUri(fields: FieldRecord[], label: string): Uint8Array | undefined;

/**
 * HKDF-SHA256 (RFC 5869) with `length` output bytes.
 */
export function hkdfSha256(ikm: Uint8Array | number[], salt: Uint8Array | number[], info: Uint8Array | number[], length: number): Uint8Array;

/**
 * The payload of an item share.
 */
export function itemSharePayload(entry: EntryRecord, names: string[], shared_by?: string | null): SharePayload;

/**
 * Parses an `otpauth://` URI.
 */
export function parseTotpUri(uri: Uint8Array | number[]): TotpParams;

/**
 * `n` bytes from the platform CSPRNG (`crypto.getRandomValues`).
 */
export function randomBytes(n: number): Uint8Array;

/**
 * SHA-256.
 */
export function sha256(data: Uint8Array | number[]): Uint8Array;

/**
 * The fields of an entry that can be shared.
 */
export function shareableFields(entry: EntryRecord): ShareableField[];

/**
 * The payload of a text share.
 */
export function textSharePayload(text: Uint8Array | number[], title?: string | null, shared_by?: string | null): SharePayload;

/**
 * The TOTP code at `nowMs`.
 */
export function totpCode(params: TotpParams, now_ms: number): TotpCode;

/**
 * The core's version (`ov-core` crate version).
 */
export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __install: (a: any, b: any) => void;
    readonly __wbg_account_free: (a: number, b: number) => void;
    readonly __wbg_eventstream_free: (a: number, b: number) => void;
    readonly __wbg_ovclient_free: (a: number, b: number) => void;
    readonly __wbg_selfhosted_free: (a: number, b: number) => void;
    readonly __wbg_serviceaccount_free: (a: number, b: number) => void;
    readonly __wbg_totpchallenge_free: (a: number, b: number) => void;
    readonly __wbg_vault_free: (a: number, b: number) => void;
    readonly account_acceptInvitation: (a: number, b: number, c: number, d: number) => any;
    readonly account_appleEligibility: (a: number, b: number, c: number, d: number) => any;
    readonly account_auditLog: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly account_autofillEdits: (a: number, b: number, c: number) => any;
    readonly account_cachedKdf: (a: number) => any;
    readonly account_cachedVaults: (a: number) => any;
    readonly account_cancelInvitation: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_changeEmail: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly account_changePassword: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_changeRole: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_checkParkedSession: (a: number, b: number, c: number, d: number) => any;
    readonly account_clearAutofillEdits: (a: number, b: any) => any;
    readonly account_clockOffsetMs: (a: number) => any;
    readonly account_confirmMember: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_confirmTwoStep: (a: number, b: number, c: number, d: number) => any;
    readonly account_createOrg: (a: number, b: number, c: number, d: number) => any;
    readonly account_createServiceAccount: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly account_createShare: (a: number, b: any, c: any, d: number) => any;
    readonly account_createVault: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_deleteAccount: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_deleteOrg: (a: number, b: number, c: number, d: number) => any;
    readonly account_deleteServiceAccount: (a: number, b: number, c: number, d: number) => any;
    readonly account_deleteVault: (a: number, b: number, c: number, d: number) => any;
    readonly account_deletionPreview: (a: number, b: number) => any;
    readonly account_deletionScheduledFor: (a: number) => [number, number];
    readonly account_devices: (a: number, b: number) => any;
    readonly account_disableTwoStep: (a: number, b: number, c: number, d: number) => any;
    readonly account_email: (a: number) => [number, number];
    readonly account_fingerprint: (a: number) => [number, number, number];
    readonly account_forgetDevice: (a: number, b: number, c: number) => any;
    readonly account_hasAnyPendingEdits: (a: number) => any;
    readonly account_hasPendingEdits: (a: number, b: number, c: number) => any;
    readonly account_hasSecretKey: (a: number, b: number, c: number) => any;
    readonly account_importKdbx: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_importVault: (a: number, b: number, c: any, d: number) => any;
    readonly account_invitations: (a: number, b: number, c: number, d: number) => any;
    readonly account_invite: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_isOffline: (a: number) => number;
    readonly account_isSignedIn: (a: number) => number;
    readonly account_isUnlocked: (a: number) => number;
    readonly account_issueServiceAccountSecret: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly account_keepAutofillEdit: (a: number, b: number, c: number, d: any, e: number, f: number) => any;
    readonly account_listShares: (a: number, b: number) => any;
    readonly account_lock: (a: number) => void;
    readonly account_login: (a: number, b: any, c: number) => any;
    readonly account_lookUp: (a: number, b: number, c: number, d: number) => any;
    readonly account_managedOrgVaults: (a: number, b: number, c: number, d: number) => any;
    readonly account_me: (a: number, b: number) => any;
    readonly account_members: (a: number, b: number, c: number, d: number) => any;
    readonly account_openCopy: (a: number, b: number, c: number) => any;
    readonly account_openOffline: (a: number, b: number, c: number) => any;
    readonly account_openVault: (a: number, b: number, c: number, d: number) => any;
    readonly account_openVaultVersion: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly account_org: (a: number, b: number, c: number, d: number) => any;
    readonly account_orgMembers: (a: number, b: number, c: number, d: number) => any;
    readonly account_orgs: (a: number, b: number) => any;
    readonly account_parkSession: (a: number) => any;
    readonly account_plan: (a: number, b: number) => any;
    readonly account_principal: (a: number) => [number, number, number];
    readonly account_recipient: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_reconnect: (a: number, b: number) => any;
    readonly account_recover: (a: number, b: number, c: number, d: number, e: number, f: any, g: number, h: number) => any;
    readonly account_recoverInfo: (a: number, b: number, c: number, d: number) => any;
    readonly account_recoveryStatus: (a: number, b: number) => any;
    readonly account_register: (a: number, b: any, c: number) => any;
    readonly account_removeMember: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_renameOrg: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_renameVault: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_reportAppleTransaction: (a: number, b: number, c: number, d: number) => any;
    readonly account_requestEmailChange: (a: number, b: number, c: number, d: number) => any;
    readonly account_restoreAccount: (a: number, b: number, c: number, d: number) => any;
    readonly account_restoreFromArchive: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_resumeSession: (a: number, b: number, c: number) => any;
    readonly account_resumeUnlocked: (a: number, b: number, c: number, d: number) => any;
    readonly account_revoke: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_revokeDevice: (a: number, b: number, c: number, d: number) => any;
    readonly account_revokeSecret: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_revokeShare: (a: number, b: number, c: number, d: number) => any;
    readonly account_rotateFlagged: (a: number, b: number, c: number, d: number) => any;
    readonly account_rotateVaultKey: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_secretKey: (a: number) => any;
    readonly account_serverConfig: (a: number) => any;
    readonly account_serviceAccountSecrets: (a: number, b: number, c: number, d: number) => any;
    readonly account_serviceAccounts: (a: number, b: number, c: number, d: number) => any;
    readonly account_setMemberRole: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_setOrgShareLinks: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly account_setSecretExpiry: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_shareBase: (a: number) => [number, number];
    readonly account_shareBlockedReason: (a: number, b: number, c: number) => any;
    readonly account_shareVault: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_signOut: (a: number, b: number, c: number) => any;
    readonly account_signOutOnUnload: (a: number) => any;
    readonly account_signOutParked: (a: number, b: number, c: number, d: number) => any;
    readonly account_signedOut: (a: number, b: number) => any;
    readonly account_startTwoStep: (a: number, b: number) => any;
    readonly account_storedSecretKey: (a: number, b: number, c: number) => any;
    readonly account_storedSession: (a: number) => any;
    readonly account_submitTotp: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly account_subscribe: (a: number, b: number) => any;
    readonly account_transferVault: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_unlock: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_unlockWithAuk: (a: number, b: number, c: number, d: number) => any;
    readonly account_unlockedKeysetSecret: (a: number) => [number, number, number];
    readonly account_updateServiceAccount: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly account_upgradeUrl: (a: number, b: any) => [number, number, number, number];
    readonly account_userId: (a: number) => [number, number];
    readonly account_vaultHistory: (a: number, b: number, c: number, d: number) => any;
    readonly account_vaultQuota: (a: number, b: number, c: number) => any;
    readonly account_vaults: (a: number, b: number) => any;
    readonly account_verifiedPublicKeys: (a: number, b: number, c: number, d: number) => any;
    readonly account_verifySession: (a: number, b: number) => any;
    readonly account_webSessionUrl: (a: number, b: number, c: number, d: number) => any;
    readonly aeadDecrypt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly aeadEncrypt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly argon2id: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly defaultShareFields: () => [number, number];
    readonly deletionExpired: (a: number, b: number, c: number) => [number, number, number];
    readonly entryTotpUri: (a: any, b: number, c: number) => [number, number, number];
    readonly eventstream_close: (a: number) => void;
    readonly eventstream_next: (a: number, b: number) => any;
    readonly eventstream_reconnect: (a: number) => void;
    readonly hkdfSha256: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number, number];
    readonly itemSharePayload: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly ovclient_config: (a: number) => any;
    readonly ovclient_connect: (a: number, b: number, c: number, d: number) => any;
    readonly ovclient_discover: (a: number, b: number, c: number, d: number) => any;
    readonly ovclient_forgetRemembered: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly ovclient_hasPendingEdits: (a: number, b: number, c: number) => any;
    readonly ovclient_markRememberedChecked: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly ovclient_new: (a: any, b: any) => [number, number, number];
    readonly ovclient_openShare: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any, i: number) => any;
    readonly ovclient_rememberAccount: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly ovclient_rememberedAccounts: (a: number) => any;
    readonly ovclient_sessionState: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly ovclient_setRememberedDeletion: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly ovclient_shareInfo: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly parseTotpUri: (a: number, b: number) => [number, number, number];
    readonly randomBytes: (a: number) => [number, number, number, number];
    readonly selfhosted_connect: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly selfhosted_createPairingCode: (a: number, b: number) => any;
    readonly selfhosted_events: (a: number, b: number) => any;
    readonly selfhosted_health: (a: number, b: number) => any;
    readonly selfhosted_listDatabases: (a: number, b: number) => any;
    readonly selfhosted_pair: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly selfhosted_restore: (a: number, b: number, c: number) => any;
    readonly selfhosted_serverUrl: (a: number) => [number, number];
    readonly selfhosted_syncDatabase: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly serviceaccount_close: (a: number) => void;
    readonly serviceaccount_fromToken: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_inject: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_openVault: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly serviceaccount_principal: (a: number) => [number, number];
    readonly serviceaccount_pull: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_read: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_saId: (a: number) => [number, number];
    readonly serviceaccount_vault: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_vaults: (a: number, b: number, c: number) => any;
    readonly serviceaccount_write: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly sha256: (a: number, b: number) => [number, number];
    readonly shareableFields: (a: any) => [number, number, number];
    readonly textSharePayload: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly totpCode: (a: any, b: number) => [number, number, number];
    readonly totpchallenge_attempt: (a: number) => number;
    readonly totpchallenge_lastError: (a: number) => any;
    readonly vault_addCustomIcon: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_addEntry: (a: number, b: number, c: number, d: any) => [number, number, number];
    readonly vault_addGroup: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_applyAutofillEdits: (a: number, b: any) => [number, number, number];
    readonly vault_attachment: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_conflicts: (a: number) => any;
    readonly vault_createLocal: (a: number, b: number, c: any, d: number) => any;
    readonly vault_customIcon: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_deleteEntry: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_deleteGroup: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_editEntry: (a: number, b: number, c: number, d: any) => [number, number, number];
    readonly vault_emptyRecycleBin: (a: number) => [number, number, number];
    readonly vault_ensureGroup: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_entries: (a: number, b: number) => any;
    readonly vault_entry: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_etag: (a: number) => [number, number];
    readonly vault_exportKdbx: (a: number, b: any, c: number, d: number, e: number) => any;
    readonly vault_exportPlain: (a: number, b: any, c: number, d: number) => [number, number, number];
    readonly vault_find: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_groupIdAt: (a: number, b: number, c: number) => [number, number];
    readonly vault_groups: (a: number) => any;
    readonly vault_hasPendingEdits: (a: number) => any;
    readonly vault_history: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_id: (a: number) => [number, number];
    readonly vault_info: (a: number) => any;
    readonly vault_isInRecycleBin: (a: number, b: number, c: number) => number;
    readonly vault_isOffline: (a: number) => number;
    readonly vault_isReadOnly: (a: number) => number;
    readonly vault_keepEdits: (a: number) => any;
    readonly vault_moveEntry: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_moveGroup: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_name: (a: number) => [number, number];
    readonly vault_openLocal: (a: number, b: number, c: any, d: number) => any;
    readonly vault_readField: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_removeAttachment: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_renameGroup: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_restoreEntry: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly vault_restoreFromRecycleBin: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_rootGroupId: (a: number) => [number, number];
    readonly vault_saveLocal: (a: number, b: number) => any;
    readonly vault_setAttachment: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly vault_setFields: (a: number, b: number, c: number, d: any, e: any) => [number, number, number];
    readonly vault_setGroupIcon: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly vault_sync: (a: number, b: any, c: number) => any;
    readonly vault_versionDifference: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly vault_writeField: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly version: () => [number, number];
    readonly wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___wasm_bindgen_90e3c6fa821d6ed___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_90e3c6fa821d6ed___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke_______true_: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
