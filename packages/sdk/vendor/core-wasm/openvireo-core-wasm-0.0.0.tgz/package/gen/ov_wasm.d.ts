/* tslint:disable */
/* eslint-disable */

/** How `Account.importKdbx` / `importVault` brings a database in. */
export type ImportMode =
| { kind: "newVault"; name?: string; orgId?: string }
| { kind: "merge"; vaultId: string }
| { kind: "copies"; vaultId: string };
export interface ImportOutcome { vault: Vault; uploaded: boolean; uploadError?: OvError; report?: SyncReport }
/** Who `Account.shareVault` grants to. */
export type Grantee = { kind: "email"; email: string } | { kind: "principal"; principal: Principal };
/** `keep` leaves the expiry as it is, `never` clears it. */
export type ExpiryChange = { kind: "keep" } | { kind: "never" } | { kind: "at"; at: Rfc3339 };
/** Entry expiry edit; `at` is Unix seconds. */
export type EntryExpiry = { kind: "keep" } | { kind: "never" } | { kind: "at"; at: number };
/** How `Vault.importFrom` brings another open vault in (contract-v1.6); `copies` goes under `parentGroupId` (the root when absent). */
export type LocalImportMode = { kind: "merge" } | { kind: "copies"; parentGroupId?: string };
/** The key derivation a password-protected `.kdbx` is saved with (contract-v1.6); `memory` is in bytes. */
export type KdbxKdf =
| { kind: "databaseDefault" }
| { kind: "argon2d"; memory: number; iterations: number; parallelism: number }
| { kind: "argon2id"; memory: number; iterations: number; parallelism: number }
| { kind: "aesKdf"; rounds: number };
export type LoginStep = { kind: "needsTotp"; challenge: TotpChallenge } | { kind: "unlocked"; unlocked: Unlocked };
export interface Unlocked { auk: Uint8Array; offline: boolean; deletionScheduledFor?: Rfc3339 }
export interface RegisterInput { email: string; password: Uint8Array; kdf?: KdfOverrides; trustDevice: boolean }
export interface LoginInput { email: string; password: Uint8Array; secretKey?: Uint8Array; totp?: string; trustDevice: boolean }
export type AccountEvent =
| { kind: "vaultChanged"; vaultId: string; etag?: string; revision?: number; deleted: boolean }
| { kind: "vaultsChanged"; vaults: VaultInfo[] }
| { kind: "sessionEnded"; reason: SignedOutReason; at?: Rfc3339 }
| { kind: "databaseChanged"; databaseId: string; etag?: string; revision?: number; deleted: boolean };



/** Why a request failed without a response; `fetchTransport` rejects with these. */
export interface TransportFailure { kind: "offline" | "timeout" | "tls" | "cancelled" | "other"; message?: string }
/** An open server-sent events body. */
export interface ByteStream { readonly status: number; nextChunk(): Promise<Uint8Array | null | undefined>; close(): void }
/** HTTP. Must not follow redirects, add cookies or log header values. Rejects with a `TransportFailure` (or a `TypeError` = offline, `AbortError` = cancelled). */
export interface HttpTransport { send(req: HttpRequest): Promise<HttpResponse>; openStream(req: HttpRequest): Promise<ByteStream> }
/** Small persistent secrets (sessions, Secret Keys). Keys are short ASCII strings. */
export interface SecureStore { get(key: string): Promise<Uint8Array | null | undefined>; set(key: string, value: Uint8Array): Promise<void>; delete(key: string): Promise<void> }
/** The offline cache (SPEC §20), keyed by user and vault. Everything in it is ciphertext or public. */
export interface BlobCache {
    load(userId: string, vaultId: string): Promise<CachedVault | null | undefined>;
    save(userId: string, vaultId: string, v: CachedVault): Promise<void>;
    remove(userId: string, vaultId: string): Promise<void>;
    list(userId: string): Promise<string[]>;
    loadMeta(userId: string, name: string): Promise<Uint8Array | null | undefined>;
    saveMeta(userId: string, name: string, value: Uint8Array): Promise<void>;
    clearUser(userId: string): Promise<void>;
}
export interface Clock { nowUnixMs(): number }
export interface LogSink { log(level: LogLevel, target: string, msg: string): void }
/** The platform services the core runs on. */
export interface Host { http: HttpTransport; store: SecureStore; cache: BlobCache; clock: Clock; log: LogSink }


/** A KDBX key: any of a password (text), a password's SHA-256 (`kdbxPasswordHash`), a key file's bytes, or a 32-byte vault key (SPEC §7, the key-file component). */
export interface KdbxKey { password?: string | Uint8Array; passwordHash?: Uint8Array; keyFile?: Uint8Array; vaultKey?: Uint8Array }
export interface KdbxKeyVersion { version: number; key: Uint8Array }
/** Outer-header settings, readable without the key. */
export interface KdbxHeaderInfo { version: string; cipher: string; compression: "none" | "gzip"; kdf: KdbxKdfSettings }
/** `kdf`: `argon2id`, `argon2d`, `aes` or `other`; Argon2 `m` in bytes (as KDBX stores it), AES `t` = rounds. */
export interface KdbxKdfSettings { kdf: string; m?: number; t?: number; p?: number }
/** The SDK's `KeePassEntry` (times in Unix seconds, the password as UTF-8). */
export interface KdbxEntryInfo { uuid: string; title: string; username: string; passwordValue: Uint8Array; url: string; notes: string; groupName: string; groupUuid: string; tags: string[]; expiryTime?: number; lastModified?: number }
export interface KdbxGroupInfo { uuid: string; name: string; parentUuid?: string; icon: number; isRecycleBin: boolean }
export type ChangeSubject = "entry" | "group" | "database";
export interface KdbxMergeChange { change: ChangeType; subject: ChangeSubject; uuid?: string; title?: string; group?: string; details: string }
export interface KdbxEntryConflict { uuid: string; title: string; fields: string[] }
/** What the sync merge did (`added`/`updated`/`deleted`: entry ids, seen from the local side). */
export interface KdbxMergeReport { conflicts: KdbxEntryConflict[]; added: string[]; updated: string[]; deleted: string[]; changes: KdbxMergeChange[]; localChanged: boolean; remoteChanged: boolean }
export interface KdbxSyncConflict { uuid: string; kind: ConflictKind; title: string; fields: string[] }
export interface KdbxImportSummary { added: number; updated: number; unchanged: number; groupsAdded: number; changes: KdbxMergeChange[] }
export type MergeMode = "keep-newer" | "synchronize";
export interface MergeIntoOptions { skipDatabaseCustomData?: boolean; skipGroups?: string[] }
/** Entry id → last modification in Unix milliseconds: the SDK's `Snapshot` (`Record<string, number>`). */
export type KdbxSnapshot = Record<string, number>;


/** A service account token's parts (SPEC §9). Wipe `secret` and `kek`. */
export interface SaTokenParts { url: string; saId: string; secret: Uint8Array; kek: Uint8Array }
export interface NewSaSecretInput { url: string; saId: string; master: Uint8Array; secretId: string; name?: string; expiresAt?: string | null }
/** `token` (UTF-8, shown once) and the `POST …/secrets` body as JSON (snake_case). */
export interface NewSaSecret { token: Uint8Array; body: { id: string; name?: string; secret_hash: string; prefix: string; wrapped_master: string; expires_at: string | null } }


/** Access-token claims (SPEC §9) as JSON: `iss`, `aud`, `sub`, `dev`, `org`, `vlt`, `del`, `iat`, `nbf`, `exp`, `jti` and any others. */
export type AccessClaims = { iss: string; aud?: string | string[]; sub: string; [claim: string]: unknown };
export interface Jwks { keys: { kty: string; crv?: string; x?: string; kid?: string; use?: string; alg?: string }[] }
/** `now` in Unix seconds (default: the current time); `skew` defaults to 60 s. */
export interface VerifyJwtOptions { issuer: string; audience: string; now?: number; skew?: number }


/** An account or service-account keyset (SPEC §5): X25519 `encSk`, Ed25519 `signSeed` and the signed public keys (the SDK's flat `Keyset`). Wipe the secrets. */
export interface Keyset extends PublicKeys { encSk: Uint8Array; signSeed: Uint8Array }
/** Public keys as the server sends them (base64url, snake_case). */
export interface PublicKeysJson { enc_pk: string; sign_pk: string; sig: string }
/** A wrapped keyset as stored on the server (base64url, snake_case). */
export interface WrappedKeysetJson { enc_pk: string; sign_pk: string; sig: string; wrapped: string }


/** Fixed randomness for `seal` (test vectors only). */
export interface SealOptions { ephemeralSecretKey?: Uint8Array; nonce?: Uint8Array }


/** The current public keys a restore proof binds (`PublicKeys` will do). */
export interface CurrentKeys { encPk: Uint8Array; signPk: Uint8Array }


/** What a share link holds (SPEC §22). Field values are UTF-8. */
export interface SharePayload { v: number; kind: string; title?: string; sharedBy?: string; fields: ShareField[] }
/** `k`: `username`, `password`, `url`, `notes`, `totp`, `custom` or `text` (open set). */
export interface ShareField { k: string; label: string; value: Uint8Array; protected: boolean }
/** A field an entry can share (`name` is the entry field, `kind` the share kind it becomes). */
export interface ShareableField { name: string; kind: string; label: string; value: Uint8Array; protected: boolean }
/** One string field of an entry. */
export interface FieldRecord { name: string; value: Uint8Array; protected: boolean }
/** A parsed share link: `base` (the page), the share `id` and the 32-byte `key` from the fragment. */
export interface ShareLinkParts { base: string; id: string; key: Uint8Array }
/** Steam Guard codes: `encoder: "steam"` (the facade's spelling) or `steam: true` (the SDK's); both are set on output. */
export interface TotpParams { secret: Uint8Array; digits: number; period: number; algorithm: TotpAlgorithm; encoder?: string; steam?: boolean }
/** The code (UTF-8 digits) and the seconds it stays valid. */
export interface TotpCode { code: Uint8Array; remaining: number }


/** `allowWeak` skips the minimum-cost check (test vectors only); `kdfMin` is the server's `kdf_min`. */
export interface DeriveAukOptions { allowWeak?: boolean; kdfMin?: KdfMin }
export interface KdfOverrides { m?: number; t?: number; p?: number }


/** `idU`: the lowercased, trimmed email; `idS`: the issuer host. */
export interface OpaqueIds { idU: string; idS: string }
export interface OpaqueRegistrationStart { request: Uint8Array; state: Uint8Array }
export interface OpaqueRegistrationFinish { record: Uint8Array; exportKey: Uint8Array }
export interface OpaqueLoginStart { ke1: Uint8Array; state: Uint8Array }
export interface OpaqueLoginFinish { authU: Uint8Array; sessionKey: Uint8Array; exportKey: Uint8Array }


export interface AppleEligibility {
    eligible: boolean;
    reason?: string;
}


export interface AppleTransactionResult {
    subject: string;
    plan: Plan;
}


export interface AttachmentInfo {
    name: string;
    size: number;
    protected: boolean;
}


export interface AuditEvent {
    id: string;
    at: Rfc3339;
    actor: Principal;
    action: string;
    target?: string;
    ip?: string;
    details?: string;
}


export interface AuditPage {
    events: AuditEvent[];
    next?: string;
}


export interface AutoFillEdit {
    entry: EntryRecord;
    groupPath: string;
}


export interface AutoFillEdits {
    vaultId: string;
    entries: AutoFillEdit[];
    version: string;
}


export interface Billing {
    source: string;
    interval: string;
    status: string;
    renewsAt?: Rfc3339;
    endsAt?: Rfc3339;
    manage: string;
}


export interface BlobMeta {
    id: string;
    etag: string;
    revision: number;
    size: number;
    updatedAt: Rfc3339;
}


export interface CachedVault {
    state: Uint8Array;
    base?: Uint8Array;
    pending?: Uint8Array;
    autofill?: Uint8Array;
}


export interface ClientConfig {
    device: DeviceInfo;
    offline: boolean;
    server?: ServerConfig;
}


export interface CreatedServiceAccount {
    serviceAccount: ServiceAccountInfo;
    token: Uint8Array;
}


export interface CreatedShare {
    id: string;
    url: Uint8Array;
    expiresAt: Rfc3339;
}


export interface DeletionCandidate {
    id: string;
    email: string;
    role: OrgRole;
}


export interface DeletionOrg {
    id: string;
    name: string;
    role: OrgRole;
    outcome: DeletionOutcome;
    members: DeletionCandidate[];
}


export interface DeletionPreview {
    scheduledFor?: Rfc3339;
    eraseOn: Rfc3339;
    vaults: DeletionVault[];
    orgs: DeletionOrg[];
    subscription?: DeletionSubscription;
    shareLinks: number;
    blocked: boolean;
}


export interface DeletionShare {
    principal: Principal;
    display?: string;
    role: VaultRole;
}


export interface DeletionSubscription {
    plan: string;
    periodEnd?: Rfc3339;
    source: string;
    manage: string;
}


export interface DeletionVault {
    id: string;
    name?: string;
    sharedWith: DeletionShare[];
}


export interface Device {
    id: string;
    name: string;
    platform: string;
    createdAt: Rfc3339;
    lastSeenAt: Rfc3339;
    current: boolean;
}


export interface DeviceInfo {
    id?: string;
    name: string;
    platform: Platform;
}


export interface EmergencyKit {
    email: string;
    issuer: string;
    web?: string;
}


export interface EntryInput {
    fields: FieldInput[];
    removeFields: string[];
    tags?: string[];
    iconId?: number;
    expiry: EntryExpiry;
    foregroundColor?: string;
    backgroundColor?: string;
    customIcon?: string | null;
    fieldOrder?: string[];
}


export interface EntryRecord {
    id: string;
    groupId: string;
    groupPath: string[];
    fields: FieldRecord[];
    tags: string[];
    iconId: number;
    customIcon?: string;
    foregroundColor: string;
    backgroundColor: string;
    overrideUrl: string;
    createdAt: number;
    modifiedAt: number;
    expiresAt?: number;
    attachments: AttachmentInfo[];
    historyCount: number;
    qualityCheck: boolean;
    lastAccessAt?: number;
    usageCount: number;
}


export interface EntrySummary {
    id: string;
    groupId: string;
    groupPath: string[];
    title: string;
    username: string;
    url: string;
    tags: string[];
    protectedFields: string[];
    iconId: number;
    customIcon?: string;
    modifiedAt: number;
    expiresAt?: number;
    inRecycleBin: boolean;
    lastAccessAt?: number;
    usageCount: number;
}


export interface FieldInput {
    name: string;
    value: Uint8Array;
    protected?: boolean;
}


export interface GrantResult {
    principal: Principal;
    fingerprint: string;
}


export interface GroupInfo {
    id: string;
    name: string;
    parentId?: string;
    path: string[];
    iconId: number;
    notes: string;
    isRecycleBin: boolean;
    entryCount: number;
}


export interface HttpRequest {
    method: HttpMethod;
    url: string;
    headers: [string, string][];
    body?: Uint8Array;
    keepalive: boolean;
}


export interface HttpResponse {
    status: number;
    headers: [string, string][];
    body: Uint8Array;
}


export interface ImportPreview {
    entries: number;
    groups: number;
}


export interface ImportSummary {
    added: number;
    updated: number;
    unchanged: number;
    groupsAdded: number;
    changes: MergeChange[];
}


export interface ImportTarget {
    groupId: string;
    path: string;
}


export interface Injected {
    text: Uint8Array;
    secrets: Uint8Array[];
}


export interface Invitation {
    id: string;
    email: string;
    role: OrgRole;
    expiresAt: Rfc3339;
    invitedBy: Principal;
}


export interface IssuedSecret {
    token: Uint8Array;
    id: string;
    prefix: string;
}


export interface KdbxCredentials {
    password?: Uint8Array;
    keyFile?: Uint8Array;
    passwordHash?: Uint8Array;
}


export interface KdfMin {
    m: number;
    t: number;
}


export interface KdfOverrides {
    m?: number;
    t?: number;
    p?: number;
}


export interface KdfParams {
    alg: string;
    salt: string;
    m: number;
    t: number;
    p: number;
}


export interface Member {
    userId: string;
    email: string;
    name?: string;
    role: OrgRole;
    status: MemberStatus;
    publicKeys?: PublicKeys;
}


export interface MergeChange {
    change: ChangeType;
    uuid?: string;
    title?: string;
    group?: string;
    details: string;
}


export interface NewAccount {
    userId: string;
    secretKey: Uint8Array;
    emergencyKit: EmergencyKit;
    auk: Uint8Array;
}


export interface NewServiceAccount {
    name: string;
    vaults: VaultGrantRequest[];
    expiresAt?: Rfc3339;
    secretName?: string;
}


export interface OpaqueConfig {
    lib: string;
    version: string;
    context: string;
    ids: string;
}


export interface OpenedShare {
    payload: SharePayload;
    opensLeft?: number;
}


export interface Org {
    id: string;
    name: string;
    role: OrgRole;
    plan?: Plan;
    itemShareLinks?: ShareLinkPolicy;
    createdAt: Rfc3339;
}


export interface OrgMembership {
    id: string;
    name: string;
    role: OrgRole;
    status: MemberStatus;
    plan?: Plan;
    itemShareLinks?: ShareLinkPolicy;
}


export interface PairingCode {
    code: string;
    expiresAt: Rfc3339;
}


export interface Plan {
    id?: string;
    limits: PlanLimit[];
    billing?: Billing;
}


export interface PlanLimit {
    name: string;
    value?: number;
}


export interface Profile {
    id: string;
    email: string;
    name?: string;
    totpEnabled: boolean;
    plan?: Plan;
    orgs: OrgMembership[];
    deletionScheduledFor?: Rfc3339;
}


export interface PublicKeys {
    encPk: Uint8Array;
    signPk: Uint8Array;
    sig: Uint8Array;
    fingerprint: string;
}


export interface ReconnectResult {
    vaults: VaultInfo[];
    dropped: string[];
}


export interface RecoveryReset {
    email: string;
    notBefore: Rfc3339;
    expiresAt: Rfc3339;
    archiveDays: number;
    personalVaults: number;
    sharedGrants: number;
    soleAdminOrgs: string[];
}


export interface RecoveryStatus {
    archived: boolean;
    email?: string;
    expiresAt?: Rfc3339;
    vaults?: number;
    locked: boolean;
}


export interface RememberedAccount {
    email: string;
    issuer: string;
    userId: string;
    lastUsedAt: Rfc3339;
    checkedAt?: Rfc3339;
    deletionScheduledFor?: Rfc3339;
}


export interface RotationFailure {
    vaultId: string;
    error: OvError;
}


export interface RotationReport {
    rotated: string[];
    failed: RotationFailure[];
}


export interface SaSecretInfo {
    id: string;
    prefix: string;
    name?: string;
    createdAt: Rfc3339;
    lastUsedAt?: Rfc3339;
    expiresAt?: Rfc3339;
}


export interface SaVault {
    id: string;
    name: string;
    role: VaultRole;
}


export interface SelfHostedSyncResult {
    kdbx: Uint8Array;
    report: SyncReport;
}


export interface ServerConfig {
    issuer: string;
    api: string;
    sync: string;
    jwksUri: string;
    opaque: OpaqueConfig;
    kdfMin?: KdfMin;
    web?: string;
    share?: string;
}


export interface ServiceAccountInfo {
    id: string;
    orgId: string;
    name: string;
    publicKeys?: PublicKeys;
    createdBy?: Principal;
    createdAt?: Rfc3339;
    expiresAt?: Rfc3339;
    disabled: boolean;
}


export interface ServiceAccountUpdate {
    name?: string;
    expiresAt: ExpiryChange;
    disabled?: boolean;
}


export interface SetFieldsResult {
    entry: EntryRecord;
    created: boolean;
}


export interface ShareInfo {
    expiresAt: Rfc3339;
    opensLeft?: number;
    kdf?: KdfParams;
}


export interface ShareListing {
    id: string;
    vaultId?: string;
    reference?: ShareRef;
    passcode: boolean;
    maxOpens?: number;
    opens: number;
    openedAt: Rfc3339[];
    createdAt: Rfc3339;
    expiresAt: Rfc3339;
    status: string;
    endedAt?: Rfc3339;
    endReason?: string;
}


export interface ShareOptions {
    expiresIn: number;
    maxOpens?: number;
    passcode?: Uint8Array;
    vaultId?: string;
    entryId?: string;
}


export interface ShareRecipient {
    principal: Principal;
    email?: string;
    name?: string;
    publicKeys: PublicKeys;
}


export interface ShareRef {
    vault?: string;
    entry?: string;
    title: string;
}


export interface StoredSession {
    issuer: string;
    userId: string;
    email: string;
    deviceId: string;
}


export interface SyncConflict {
    uuid: string;
    kind: ConflictKind;
    title: string;
    fields: string[];
}


export interface SyncOptions {
    localChanged: boolean;
    acceptServerState?: boolean;
}


export interface SyncReport {
    outcome: SyncOutcome;
    conflicts: SyncConflict[];
    changes: MergeChange[];
    attempts: number;
    etag?: string;
    clockOffsetMs?: number;
    clockSkewed: boolean;
}


export interface TotpSetup {
    secret: Uint8Array;
    uri: Uint8Array;
}


export interface VaultGrantRequest {
    vaultId: string;
    role: VaultRole;
}


export interface VaultInfo {
    id: string;
    name: string;
    role: VaultRole;
    orgId?: string;
    currentKeyVersion: number;
    pendingKeyVersion?: number;
    rotationRequired: boolean;
}


export interface VaultKdbxSyncResult {
    kdbx: Uint8Array;
    credentials: KdbxCredentials;
    report: SyncReport;
}


export interface VaultMember {
    principal: Principal;
    role: VaultRole;
    display: string;
    keyVersion: number;
    isYou: boolean;
}


export interface VaultVersion {
    revision: number;
    etag: string;
    size?: number;
    savedAt?: Rfc3339;
    isCurrent: boolean;
}


export type Argon2Type = "argon2d" | "argon2i" | "argon2id";
/** The SDK's `Argon2Params`: memory `m` in KiB, output length `dkLen` in bytes. Argon2 version 0x13. */
export interface Argon2Params { type: Argon2Type; password: Uint8Array; salt: Uint8Array; m: number; t: number; p: number; dkLen: number }


export type ChangeType = "added" | "modified" | "moved" | "deleted" | "metadata";


export type ConflictKind = "edited-on-both" | "deleted-here-edited-there" | "edited-here-deleted-there";


export type CreateMode = "must_exist" | "create_if_missing" | "create_only";


export type DeletionOutcome = "leave" | "delete" | "blocked";


export type ExportFormat = "csv" | "json";


export type HttpMethod = "GET" | "HEAD" | "POST" | "PUT" | "PATCH" | "DELETE";


export type LogLevel = "error" | "warn" | "info" | "debug" | "trace";


export type MemberStatus = "invited" | "accepted" | "confirmed";


export type OrgRole = "owner" | "admin" | "member";


export type ParkedCheck = "valid" | "ended" | "no_answer";


export type Platform = "qt-linux" | "qt-macos" | "qt-windows" | "web" | "cli" | "connect" | "ios";


export type SessionState = "active" | "parked" | "signed_out";


export type ShareLinkPolicy = "on" | "managers" | "off";


export type SignedOutReason = "token_reused" | "session_expired" | "unauthorized" | "logout" | "deletion_scheduled" | "account_deleted";


export type SyncOutcome = "unchanged" | "pulled" | "uploaded" | "created";


export type TotpAlgorithm = "SHA1" | "SHA256" | "SHA512";


export type VaultRole = "read" | "write" | "manage";


export type VersionDifference = "same" | "changed" | "deleted";


import type { OvError } from "../index.js";
/** Server times: RFC 3339 strings. KDBX times: Unix seconds. Secrets: Uint8Array (UTF-8 for text); wipe them when done. */
export type Rfc3339 = string;
/** `user:<id>`, `sa:<id>`. */
export type Principal = string;



/**
 * An account on one server: signed out, signed in but locked, or unlocked.
 */
export class Account {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * r" Accepts an invitation.
     */
    acceptInvitation(token: Uint8Array | number[], signal?: any | null): Promise<Member>;
    /**
     * r" The session's access token (UTF-8), refreshed when needed (contract-v1.6). Never log it.
     */
    accessToken(force_refresh: boolean, signal?: any | null): Promise<Uint8Array>;
    /**
     * r" Whether In-App Purchase is possible.
     */
    appleEligibility(org_id?: string | null, signal?: any | null): Promise<AppleEligibility>;
    /**
     * r" One page of an org's audit log.
     */
    auditLog(org_id: string, before?: string | null, limit?: number | null, signal?: any | null): Promise<AuditPage>;
    /**
     * r" What AutoFill saved for a vault and the app hasn't taken yet.
     */
    autofillEdits(vault_id: string): Promise<AutoFillEdits | undefined>;
    /**
     * r" The KDF parameters cached at the last sign-in or unlock.
     */
    cachedKdf(): Promise<KdfParams | undefined>;
    /**
     * r" The vault list from the last successful call, without the network.
     */
    cachedVaults(): Promise<VaultInfo[] | undefined>;
    /**
     * r" Cancels an invitation.
     */
    cancelInvitation(org_id: string, invitation_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Changes the email with the code that was sent.
     */
    changeEmail(email: string, code: string, password: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * Changes the master password; returns the new AUK.
     */
    changePassword(current: Uint8Array | number[], next: Uint8Array | number[], kdf: KdfOverrides | undefined, signal?: any | null): Promise<Uint8Array>;
    /**
     * Changes a member's role on a vault.
     */
    changeRole(vault_id: string, principal: string, role: VaultRole, signal?: any | null): Promise<void>;
    /**
     * r" Asks the server about a parked session.
     */
    checkParkedSession(user_id: string, signal?: any | null): Promise<ParkedCheck>;
    /**
     * Removes AutoFill edits once taken.
     */
    clearAutofillEdits(edits: AutoFillEdits): Promise<void>;
    /**
     * How far this device's clock is ahead of the sync server's (ms).
     */
    clockOffsetMs(): number | undefined;
    /**
     * Confirms an accepted member and grants vaults.
     */
    confirmMember(org_id: string, member: Member, vaults: VaultGrantRequest[], signal?: any | null): Promise<Member>;
    /**
     * r" Confirms two-step setup with a code.
     */
    confirmTwoStep(code: string, signal?: any | null): Promise<void>;
    /**
     * r" Creates an org.
     */
    createOrg(name: string, signal?: any | null): Promise<Org>;
    /**
     * Creates a service account (SPEC §9).
     */
    createServiceAccount(org_id: string, input: NewServiceAccount, signal?: any | null): Promise<CreatedServiceAccount>;
    /**
     * Creates a share link (SPEC §22).
     */
    createShare(payload: SharePayload, options: ShareOptions, signal?: any | null): Promise<CreatedShare>;
    /**
     * r" Creates a vault (SPEC §7, §13).
     */
    createVault(name: string, org_id?: string | null, signal?: any | null): Promise<Vault>;
    /**
     * r" Schedules the account's deletion; returns the erase date.
     */
    deleteAccount(password: Uint8Array | number[], confirm: string, signal?: any | null): Promise<Rfc3339>;
    /**
     * r" Deletes an org.
     */
    deleteOrg(org_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Deletes a service account.
     */
    deleteServiceAccount(sa_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Deletes a vault for everyone (needs `manage`).
     */
    deleteVault(vault_id: string, signal?: any | null): Promise<void>;
    /**
     * r" What deleting the account would do (SPEC §23).
     */
    deletionPreview(signal?: any | null): Promise<DeletionPreview>;
    /**
     * The erase date while the account is pending deletion (SPEC §23).
     */
    deletionScheduledFor(): string | undefined;
    /**
     * r" Signed-in devices.
     */
    devices(signal?: any | null): Promise<Device[]>;
    /**
     * r" Turns two-step sign-in off.
     */
    disableTwoStep(code: string, signal?: any | null): Promise<void>;
    /**
     * The signed-in email.
     */
    email(): string | undefined;
    /**
     * This account's public-key fingerprint (SPEC §5).
     */
    fingerprint(): string;
    /**
     * r" Removes the kept Secret Key and device id for `email`.
     */
    forgetDevice(email: string): Promise<void>;
    /**
     * r" Whether any vault has edits waiting on this device.
     */
    hasAnyPendingEdits(): Promise<boolean>;
    /**
     * r" Whether a vault has edits waiting on this device.
     */
    hasPendingEdits(vault_id: string): Promise<boolean>;
    /**
     * r" Whether this device keeps the Secret Key for `email`.
     */
    hasSecretKey(email: string): Promise<boolean>;
    /**
     * Imports a `.kdbx` into the account (new vault, merge or copies).
     */
    importKdbx(kdbx: Uint8Array | number[], credentials: KdbxCredentials, mode: ImportMode, signal?: any | null): Promise<ImportOutcome>;
    /**
     * Imports an already open vault.
     */
    importVault(source: Vault, mode: ImportMode, signal?: any | null): Promise<ImportOutcome>;
    /**
     * r" An org's open invitations.
     */
    invitations(org_id: string, signal?: any | null): Promise<Invitation[]>;
    /**
     * Invites an email to an org.
     */
    invite(org_id: string, email: string, role: OrgRole, signal?: any | null): Promise<Invitation>;
    /**
     * Working from the offline cache (SPEC §20).
     */
    isOffline(): boolean;
    /**
     * A session is loaded (it may be locked).
     */
    isSignedIn(): boolean;
    /**
     * The keyset is in memory.
     */
    isUnlocked(): boolean;
    /**
     * r" Issues a new secret for a service account.
     */
    issueServiceAccountSecret(sa_id: string, name?: string | null, expires_at?: string | null, signal?: any | null): Promise<IssuedSecret>;
    /**
     * Keeps an entry the AutoFill extension saved, for the app to merge later.
     */
    keepAutofillEdit(vault_id: string, entry: EntryRecord, group_path: string): Promise<void>;
    /**
     * r" Your share links.
     */
    listShares(signal?: any | null): Promise<ShareListing[]>;
    /**
     * Clears the keyset and vault keys from memory. The session stays.
     */
    lock(): void;
    /**
     * OPAQUE sign-in (SPEC §8), then unlock.
     */
    login(input: LoginInput, signal?: any | null): Promise<LoginStep>;
    /**
     * r" Looks a user up by email for sharing.
     */
    lookUp(email: string, signal?: any | null): Promise<ShareRecipient>;
    /**
     * r" The org's vaults an admin manages.
     */
    managedOrgVaults(org_id: string, signal?: any | null): Promise<VaultInfo[]>;
    /**
     * r" `GET /me` (SPEC §16).
     */
    me(signal?: any | null): Promise<Profile>;
    /**
     * r" A vault's members.
     */
    members(vault_id: string, signal?: any | null): Promise<VaultMember[]>;
    /**
     * r" Opens this device's copy of a vault, without AutoFill's edits.
     */
    openCopy(vault_id: string): Promise<Vault>;
    /**
     * r" Opens a vault from this device's copies only, plus AutoFill's edits.
     */
    openOffline(vault_id: string): Promise<Vault>;
    /**
     * Opens one saved version, read-only. `revision` is an integer.
     */
    openVaultVersion(vault_id: string, revision: number, signal?: any | null): Promise<Vault>;
    /**
     * r" Downloads and opens a vault.
     */
    openVault(vault_id: string, signal?: any | null): Promise<Vault>;
    /**
     * r" An org's members.
     */
    orgMembers(org_id: string, signal?: any | null): Promise<Member[]>;
    /**
     * r" One org.
     */
    org(org_id: string, signal?: any | null): Promise<Org>;
    /**
     * r" The orgs this account belongs to (SPEC §12).
     */
    orgs(signal?: any | null): Promise<OrgMembership[]>;
    /**
     * r" Locks and sets this session aside (SPEC §21).
     */
    parkSession(): Promise<boolean>;
    /**
     * r" The account's plan (SPEC §19).
     */
    plan(signal?: any | null): Promise<Plan | undefined>;
    /**
     * `user:<id>`; `signed_out` without a session.
     */
    principal(): Principal;
    /**
     * r" A known principal as a share recipient.
     */
    recipient(principal: string, display?: string | null, signal?: any | null): Promise<ShareRecipient>;
    /**
     * r" Goes back online after working offline.
     */
    reconnect(signal?: any | null): Promise<ReconnectResult>;
    /**
     * r" What a recovery link resets (SPEC §18).
     */
    recoverInfo(token: Uint8Array | number[], signal?: any | null): Promise<RecoveryReset>;
    /**
     * Resets the account from a recovery link (SPEC §18).
     */
    recover(token: Uint8Array | number[], password: Uint8Array | number[], kdf: KdfOverrides | undefined, trust_device: boolean, signal?: any | null): Promise<NewAccount>;
    /**
     * r" Whether an archive from a reset can be restored.
     */
    recoveryStatus(signal?: any | null): Promise<RecoveryStatus>;
    /**
     * Creates an account (SPEC §2, §3, §5, §8). Show the returned Secret Key once.
     */
    register(input: RegisterInput, signal?: any | null): Promise<NewAccount>;
    /**
     * r" Removes a member (rotating the vaults they could open).
     */
    removeMember(org_id: string, user_id: string, signal?: any | null): Promise<RotationReport>;
    /**
     * r" Renames an org.
     */
    renameOrg(org_id: string, name: string, signal?: any | null): Promise<Org>;
    /**
     * r" Renames a vault (needs `manage`).
     */
    renameVault(vault_id: string, name: string, signal?: any | null): Promise<VaultInfo>;
    /**
     * r" Reports an App Store transaction.
     */
    reportAppleTransaction(jws: string, signal?: any | null): Promise<AppleTransactionResult>;
    /**
     * r" Sends a code to a new email address.
     */
    requestEmailChange(email: string, signal?: any | null): Promise<void>;
    /**
     * r" Cancels a scheduled deletion.
     */
    restoreAccount(password: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * r" Restores vaults from the archive with the old credentials.
     */
    restoreFromArchive(old_password: Uint8Array | number[], old_secret_key: Uint8Array | number[], signal?: any | null): Promise<number>;
    /**
     * r" Makes a parked session the active one.
     */
    resumeSession(user_id: string): Promise<boolean>;
    /**
     * r" Unlocks from keyset secrets saved by `unlockedKeysetSecret`.
     */
    resumeUnlocked(keyset_secret: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * r" Signs a device out.
     */
    revokeDevice(device_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Revokes a service-account secret.
     */
    revokeSecret(sa_id: string, secret_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Ends a share link.
     */
    revokeShare(share_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Revokes members from a vault (rotating its key).
     */
    revoke(vault_id: string, principals: string[], signal?: any | null): Promise<SyncReport>;
    /**
     * r" Rotates every vault flagged for rotation.
     */
    rotateFlagged(org_id: string, signal?: any | null): Promise<RotationReport>;
    /**
     * r" Rotates a vault's key, optionally removing principals.
     */
    rotateVaultKey(vault_id: string, remove: string[], signal?: any | null): Promise<SyncReport>;
    /**
     * r" The Secret Key, to show again in settings.
     */
    secretKey(): Promise<Uint8Array | undefined>;
    /**
     * The server's discovery document.
     */
    serverConfig(): ServerConfig;
    /**
     * r" A service account's secrets.
     */
    serviceAccountSecrets(sa_id: string, signal?: any | null): Promise<SaSecretInfo[]>;
    /**
     * r" An org's service accounts.
     */
    serviceAccounts(org_id: string, signal?: any | null): Promise<ServiceAccountInfo[]>;
    /**
     * Promotes or demotes a member.
     */
    setMemberRole(org_id: string, member: Member, role: OrgRole, signal?: any | null): Promise<Member>;
    /**
     * Sets an org's item share-link policy.
     */
    setOrgShareLinks(org_id: string, policy: ShareLinkPolicy, signal?: any | null): Promise<Org>;
    /**
     * Changes a service-account secret's expiry.
     */
    setSecretExpiry(sa_id: string, secret_id: string, expires_at: ExpiryChange, signal?: any | null): Promise<SaSecretInfo>;
    /**
     * The share page's base URL, if the server has one.
     */
    shareBase(): string | undefined;
    /**
     * r" Why share links are blocked for an org (or personal vaults), if they are.
     */
    shareBlockedReason(org_id?: string | null): Promise<string | undefined>;
    /**
     * Shares a vault with a user (SPEC §7).
     */
    shareVault(vault_id: string, grantee: Grantee, role: VaultRole, signal?: any | null): Promise<GrantResult>;
    /**
     * For a page closing on a shared session: locks and returns the logout request to fire.
     */
    signOutOnUnload(): HttpRequest | undefined;
    /**
     * r" Signs a parked session out.
     */
    signOutParked(user_id: string, signal?: any | null): Promise<void>;
    /**
     * r" Signs this device out (and with `forgetDevice` drops the kept Secret Key).
     */
    signOut(forget_device: boolean, signal?: any | null): Promise<void>;
    /**
     * r" Completes the next time the server ends this session. Await it in a loop.
     */
    signedOut(signal?: any | null): Promise<SignedOutReason>;
    /**
     * r" Starts two-step sign-in setup (SPEC §8).
     */
    startTwoStep(signal?: any | null): Promise<TotpSetup>;
    /**
     * r" The Secret Key this device keeps for `email`.
     */
    storedSecretKey(email: string): Promise<Uint8Array | undefined>;
    /**
     * r" The stored session (without tokens).
     */
    storedSession(): Promise<StoredSession | undefined>;
    /**
     * Sends a TOTP code for a waiting sign-in.
     */
    submitTotp(challenge: TotpChallenge, code: string, signal?: any | null): Promise<LoginStep>;
    /**
     * r" Live updates (SPEC §11).
     */
    subscribe(signal?: any | null): Promise<EventStream>;
    /**
     * Syncs an account vault held as `.kdbx` bytes (contract-v1.6).
     */
    syncVaultKdbx(vault_id: string, kdbx: Uint8Array | number[], base: Uint8Array | number[] | null | undefined, options: SyncOptions | undefined, signal?: any | null): Promise<VaultKdbxSyncResult>;
    /**
     * r" Hands a vault to another member before deletion.
     */
    transferVault(vault_id: string, to: string, signal?: any | null): Promise<void>;
    /**
     * r" Unlocks with an AUK kept behind biometrics.
     */
    unlockWithAuk(auk: Uint8Array | number[], signal?: any | null): Promise<void>;
    /**
     * r" Unlocks a signed-in session with the master password (offline: from the cache).
     */
    unlock(password: Uint8Array | number[], secret_key?: Uint8Array | number[] | null, signal?: any | null): Promise<Unlocked>;
    /**
     * The unlocked keyset's private halves (64 bytes), for the web's `sealUnlocked`.
     */
    unlockedKeysetSecret(): Uint8Array;
    /**
     * Updates a service account.
     */
    updateServiceAccount(sa_id: string, update: ServiceAccountUpdate, signal?: any | null): Promise<ServiceAccountInfo>;
    /**
     * The upgrade page for a `plan_limit` / `quota_exceeded` error.
     */
    upgradeUrl(error: OvError): string | undefined;
    /**
     * The signed-in user's id.
     */
    userId(): string | undefined;
    /**
     * r" The saved versions of a vault, newest first.
     */
    vaultHistory(vault_id: string, signal?: any | null): Promise<VaultVersion[]>;
    /**
     * r" The credentials an account vault's `.kdbx` is under (contract-v1.6). Wipe them.
     */
    vaultKdbxCredentials(vault_id: string, signal?: any | null): Promise<KdbxCredentials>;
    /**
     * r" A vault's storage quota in bytes.
     */
    vaultQuota(vault_id: string): Promise<number | undefined>;
    /**
     * r" Every vault this account can open (SPEC §7).
     */
    vaults(signal?: any | null): Promise<VaultInfo[]>;
    /**
     * r" A principal's public keys, verified.
     */
    verifiedPublicKeys(principal: string, signal?: any | null): Promise<PublicKeys>;
    /**
     * r" Asks the server whether this device's session still stands.
     */
    verifySession(signal?: any | null): Promise<void>;
    /**
     * r" A one-time URL that signs the web app in.
     */
    webSessionUrl(next?: string | null, signal?: any | null): Promise<Uint8Array>;
}

/**
 * Live updates: `await next()` in a loop until it resolves `undefined`.
 */
export class EventStream {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Closes the stream.
     */
    close(): void;
    /**
     * The next event, or `undefined` once closed.
     */
    next(signal?: any | null): Promise<AccountEvent | undefined>;
    /**
     * Reconnects now (e.g. after the page comes back online).
     */
    reconnect(): void;
}

/**
 * One decrypted KDBX database. `Kdbx.read(bytes, key)` → inspect, merge, import → `write()`.
 * `free()` drops it (the decrypted model lives in the module's memory until then).
 */
export class Kdbx {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Switches to the vault KDF (Argon2id, 1 GiB… as `VAULT_KDF`).
     */
    applyVaultKdf(): void;
    /**
     * A deep copy (with the same key).
     */
    clone(): Kdbx;
    /**
     * A new vault database keyed with a 32-byte vault key (ChaCha20, the vault KDF).
     */
    static createVault(name: string, vault_key: Uint8Array | number[], now_secs?: number | null): Kdbx;
    /**
     * A new, empty database named `name` (KDBX 4, AES, Argon2d). Set a key with `setKey` before `write()`.
     */
    static create(name: string, now_secs?: number | null): Kdbx;
    /**
     * Removes the desktop's sync-server remotes from the database settings (an imported file).
     */
    dropServerRemotes(): void;
    /**
     * Every entry (Recycle Bin included), depth first, as the SDK's `collectAllDbData`.
     */
    entries(): KdbxEntryInfo[];
    /**
     * Conflicts between this (local) copy and `remote` since `snapshot` (SDK `findConflicts`).
     */
    findConflicts(remote: Kdbx, snapshot: KdbxSnapshot): KdbxSyncConflict[];
    /**
     * Every group, depth first.
     */
    groups(): KdbxGroupInfo[];
    /**
     * Whether either side has deletions the other hasn't seen (SDK `hasPendingDeletions`).
     */
    hasPendingDeletions(remote: Kdbx): boolean;
    /**
     * The outer-header settings it is saved with.
     */
    header(): KdbxHeaderInfo;
    /**
     * Imports `source`'s entries as new copies under the group `parentId` (SDK `importAsCopies`).
     */
    importAsCopies(source: Kdbx, parent_id: string, now_secs?: number | null): KdbxImportSummary;
    /**
     * Imports `source` by UUID, keeping newer versions and deleting nothing (SDK `importInto`).
     */
    importFrom(source: Kdbx): KdbxImportSummary;
    /**
     * Where entries can be imported to: `{ uuid, path }` for every group outside the Recycle Bin.
     */
    importTargets(): { uuid: string; path: string }[];
    /**
     * The KDF settings the database is saved with.
     */
    kdfSettings(): KdbxKdfSettings;
    /**
     * The one-way structure merge of `source` into this database (SDK `mergeInto`).
     */
    mergeFrom(source: Kdbx, mode?: MergeMode, opts?: MergeIntoOptions): KdbxMergeChange[];
    /**
     * The sync merge against `base`, the copy both last synced from.
     */
    mergeWithBase(remote: Kdbx, base: Kdbx, now_secs?: number | null): KdbxMergeReport;
    /**
     * The sync merge (SDK `mergeDatabases`) without a base: both copies end up with the same entries.
     */
    merge(remote: Kdbx, now_secs?: number | null): KdbxMergeReport;
    /**
     * Whether the merge needs the common base (SDK `needsCommonBase`).
     */
    needsCommonBase(remote: Kdbx, snapshot: KdbxSnapshot): boolean;
    /**
     * Opens a vault with the newest of its key versions that fits (SPEC §7): `{ db, keyVersion }`.
     */
    static openWithKeyVersions(bytes: Uint8Array | number[], keys: KdbxKeyVersion[]): { db: Kdbx; keyVersion: number };
    /**
     * The outer header's settings, without the key.
     */
    static peekHeader(bytes: Uint8Array | number[]): KdbxHeaderInfo;
    /**
     * Opens a KDBX 3.1 or 4.x file. `vault_key_mismatch` for a wrong key, `kdbx_error` for a file
     * that isn't KDBX or is corrupt or unsupported. The key is kept for `write()`.
     */
    static read(bytes: Uint8Array | number[], key: KdbxKey): Kdbx;
    /**
     * Re-keys to a vault key: the vault KDF, and the vault key as the key from now on.
     */
    rekeyToVaultKey(vault_key: Uint8Array | number[]): void;
    /**
     * Replaces the key `write()` uses.
     */
    setKey(key: KdbxKey): void;
    /**
     * Sets the sync generation.
     */
    setSyncGeneration(generation: number, now_secs?: number | null): void;
    /**
     * The snapshot to keep after a sync (SDK `snapshotOf`).
     */
    snapshot(): KdbxSnapshot;
    /**
     * The sync generation in the custom data (0 when absent).
     */
    syncGeneration(): number;
    /**
     * Saves as KDBX 4 with `key`, or the key it was read or created with.
     */
    write(key?: KdbxKey): Uint8Array;
    /**
     * The database name (Meta).
     */
    readonly name: string;
    /**
     * The root group's id.
     */
    readonly rootGroupId: string;
}

/**
 * The entry point: one per app (or per test). `new OvClient(config, host)`.
 */
export class OvClient {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * The settings this client was made with.
     */
    config(): ClientConfig;
    /**
     * Discovers the server and loads a stored session (signed in but locked).
     */
    connect(issuer: string, signal?: any | null): Promise<Account>;
    /**
     * Creates a new local database on this client's Host clock (contract-v1.6).
     */
    createLocal(name: string, credentials: KdbxCredentials, signal?: any | null): Promise<Vault>;
    /**
     * Fetches and checks the discovery document (SPEC §10).
     */
    discover(issuer: string, signal?: any | null): Promise<ServerConfig>;
    /**
     * Removes an account from the remembered list.
     */
    forgetRemembered(issuer: string, user_id: string): Promise<void>;
    /**
     * Whether a user's offline cache holds edits not yet uploaded.
     */
    hasPendingEdits(user_id: string): Promise<boolean>;
    /**
     * Records that the server confirmed the account's parked session now.
     */
    markRememberedChecked(issuer: string, user_id: string): Promise<void>;
    /**
     * A client over `host` (see `host/` in the package for ready-made adapters). Does no I/O.
     */
    constructor(config: ClientConfig, host: Host);
    /**
     * Opens a local `.kdbx`; edits are stamped with this client's Host clock (contract-v1.6).
     */
    openLocal(kdbx: Uint8Array | number[], credentials: KdbxCredentials, signal?: any | null): Promise<Vault>;
    /**
     * Opens a share link (SPEC §22).
     */
    openShare(api: string, link: Uint8Array | number[], passcode: Uint8Array | number[] | null | undefined, info: ShareInfo | undefined, signal?: any | null): Promise<OpenedShare>;
    /**
     * Adds or refreshes a remembered account.
     */
    rememberAccount(email: string, issuer: string, user_id: string): Promise<void>;
    /**
     * Remembered accounts, most recently used first (SPEC §21).
     */
    rememberedAccounts(): Promise<RememberedAccount[]>;
    /**
     * Active, parked or no session for a user on this device (no network).
     */
    sessionState(issuer: string, user_id: string): Promise<SessionState>;
    /**
     * Records (or clears) a remembered account's erase date (SPEC §23).
     */
    setRememberedDeletion(issuer: string, user_id: string, at?: string | null): Promise<void>;
    /**
     * What the public share page knows before opening a share (SPEC §22).
     */
    shareInfo(api: string, share_id: string, signal?: any | null): Promise<ShareInfo>;
}

/**
 * A self-hosted sync server (SPEC §13).
 */
export class SelfHosted {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Connects with a device token.
     */
    static connect(client: OvClient, server_url: string, device_token: Uint8Array | number[]): SelfHosted;
    /**
     * A code to pair another device.
     */
    createPairingCode(signal?: any | null): Promise<PairingCode>;
    /**
     * Live updates from the server.
     */
    events(signal?: any | null): Promise<EventStream>;
    /**
     * The server's health text.
     */
    health(signal?: any | null): Promise<string>;
    /**
     * The versions the server keeps of a database, newest first (contract-v1.6).
     */
    history(database_id: string, signal?: any | null): Promise<VaultVersion[]>;
    /**
     * The databases on the server.
     */
    listDatabases(signal?: any | null): Promise<BlobMeta[]>;
    /**
     * Opens one kept version of a database, read-only (contract-v1.6).
     */
    openVersion(database_id: string, revision: number, credentials: KdbxCredentials, signal?: any | null): Promise<Vault>;
    /**
     * Pairs this device with a pairing code.
     */
    static pair(client: OvClient, server_url: string, code: string, device_name: string, signal?: any | null): Promise<SelfHosted>;
    /**
     * Reconnects with the device token kept in the secure store.
     */
    static restore(client: OvClient, server_url: string): Promise<SelfHosted | undefined>;
    /**
     * The server URL.
     */
    serverUrl(): string;
    /**
     * `syncDatabase` with options: `localChanged: false` checks with a HEAD first and, when the
     * server is unchanged, returns `kdbx` as it is (contract-v1.7).
     */
    syncDatabaseWith(database_id: string, kdbx: Uint8Array | number[], credentials: KdbxCredentials, options: SyncOptions, signal?: any | null): Promise<SelfHostedSyncResult>;
    /**
     * Syncs a local `.kdbx` with the server's copy.
     */
    syncDatabase(database_id: string, kdbx: Uint8Array | number[], credentials: KdbxCredentials, signal?: any | null): Promise<SelfHostedSyncResult>;
}

/**
 * A service account signed in with its token (SPEC §9, §15).
 */
export class ServiceAccount {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Drops the keys from memory.
     */
    close(): void;
    /**
     * Signs in with a service-account token.
     */
    static fromToken(client: OvClient, token: Uint8Array | number[], signal?: any | null): Promise<ServiceAccount>;
    /**
     * Replaces `ov://` references in a template.
     */
    inject(template: Uint8Array | number[], signal?: any | null): Promise<Injected>;
    /**
     * The server's issuer (contract-v1.6).
     */
    issuer(): string;
    /**
     * Opens a vault by id or name.
     */
    openVault(id_or_name: string, refresh: boolean, signal?: any | null): Promise<Vault>;
    /**
     * `sa:<id>`.
     */
    principal(): string;
    /**
     * Opens a vault, always downloading it.
     */
    pull(id_or_name: string, signal?: any | null): Promise<Vault>;
    /**
     * Reads a secret by reference.
     */
    read(reference: string, signal?: any | null): Promise<Uint8Array>;
    /**
     * The service account's id.
     */
    saId(): string;
    /**
     * The server it signed in to (contract-v1.6).
     */
    serverConfig(): ServerConfig;
    /**
     * One vault by id or name.
     */
    vault(id_or_name: string, signal?: any | null): Promise<SaVault>;
    /**
     * The vaults it can open.
     */
    vaults(refresh: boolean, signal?: any | null): Promise<SaVault[]>;
    /**
     * Writes a secret by reference.
     */
    write(reference: string, value: Uint8Array | number[], create: boolean, signal?: any | null): Promise<void>;
}

/**
 * A share link being opened (the TS `openShare` minus HTTP): built from the link, the share's
 * public `kdf` (when it has a passcode) and the passcode, so the Argon2 work happens once. Send
 * `requestBody()` to `POST {api}/public/shares/{id}/open`, then `decrypt` the returned `ct`.
 * `free()` wipes the keys.
 */
export class ShareOpen {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Decrypts the share's `ct` (bytes, or base64url as the server sends it).
     */
    decrypt(ct: Uint8Array | string): SharePayload;
    /**
     * `passcode_required` when the share has a `kdf` and no passcode is given, `weak_kdf` below the
     * SPEC minimum, `invalid_link` for a bad link.
     */
    constructor(link: string | Uint8Array, kdf?: KdfParams, passcode?: string | Uint8Array);
    /**
     * The JSON body of the open request (UTF-8): `{"auth":"…"}` or `{}`.
     */
    requestBody(): Uint8Array;
    /**
     * `auth` (base64url) when the share has a passcode.
     */
    readonly auth: Uint8Array | undefined;
    /**
     * The link's base (the share page).
     */
    readonly base: string;
    /**
     * The share id.
     */
    readonly id: string;
}

/**
 * A sign-in waiting for a TOTP code. Pass it to `Account.submitTotp`.
 */
export class TotpChallenge {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Which try this is, from 1.
     */
    attempt(): number;
    /**
     * The previous wrong code's error (`invalid_mfa`), if any.
     */
    lastError(): OvError | undefined;
}

/**
 * One open vault: an account vault, a local file, or a read-only saved version.
 */
export class Vault {
    private constructor();
    free(): void;
    [Symbol.dispose](): void;
    /**
     * r" Adds a custom icon; returns its id.
     */
    addCustomIcon(png: Uint8Array | number[]): string;
    /**
     * Adds an entry with an id the caller chose; returns it normalized (contract-v1.6).
     */
    addEntryWithId(entry_id: string, group_id: string, input: EntryInput): string;
    /**
     * Adds an entry; returns its id.
     */
    addEntry(group_id: string, input: EntryInput): string;
    /**
     * r" Adds a group; returns its id.
     */
    addGroup(parent_id: string | null | undefined, name: string): string;
    /**
     * Merges AutoFill's edits into this vault.
     */
    applyAutofillEdits(edits: AutoFillEdits): boolean;
    /**
     * r" An attachment's bytes.
     */
    attachment(entry_id: string, name: string): Uint8Array;
    /**
     * Conflicts from the last sync.
     */
    conflicts(): SyncConflict[];
    /**
     * A local copy without sync-server remotes; `credentials` default to a local file's own
     * (contract-v1.6).
     */
    copyWithoutRemotes(credentials: KdbxCredentials | undefined): Vault;
    /**
     * Creates a new local database.
     */
    static createLocal(name: string, credentials: KdbxCredentials, signal?: any | null): Promise<Vault>;
    /**
     * r" A custom icon's PNG bytes.
     */
    customIcon(icon_id: string): Uint8Array;
    /**
     * r" Deletes an entry (to the Recycle Bin when enabled).
     */
    deleteEntry(entry_id: string): undefined;
    /**
     * r" Deletes a group.
     */
    deleteGroup(group_id: string): undefined;
    /**
     * Edits an entry (keeping a history copy).
     */
    editEntry(entry_id: string, input: EntryInput): undefined;
    /**
     * r" Empties the Recycle Bin.
     */
    emptyRecycleBin(): undefined;
    /**
     * r" The group at a path, creating missing groups; returns its id.
     */
    ensureGroup(path: string): string;
    /**
     * Every entry (optionally including the Recycle Bin).
     */
    entries(include_recycle_bin: boolean): EntrySummary[];
    /**
     * Every entry with its values (contract-v1.6).
     */
    entryRecords(include_recycle_bin: boolean): EntryRecord[];
    /**
     * r" One entry by id.
     */
    entry(entry_id: string): EntryRecord;
    /**
     * The ETag of the last sync.
     */
    etag(): string | undefined;
    /**
     * Exports as a `.kdbx` with a chosen key derivation (contract-v1.6).
     */
    exportKdbxWith(credentials: KdbxCredentials, group_ids: string[] | null | undefined, kdf: KdbxKdf, signal?: any | null): Promise<Uint8Array>;
    /**
     * Exports as a `.kdbx` under new credentials (optionally only some groups).
     */
    exportKdbx(credentials: KdbxCredentials, group_ids?: string[] | null, signal?: any | null): Promise<Uint8Array>;
    /**
     * Exports in the clear (CSV or JSON).
     */
    exportPlain(format: ExportFormat, group_ids?: string[] | null): Uint8Array;
    /**
     * r" One entry by reference (`ov://vault/item/field`, id or title).
     */
    find(reference: string): EntryRecord;
    /**
     * The group at a `/`-separated path.
     */
    groupIdAt(path: string): string | undefined;
    /**
     * Every group.
     */
    groups(): GroupInfo[];
    /**
     * Whether this vault has edits waiting for its next upload.
     */
    hasPendingEdits(): Promise<boolean>;
    /**
     * r" An entry's history, oldest first.
     */
    history(entry_id: string): EntryRecord[];
    /**
     * The vault id (or the local database's id).
     */
    id(): string;
    /**
     * Imports another open vault into this one (contract-v1.6).
     */
    importFrom(source: Vault, mode: LocalImportMode): ImportSummary;
    /**
     * What importing this vault elsewhere would bring in (contract-v1.6).
     */
    importPreview(): ImportPreview;
    /**
     * The groups an import can go into (contract-v1.6).
     */
    importTargets(): ImportTarget[];
    /**
     * The account vault's info (`undefined` for a local file).
     */
    info(): VaultInfo | undefined;
    /**
     * Whether an entry or group is in the Recycle Bin.
     */
    isInRecycleBin(id: string): boolean;
    /**
     * Opened from this device's copy because the server couldn't be reached.
     */
    isOffline(): boolean;
    /**
     * A saved version, or a vault this account can only read.
     */
    isReadOnly(): boolean;
    /**
     * Keeps local edits in the offline cache without syncing.
     */
    keepEdits(): Promise<void>;
    /**
     * A database custom data value (contract-v1.6).
     */
    metaCustomData(key: string): string | undefined;
    /**
     * r" Moves an entry to another group.
     */
    moveEntry(entry_id: string, group_id: string): undefined;
    /**
     * r" Moves a group.
     */
    moveGroup(group_id: string, parent_id: string): undefined;
    /**
     * The vault's name.
     */
    name(): string;
    /**
     * Opens a local `.kdbx`.
     */
    static openLocal(kdbx: Uint8Array | number[], credentials: KdbxCredentials, signal?: any | null): Promise<Vault>;
    /**
     * r" One field's value by reference.
     */
    readField(reference: string): Uint8Array;
    /**
     * r" Removes an attachment.
     */
    removeAttachment(entry_id: string, name: string): undefined;
    /**
     * r" Renames a group.
     */
    renameGroup(group_id: string, name: string): undefined;
    /**
     * Restores an entry from a saved version.
     */
    restoreEntry(version: Vault, entry_id: string, group_path: string): undefined;
    /**
     * r" Restores an entry or group from the Recycle Bin.
     */
    restoreFromRecycleBin(id: string): undefined;
    /**
     * The root group's id.
     */
    rootGroupId(): string;
    /**
     * Encrypts a local database for saving.
     */
    saveLocal(signal?: any | null): Promise<Uint8Array>;
    /**
     * r" Adds or replaces an attachment with its protected flag; `undefined` keeps the replaced one's
     * r" (contract-v1.6).
     */
    setAttachmentWith(entry_id: string, name: string, data: Uint8Array | number[], _protected?: boolean | null): undefined;
    /**
     * r" Adds or replaces an attachment.
     */
    setAttachment(entry_id: string, name: string, data: Uint8Array | number[]): undefined;
    /**
     * Sets several fields of an entry found by reference.
     */
    setFields(reference: string, fields: FieldInput[], create: CreateMode): SetFieldsResult;
    /**
     * r" Sets a group's icon.
     */
    setGroupIcon(group_id: string, icon_id: number): undefined;
    /**
     * Sets a local database's key derivation (contract-v1.6).
     */
    setKdf(kdf: KdbxKdf): undefined;
    /**
     * r" Sets (a string) or removes (`undefined`) a database custom data item (contract-v1.6).
     */
    setMetaCustomData(key: string, value?: string | null): undefined;
    /**
     * r" Renames a local database (contract-v1.6).
     */
    setName(name: string): undefined;
    /**
     * Syncs with the server (SPEC §11).
     */
    sync(options: SyncOptions | undefined, signal?: any | null): Promise<SyncReport>;
    /**
     * How an entry differs between this vault and a saved version.
     */
    versionDifference(version: Vault, entry_id: string): VersionDifference;
    /**
     * Writes one field and syncs (TS `AccountVault.write`).
     */
    writeField(reference: string, value: Uint8Array | number[], create: boolean, signal?: any | null): Promise<SyncReport>;
}

/**
 * Called once by `index.js` at load: the `OvError` class to construct errors with, and the
 * callback a panic reports to before the module traps.
 */
export function __install(error_class: Function, on_panic: Function): void;

/**
 * Zeroes the shadow stack below the caller (where the frames of the call that just returned were).
 * Hidden from the loaded API; the loaders call it.
 */
export function __scrubStack(): void;

/**
 * Test hook: panics synchronously, so the loader's panic handling can be tested. Hidden from the
 * loaded API.
 */
export function __testPanic(message: string): void;

/**
 * Test hook: panics inside a future, so the loader's async panic handling can be tested. Hidden
 * from the loaded API.
 */
export function __testPanicAsync(message: string): Promise<any>;

/**
 * XChaCha20-Poly1305 decryption; `decryption_failed` on a wrong key or tampered input.
 */
export function aeadDecrypt(key: Uint8Array | number[], nonce: Uint8Array | number[], ciphertext: Uint8Array | number[], aad: Uint8Array | number[]): Uint8Array;

/**
 * XChaCha20-Poly1305 encryption: 32-byte key, 24-byte nonce; returns ciphertext ‖ tag.
 */
export function aeadEncrypt(key: Uint8Array | number[], nonce: Uint8Array | number[], plaintext: Uint8Array | number[], aad: Uint8Array | number[]): Uint8Array;

/**
 * Argon2d, Argon2i or Argon2id (version 0x13) with any output length (KDBX files, the SDK's
 * `argon2()`). `weak_kdf` for parameters Argon2 refuses. No minimum-cost check: see `checkKdfParams`.
 */
export function argon2(params: Argon2Params): Uint8Array;

/**
 * Argon2id (v0x13), 32-byte output. `m` in KiB.
 */
export function argon2id(password: Uint8Array | number[], salt: Uint8Array | number[], m: number, t: number, p: number): Uint8Array;

/**
 * RFC 4648 base32 (as TOTP secrets are written): case-insensitive, white space, `=` and `-`
 * ignored; `invalid_totp` otherwise. The SDK's `base32Decode`. The result may be a secret: wipe it.
 */
export function base32Decode(text: string | Uint8Array): Uint8Array;

/**
 * `ov_sa_<base64url JSON>` (UTF-8).
 */
export function buildSaToken(p: SaTokenParts): Uint8Array;

/**
 * Refuses parameters below `min` (default the SPEC floor m = 19456, t = 2) or not Argon2id: `weak_kdf`.
 */
export function checkKdfParams(kdf: KdfParams, min?: KdfMin): void;

/**
 * Decodes a JWT without verifying it: `{ header, claims }`. `invalid_token` when malformed.
 */
export function decodeJwt(token: string | Uint8Array): { header: Record<string, unknown>; claims: AccessClaims };

/**
 * Decrypts a share's `ct` bytes; `decryption_failed` for a wrong key, passcode or id.
 */
export function decryptSharePayload(key: Uint8Array | number[], id: string, ct: Uint8Array | number[], passcode_key?: Uint8Array | number[] | null): SharePayload;

/**
 * Decrypts an owner's reference.
 */
export function decryptShareRef(enc_sk: Uint8Array | number[], id: string, reference: string): ShareRef;

/**
 * Decrypts a vault name.
 */
export function decryptVaultName(vault_key: Uint8Array | number[], vault_id: string, encrypted_name: string): string;

/**
 * The fields an item share includes by default.
 */
export function defaultShareFields(): string[];

/**
 * Whether a remembered account's erase date is more than a day past.
 */
export function deletionExpired(scheduled_for: string | null | undefined, now_ms: number): boolean;

/**
 * The Account Unlock Key: HKDF(stretched password, salt = Secret Key, "ov-auk-v1") (SPEC §3).
 */
export function deriveAuk(password: string | Uint8Array, kdf: KdfParams, secret_key: Uint8Array | number[], opts?: DeriveAukOptions): Uint8Array;

/**
 * The Ed25519 public key of a 32-byte seed.
 */
export function ed25519PublicKey(seed: Uint8Array | number[]): Uint8Array;

/**
 * An Ed25519 signature (64 bytes) of `message` with a 32-byte seed.
 */
export function ed25519Sign(message: Uint8Array | number[], seed: Uint8Array | number[]): Uint8Array;

/**
 * Whether `sig` is a valid (strict) Ed25519 signature of `message` by `pk`. Never throws.
 */
export function ed25519Verify(sig: Uint8Array | number[], message: Uint8Array | number[], pk: Uint8Array | number[]): boolean;

/**
 * Encrypts a payload under the link key (and passcode key): the share's `ct` bytes. `nonce` is
 * for test vectors only. `too_large` past 64 KiB.
 */
export function encryptSharePayload(key: Uint8Array | number[], id: string, payload: SharePayload, passcode_key?: Uint8Array | number[] | null, nonce?: Uint8Array | number[] | null): Uint8Array;

/**
 * Encrypts the owner's reference (`{vault, entry, title}`) to base64url. `nonce` for test vectors only.
 */
export function encryptShareRef(enc_sk: Uint8Array | number[], id: string, reference: ShareRef, nonce?: Uint8Array | number[] | null): string;

/**
 * Encrypts a vault name (base64url, SPEC §7).
 */
export function encryptVaultName(vault_key: Uint8Array | number[], vault_id: string, name: string, nonce?: Uint8Array | number[] | null): string;

/**
 * An entry's TOTP URI from its fields (`otp`, or KeePass's `TOTP Seed`/`TOTP Settings`).
 */
export function entryTotpUri(fields: { fields: FieldRecord[] } | FieldRecord[], label: string): Uint8Array | undefined;

/**
 * The fingerprint `xxxx xxxx …` (first 20 bytes of SHA-256(encPk ‖ signPk), hex in groups).
 */
export function fingerprint(enc_pk: Uint8Array | number[], sign_pk: Uint8Array | number[]): string;

/**
 * The display form `K1-XXXXXX-…` (UTF-8).
 */
export function formatSecretKey(raw: Uint8Array | number[]): Uint8Array;

/**
 * A fresh random keyset.
 */
export function generateKeyset(): Keyset;

/**
 * A fresh 16-byte Secret Key (SPEC §2).
 */
export function generateSecretKey(): Uint8Array;

/**
 * HKDF-SHA256 (RFC 5869) with `length` output bytes (at most 8160).
 */
export function hkdfSha256(ikm: Uint8Array | number[], salt: Uint8Array | number[], info: Uint8Array | number[], length: number): Uint8Array;

/**
 * Whether a token looks like a JWT (three dot-separated parts).
 */
export function isJwt(token: string | Uint8Array): boolean;

/**
 * The payload of an item share with the named fields.
 */
export function itemSharePayload(entry: { fields: FieldRecord[] } | FieldRecord[], names: string[], shared_by?: string | null): SharePayload;

/**
 * The sync merge on file bytes: reads `local`, `remote` and `base` (when given) with `key`, merges,
 * and writes both copies back with the same key. `{ local, remote, report }`; upload `remote` when
 * `report.remoteChanged`.
 */
export function kdbxMerge(local: Uint8Array | number[], remote: Uint8Array | number[], base: Uint8Array | number[] | null | undefined, key: KdbxKey, now_secs?: number | null): { local: Uint8Array; remote: Uint8Array; report: KdbxMergeReport };

/**
 * SHA-256 of a password as KDBX uses it (the SDK's `passwordHash`).
 */
export function kdbxPasswordHash(password: string | Uint8Array): Uint8Array;

/**
 * The keyset of two 32-byte secrets (computes and signs the public keys).
 */
export function keysetFromSecrets(enc_sk: Uint8Array | number[], sign_seed: Uint8Array | number[]): Keyset;

/**
 * KDF parameters for a new account: the defaults (m = 64 MiB, t = 3, p = 1) with any overrides,
 * and a random salt.
 */
export function newKdfParams(overrides?: KdfOverrides): KdfParams;

/**
 * A fresh `ov_rt_…` refresh token (UTF-8).
 */
export function newRefreshToken(): Uint8Array;

/**
 * A new SA secret: the token and the request body.
 */
export function newSaSecret(p: NewSaSecretInput): NewSaSecret;

/**
 * A fresh 32-byte link key.
 */
export function newShareKey(): Uint8Array;

/**
 * Client login step 2: `authU` for `/auth/login/finish`. `opaque_failed` ("wrong password") for a
 * wrong password or the fake record of an unknown email. Consumes `state`.
 */
export function opaqueFinishLogin(state: Uint8Array | number[], ke2: Uint8Array | number[], ids: OpaqueIds, context?: string | null, seed?: Uint8Array | number[] | null): OpaqueLoginFinish;

/**
 * Client registration step 2: the `record` for `/auth/register/finish`. Consumes `state`.
 */
export function opaqueFinishRegistration(state: Uint8Array | number[], response: Uint8Array | number[], ids: OpaqueIds, seed?: Uint8Array | number[] | null): OpaqueRegistrationFinish;

/**
 * `{ idU, idS }` from an email and the issuer URL or host.
 */
export function opaqueIds(email: string, issuer_or_host: string): OpaqueIds;

/**
 * Test server: `ke2` and the login state `sec`.
 */
export function opaqueServerCredentialResponse(ke1: Uint8Array | number[], stored_record: Uint8Array | number[], ids: OpaqueIds, context?: string | null, seed?: Uint8Array | number[] | null): { ke2: Uint8Array; sec: Uint8Array };

/**
 * Test server: the registration response, and `sec` (a new per-user `ServerSetup`).
 */
export function opaqueServerRegistrationResponse(request: Uint8Array | number[], seed?: Uint8Array | number[] | null): { sec: Uint8Array; response: Uint8Array };

/**
 * Test server: the stored record (`sec` ‖ the client's registration upload).
 */
export function opaqueServerStoreRecord(sec: Uint8Array | number[], record: Uint8Array | number[]): Uint8Array;

/**
 * Test server: checks `authU`; the server's session key, or `undefined` when it is wrong.
 */
export function opaqueServerUserAuth(sec: Uint8Array | number[], auth_u: Uint8Array | number[]): Uint8Array | undefined;

/**
 * Client login step 1: `ke1` for `/auth/login/start`.
 */
export function opaqueStartLogin(password: string | Uint8Array, seed?: Uint8Array | number[] | null): OpaqueLoginStart;

/**
 * Client registration step 1: `request` for `/auth/register/start`.
 */
export function opaqueStartRegistration(password: string | Uint8Array, seed?: Uint8Array | number[] | null): OpaqueRegistrationStart;

/**
 * Opens a share in one step from its link, `kdf`, passcode and the fetched `ct` (base64url).
 */
export function openShareContent(link: string | Uint8Array, kdf: KdfParams | undefined, passcode: string | Uint8Array | undefined, ct: string): SharePayload;

/**
 * Pads share content to a multiple of 512 bytes (`0x80` then zeroes).
 */
export function padShare(data: Uint8Array | number[]): Uint8Array;

/**
 * Parses a service account token; `invalid_token`.
 */
export function parseSaToken(token: string | Uint8Array): SaTokenParts;

/**
 * Parses a displayed Secret Key; `invalid_secret_key` when it is malformed.
 */
export function parseSecretKey(display: string | Uint8Array): Uint8Array;

/**
 * Splits a share link; `invalid_link` when it isn't a complete one.
 */
export function parseShareLink(link: string | Uint8Array): ShareLinkParts;

/**
 * Parses an `otpauth://totp/` URI (KeePassXC's `otp` field).
 */
export function parseTotpUri(uri: string | Uint8Array): TotpParams;

/**
 * UTF-8 of the NFKC-normalised password (SPEC §3; also the OPAQUE input).
 */
export function passwordBytes(password: string | Uint8Array): Uint8Array;

/**
 * Decodes server JSON (no signature check; see `trustedPublicKeys`). `invalid_public_keys`.
 */
export function publicKeysFromJson(j: PublicKeysJson): PublicKeys;

/**
 * Public keys as server JSON.
 */
export function publicKeysToJson(_public: PublicKeys): PublicKeysJson;

/**
 * `n` bytes from the platform CSPRNG (`crypto.getRandomValues`).
 */
export function randomBytes(n: number): Uint8Array;

/**
 * Hex SHA-256 of a refresh token.
 */
export function refreshTokenHash(token: string | Uint8Array): string;

/**
 * Re-seals an archived vault key to the current keyset.
 */
export function resealVaultKey(old_enc_sk: Uint8Array | number[], current_enc_pk: Uint8Array | number[], vault_id: string, sealed: Uint8Array | number[], opts?: SealOptions): Uint8Array;

/**
 * The restore proof: the archived keyset's Ed25519 signature over the message.
 */
export function restoreProof(old_sign_seed: Uint8Array | number[], user_id: string, current_keys: CurrentKeys): Uint8Array;

/**
 * `"ov-restore-v1" ‖ userId ‖ encPk ‖ signPk` (SPEC §18).
 */
export function restoreProofMessage(user_id: string, current_keys: CurrentKeys): Uint8Array;

/**
 * Hex SHA-256 of an SA secret (what the server stores).
 */
export function saSecretHash(secret: Uint8Array | number[]): string;

/**
 * The first 8 base64url characters of an SA secret (shown in lists).
 */
export function saSecretPrefix(secret: Uint8Array | number[]): string;

/**
 * Seals to an X25519 public key (SPEC §6); `low_order_point` for a bad key.
 */
export function seal(recipient_enc_pk: Uint8Array | number[], plaintext: Uint8Array | number[], aad: string, opts?: SealOptions): Uint8Array;

/**
 * The derived key of a sealed blob (for vectors and debugging).
 */
export function sealDerivedKey(recipient_enc_sk: Uint8Array | number[], sealed: Uint8Array | number[]): Uint8Array;

/**
 * Seals a service account's master key (AAD `ov-sa-master-v1|<saId>`).
 */
export function sealSaMaster(recipient_enc_pk: Uint8Array | number[], sa_id: string, master: Uint8Array | number[], opts?: SealOptions): Uint8Array;

/**
 * Seals a vault key (AAD `ov-vault-key|<vaultId>`).
 */
export function sealVaultKey(recipient_enc_pk: Uint8Array | number[], vault_id: string, vault_key: Uint8Array | number[], opts?: SealOptions): Uint8Array;

/**
 * SHA-256.
 */
export function sha256(data: Uint8Array | number[]): Uint8Array;

/**
 * The `auth` value a passcode share's open request sends: HKDF(passcodeKey, "ov-share-auth-v1").
 */
export function shareAuth(passcode_key: Uint8Array | number[]): Uint8Array;

/**
 * SHA-256 of `auth` (what the server stores).
 */
export function shareAuthHash(auth: Uint8Array | number[]): Uint8Array;

/**
 * HKDF(key, salt = passcodeKey or empty, "ov-share-v1"): the content key.
 */
export function shareContentKey(key: Uint8Array | number[], passcode_key?: Uint8Array | number[] | null): Uint8Array;

/**
 * The link key from a URL fragment (`#…` or without the `#`).
 */
export function shareKeyFromHash(hash: string | Uint8Array): Uint8Array;

/**
 * `<base>/<id>#<base64url key>` (UTF-8).
 */
export function shareLink(base: string, id: string, key: Uint8Array | number[]): Uint8Array;

/**
 * Argon2id of the NFKC passcode with the share's `kdf` (SPEC §22). `weak_kdf` below the SPEC §3
 * minimum unless `allowWeak` (test vectors only).
 */
export function sharePasscodeKey(passcode: string | Uint8Array, kdf: KdfParams, allow_weak?: boolean | null): Uint8Array;

/**
 * HKDF(encSk, "ov-share-ref-v1"): the owner's key for share references.
 */
export function shareRefKey(enc_sk: Uint8Array | number[]): Uint8Array;

/**
 * The fields of an entry that can be shared (standard ones first, then the TOTP code source, then
 * custom fields). `entry` is `{ fields: FieldRecord[] }` (an `EntryRecord`) or a `FieldRecord[]`.
 */
export function shareableFields(entry: { fields: FieldRecord[] } | FieldRecord[]): ShareableField[];

/**
 * Argon2id of the NFKC password with `kdf` (checked against `opts.min` unless `opts.allowWeak`).
 */
export function stretchPassword(password: string | Uint8Array, kdf: KdfParams, opts?: DeriveAukOptions): Uint8Array;

/**
 * The payload of a text share.
 */
export function textSharePayload(text: string | Uint8Array, title?: string | null, shared_by?: string | null): SharePayload;

/**
 * The TOTP code at `nowMs` (Unix milliseconds).
 */
export function totpCode(params: TotpParams, now_ms: number): TotpCode;

/**
 * Decodes server JSON and checks the signature: `invalid_public_keys` when it doesn't verify.
 */
export function trustedPublicKeys(j: PublicKeysJson): PublicKeys;

/**
 * Removes the padding; `decryption_failed` when it is malformed.
 */
export function unpadShare(padded: Uint8Array | number[]): Uint8Array;

/**
 * Opens a sealed blob.
 */
export function unseal(recipient_enc_sk: Uint8Array | number[], sealed: Uint8Array | number[], aad: string): Uint8Array;

/**
 * Opens a sealed SA master key.
 */
export function unsealSaMaster(enc_sk: Uint8Array | number[], sa_id: string, sealed: Uint8Array | number[]): Uint8Array;

/**
 * Opens a sealed vault key (32 bytes).
 */
export function unsealVaultKey(enc_sk: Uint8Array | number[], vault_id: string, sealed: Uint8Array | number[]): Uint8Array;

/**
 * Opens a [`wrap`] blob; `unsupported_version`/`decryption_failed`.
 */
export function unwrap(key: Uint8Array | number[], blob: Uint8Array | number[], aad: string): Uint8Array;

/**
 * Unwraps a server keyset and checks it against its public keys.
 */
export function unwrapKeyset(key: Uint8Array | number[], w: WrappedKeysetJson): Keyset;

/**
 * Unwraps an SA master key.
 */
export function unwrapSaMaster(kek: Uint8Array | number[], sa_id: string, wrapped: string): Uint8Array;

/**
 * HKDF(vaultKey, "ov-vault-name-v1").
 */
export function vaultNameKey(vault_key: Uint8Array | number[]): Uint8Array;

/**
 * Verifies an EdDSA access token against a JWKS (signature, `iss`, `aud`, `exp`/`nbf` with skew):
 * the claims, or `unauthorized` (status 401).
 */
export function verifyJwt(token: string | Uint8Array, jwks: Jwks, opts: VerifyJwtOptions): AccessClaims;

/**
 * Whether the public keys' signature verifies (`sig` by `signPk` over both keys).
 */
export function verifyPublicKeys(_public: PublicKeys): boolean;

/**
 * Whether a restore proof verifies against the archived signing key.
 */
export function verifyRestoreProof(proof: Uint8Array | number[], user_id: string, current_keys: CurrentKeys, old_sign_pk: Uint8Array | number[]): boolean;

/**
 * The core's version (`ov-core` crate version).
 */
export function version(): string;

/**
 * `0x01 ‖ nonce ‖ XChaCha20-Poly1305(key, plaintext, aad)` (SPEC §4).
 */
export function wrap(key: Uint8Array | number[], plaintext: Uint8Array | number[], aad: string, nonce?: Uint8Array | number[] | null): Uint8Array;

/**
 * Wraps a keyset under `key` (the AUK or an SA master) for the server.
 */
export function wrapKeyset(key: Uint8Array | number[], ks: Keyset, nonce?: Uint8Array | number[] | null): WrappedKeysetJson;

/**
 * Wraps an SA master key under a token's KEK (base64url).
 */
export function wrapSaMaster(kek: Uint8Array | number[], sa_id: string, master: Uint8Array | number[], nonce?: Uint8Array | number[] | null): string;

/**
 * The X25519 public key of a 32-byte secret key.
 */
export function x25519PublicKey(sk: Uint8Array | number[]): Uint8Array;

/**
 * A random X25519 secret key (clamped).
 */
export function x25519RandomSecret(): Uint8Array;

/**
 * X25519(sk, pk); `low_order_point` when the result is all zeroes.
 */
export function x25519Shared(sk: Uint8Array | number[], pk: Uint8Array | number[]): Uint8Array;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __install: (a: any, b: any) => void;
    readonly __scrubStack: () => void;
    readonly __testPanic: (a: number, b: number) => void;
    readonly __testPanicAsync: (a: number, b: number) => any;
    readonly __wbg_account_free: (a: number, b: number) => void;
    readonly __wbg_eventstream_free: (a: number, b: number) => void;
    readonly __wbg_kdbx_free: (a: number, b: number) => void;
    readonly __wbg_ovclient_free: (a: number, b: number) => void;
    readonly __wbg_selfhosted_free: (a: number, b: number) => void;
    readonly __wbg_serviceaccount_free: (a: number, b: number) => void;
    readonly __wbg_shareopen_free: (a: number, b: number) => void;
    readonly __wbg_totpchallenge_free: (a: number, b: number) => void;
    readonly __wbg_vault_free: (a: number, b: number) => void;
    readonly account_acceptInvitation: (a: number, b: number, c: number, d: number) => any;
    readonly account_accessToken: (a: number, b: number, c: number) => any;
    readonly account_appleEligibility: (a: number, b: number, c: number, d: number) => any;
    readonly account_auditLog: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly account_autofillEdits: (a: number, b: number, c: number) => any;
    readonly account_cachedKdf: (a: number) => any;
    readonly account_cachedVaults: (a: number) => any;
    readonly account_cancelInvitation: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_changeEmail: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly account_changePassword: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_changeRole: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_checkParkedSession: (a: number, b: number, c: number, d: number) => any;
    readonly account_clearAutofillEdits: (a: number, b: any) => any;
    readonly account_clockOffsetMs: (a: number) => any;
    readonly account_confirmMember: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_confirmTwoStep: (a: number, b: number, c: number, d: number) => any;
    readonly account_createOrg: (a: number, b: number, c: number, d: number) => any;
    readonly account_createServiceAccount: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly account_createShare: (a: number, b: any, c: any, d: number) => any;
    readonly account_createVault: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_deleteAccount: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_deleteOrg: (a: number, b: number, c: number, d: number) => any;
    readonly account_deleteServiceAccount: (a: number, b: number, c: number, d: number) => any;
    readonly account_deleteVault: (a: number, b: number, c: number, d: number) => any;
    readonly account_deletionPreview: (a: number, b: number) => any;
    readonly account_deletionScheduledFor: (a: number) => [number, number];
    readonly account_devices: (a: number, b: number) => any;
    readonly account_disableTwoStep: (a: number, b: number, c: number, d: number) => any;
    readonly account_email: (a: number) => [number, number];
    readonly account_fingerprint: (a: number) => [number, number, number];
    readonly account_forgetDevice: (a: number, b: number, c: number) => any;
    readonly account_hasAnyPendingEdits: (a: number) => any;
    readonly account_hasPendingEdits: (a: number, b: number, c: number) => any;
    readonly account_hasSecretKey: (a: number, b: number, c: number) => any;
    readonly account_importKdbx: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_importVault: (a: number, b: number, c: any, d: number) => any;
    readonly account_invitations: (a: number, b: number, c: number, d: number) => any;
    readonly account_invite: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_isOffline: (a: number) => number;
    readonly account_isSignedIn: (a: number) => number;
    readonly account_isUnlocked: (a: number) => number;
    readonly account_issueServiceAccountSecret: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly account_keepAutofillEdit: (a: number, b: number, c: number, d: any, e: number, f: number) => any;
    readonly account_listShares: (a: number, b: number) => any;
    readonly account_lock: (a: number) => void;
    readonly account_login: (a: number, b: any, c: number) => any;
    readonly account_lookUp: (a: number, b: number, c: number, d: number) => any;
    readonly account_managedOrgVaults: (a: number, b: number, c: number, d: number) => any;
    readonly account_me: (a: number, b: number) => any;
    readonly account_members: (a: number, b: number, c: number, d: number) => any;
    readonly account_openCopy: (a: number, b: number, c: number) => any;
    readonly account_openOffline: (a: number, b: number, c: number) => any;
    readonly account_openVault: (a: number, b: number, c: number, d: number) => any;
    readonly account_openVaultVersion: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly account_org: (a: number, b: number, c: number, d: number) => any;
    readonly account_orgMembers: (a: number, b: number, c: number, d: number) => any;
    readonly account_orgs: (a: number, b: number) => any;
    readonly account_parkSession: (a: number) => any;
    readonly account_plan: (a: number, b: number) => any;
    readonly account_principal: (a: number) => [number, number, number];
    readonly account_recipient: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_reconnect: (a: number, b: number) => any;
    readonly account_recover: (a: number, b: number, c: number, d: number, e: number, f: any, g: number, h: number) => any;
    readonly account_recoverInfo: (a: number, b: number, c: number, d: number) => any;
    readonly account_recoveryStatus: (a: number, b: number) => any;
    readonly account_register: (a: number, b: any, c: number) => any;
    readonly account_removeMember: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_renameOrg: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_renameVault: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_reportAppleTransaction: (a: number, b: number, c: number, d: number) => any;
    readonly account_requestEmailChange: (a: number, b: number, c: number, d: number) => any;
    readonly account_restoreAccount: (a: number, b: number, c: number, d: number) => any;
    readonly account_restoreFromArchive: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_resumeSession: (a: number, b: number, c: number) => any;
    readonly account_resumeUnlocked: (a: number, b: number, c: number, d: number) => any;
    readonly account_revoke: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_revokeDevice: (a: number, b: number, c: number, d: number) => any;
    readonly account_revokeSecret: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_revokeShare: (a: number, b: number, c: number, d: number) => any;
    readonly account_rotateFlagged: (a: number, b: number, c: number, d: number) => any;
    readonly account_rotateVaultKey: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_secretKey: (a: number) => any;
    readonly account_serverConfig: (a: number) => any;
    readonly account_serviceAccountSecrets: (a: number, b: number, c: number, d: number) => any;
    readonly account_serviceAccounts: (a: number, b: number, c: number, d: number) => any;
    readonly account_setMemberRole: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_setOrgShareLinks: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly account_setSecretExpiry: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly account_shareBase: (a: number) => [number, number];
    readonly account_shareBlockedReason: (a: number, b: number, c: number) => any;
    readonly account_shareVault: (a: number, b: number, c: number, d: any, e: any, f: number) => any;
    readonly account_signOut: (a: number, b: number, c: number) => any;
    readonly account_signOutOnUnload: (a: number) => any;
    readonly account_signOutParked: (a: number, b: number, c: number, d: number) => any;
    readonly account_signedOut: (a: number, b: number) => any;
    readonly account_startTwoStep: (a: number, b: number) => any;
    readonly account_storedSecretKey: (a: number, b: number, c: number) => any;
    readonly account_storedSession: (a: number) => any;
    readonly account_submitTotp: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly account_subscribe: (a: number, b: number) => any;
    readonly account_syncVaultKdbx: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any, i: number) => any;
    readonly account_transferVault: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_unlock: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly account_unlockWithAuk: (a: number, b: number, c: number, d: number) => any;
    readonly account_unlockedKeysetSecret: (a: number) => [number, number, number];
    readonly account_updateServiceAccount: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly account_upgradeUrl: (a: number, b: any) => [number, number, number, number];
    readonly account_userId: (a: number) => [number, number];
    readonly account_vaultHistory: (a: number, b: number, c: number, d: number) => any;
    readonly account_vaultKdbxCredentials: (a: number, b: number, c: number, d: number) => any;
    readonly account_vaultQuota: (a: number, b: number, c: number) => any;
    readonly account_vaults: (a: number, b: number) => any;
    readonly account_verifiedPublicKeys: (a: number, b: number, c: number, d: number) => any;
    readonly account_verifySession: (a: number, b: number) => any;
    readonly account_webSessionUrl: (a: number, b: number, c: number, d: number) => any;
    readonly aeadDecrypt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly aeadEncrypt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly argon2: (a: any) => [number, number, number];
    readonly argon2id: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly base32Decode: (a: any) => [number, number, number];
    readonly buildSaToken: (a: any) => [number, number, number];
    readonly checkKdfParams: (a: any, b: number) => [number, number];
    readonly decodeJwt: (a: any) => [number, number, number];
    readonly decryptSharePayload: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly decryptShareRef: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly decryptVaultName: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number, number];
    readonly defaultShareFields: () => [number, number];
    readonly deletionExpired: (a: number, b: number, c: number) => [number, number, number];
    readonly deriveAuk: (a: any, b: any, c: number, d: number, e: number) => [number, number, number];
    readonly ed25519PublicKey: (a: number, b: number) => [number, number, number];
    readonly ed25519Sign: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly ed25519Verify: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
    readonly encryptSharePayload: (a: number, b: number, c: number, d: number, e: any, f: number, g: number, h: number, i: number) => [number, number, number];
    readonly encryptShareRef: (a: number, b: number, c: number, d: number, e: any, f: number, g: number) => [number, number, number, number];
    readonly encryptVaultName: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly entryTotpUri: (a: any, b: number, c: number) => [number, number, number];
    readonly eventstream_close: (a: number) => void;
    readonly eventstream_next: (a: number, b: number) => any;
    readonly eventstream_reconnect: (a: number) => void;
    readonly fingerprint: (a: number, b: number, c: number, d: number) => [number, number];
    readonly formatSecretKey: (a: number, b: number) => [number, number, number];
    readonly generateKeyset: () => [number, number, number];
    readonly generateSecretKey: () => [number, number, number];
    readonly hkdfSha256: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly isJwt: (a: any) => [number, number, number];
    readonly itemSharePayload: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly kdbxMerge: (a: number, b: number, c: number, d: number, e: number, f: number, g: any, h: number, i: number) => [number, number, number];
    readonly kdbxPasswordHash: (a: any) => [number, number, number];
    readonly kdbx_applyVaultKdf: (a: number) => [number, number];
    readonly kdbx_clone: (a: number) => number;
    readonly kdbx_create: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly kdbx_createVault: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly kdbx_dropServerRemotes: (a: number) => void;
    readonly kdbx_entries: (a: number) => any;
    readonly kdbx_findConflicts: (a: number, b: number, c: any) => [number, number, number];
    readonly kdbx_groups: (a: number) => any;
    readonly kdbx_hasPendingDeletions: (a: number, b: number) => number;
    readonly kdbx_header: (a: number) => any;
    readonly kdbx_importAsCopies: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly kdbx_importFrom: (a: number, b: number) => any;
    readonly kdbx_importTargets: (a: number) => any;
    readonly kdbx_kdfSettings: (a: number) => any;
    readonly kdbx_merge: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly kdbx_mergeFrom: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly kdbx_mergeWithBase: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly kdbx_name: (a: number) => [number, number];
    readonly kdbx_needsCommonBase: (a: number, b: number, c: any) => [number, number, number];
    readonly kdbx_openWithKeyVersions: (a: number, b: number, c: any) => [number, number, number];
    readonly kdbx_peekHeader: (a: number, b: number) => [number, number, number];
    readonly kdbx_read: (a: number, b: number, c: any) => [number, number, number];
    readonly kdbx_rekeyToVaultKey: (a: number, b: number, c: number) => [number, number];
    readonly kdbx_rootGroupId: (a: number) => [number, number];
    readonly kdbx_setKey: (a: number, b: any) => [number, number];
    readonly kdbx_setSyncGeneration: (a: number, b: number, c: number, d: number) => [number, number];
    readonly kdbx_snapshot: (a: number) => any;
    readonly kdbx_syncGeneration: (a: number) => number;
    readonly kdbx_write: (a: number, b: number) => [number, number, number];
    readonly keysetFromSecrets: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly newKdfParams: (a: number) => [number, number, number];
    readonly newRefreshToken: () => [number, number, number];
    readonly newSaSecret: (a: any) => [number, number, number];
    readonly newShareKey: () => [number, number, number];
    readonly opaqueFinishLogin: (a: number, b: number, c: number, d: number, e: any, f: number, g: number, h: number, i: number) => [number, number, number];
    readonly opaqueFinishRegistration: (a: number, b: number, c: number, d: number, e: any, f: number, g: number) => [number, number, number];
    readonly opaqueIds: (a: number, b: number, c: number, d: number) => any;
    readonly opaqueServerCredentialResponse: (a: number, b: number, c: number, d: number, e: any, f: number, g: number, h: number, i: number) => [number, number, number];
    readonly opaqueServerRegistrationResponse: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly opaqueServerStoreRecord: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly opaqueServerUserAuth: (a: number, b: number, c: number, d: number) => any;
    readonly opaqueStartLogin: (a: any, b: number, c: number) => [number, number, number];
    readonly opaqueStartRegistration: (a: any, b: number, c: number) => [number, number, number];
    readonly openShareContent: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly ovclient_config: (a: number) => any;
    readonly ovclient_connect: (a: number, b: number, c: number, d: number) => any;
    readonly ovclient_createLocal: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly ovclient_discover: (a: number, b: number, c: number, d: number) => any;
    readonly ovclient_forgetRemembered: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly ovclient_hasPendingEdits: (a: number, b: number, c: number) => any;
    readonly ovclient_markRememberedChecked: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly ovclient_new: (a: any, b: any) => [number, number, number];
    readonly ovclient_openLocal: (a: number, b: number, c: number, d: any, e: number) => any;
    readonly ovclient_openShare: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: any, i: number) => any;
    readonly ovclient_rememberAccount: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly ovclient_rememberedAccounts: (a: number) => any;
    readonly ovclient_sessionState: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly ovclient_setRememberedDeletion: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly ovclient_shareInfo: (a: number, b: number, c: number, d: number, e: number, f: number) => any;
    readonly padShare: (a: number, b: number) => any;
    readonly parseSaToken: (a: any) => [number, number, number];
    readonly parseSecretKey: (a: any) => [number, number, number];
    readonly parseShareLink: (a: any) => [number, number, number];
    readonly parseTotpUri: (a: any) => [number, number, number];
    readonly passwordBytes: (a: any) => [number, number, number];
    readonly publicKeysFromJson: (a: any) => [number, number, number];
    readonly publicKeysToJson: (a: any) => [number, number, number];
    readonly randomBytes: (a: number) => [number, number, number];
    readonly refreshTokenHash: (a: any) => [number, number, number, number];
    readonly resealVaultKey: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number) => [number, number, number];
    readonly restoreProof: (a: number, b: number, c: number, d: number, e: any) => [number, number, number];
    readonly restoreProofMessage: (a: number, b: number, c: any) => [number, number, number];
    readonly saSecretHash: (a: number, b: number) => [number, number, number, number];
    readonly saSecretPrefix: (a: number, b: number) => [number, number, number, number];
    readonly seal: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly sealDerivedKey: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly sealSaMaster: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly sealVaultKey: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly selfhosted_connect: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly selfhosted_createPairingCode: (a: number, b: number) => any;
    readonly selfhosted_events: (a: number, b: number) => any;
    readonly selfhosted_health: (a: number, b: number) => any;
    readonly selfhosted_history: (a: number, b: number, c: number, d: number) => any;
    readonly selfhosted_listDatabases: (a: number, b: number) => any;
    readonly selfhosted_openVersion: (a: number, b: number, c: number, d: number, e: any, f: number) => any;
    readonly selfhosted_pair: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => any;
    readonly selfhosted_restore: (a: number, b: number, c: number) => any;
    readonly selfhosted_serverUrl: (a: number) => [number, number];
    readonly selfhosted_syncDatabase: (a: number, b: number, c: number, d: number, e: number, f: any, g: number) => any;
    readonly selfhosted_syncDatabaseWith: (a: number, b: number, c: number, d: number, e: number, f: any, g: any, h: number) => any;
    readonly serviceaccount_close: (a: number) => void;
    readonly serviceaccount_fromToken: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_inject: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_issuer: (a: number) => [number, number];
    readonly serviceaccount_openVault: (a: number, b: number, c: number, d: number, e: number) => any;
    readonly serviceaccount_principal: (a: number) => [number, number];
    readonly serviceaccount_pull: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_read: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_saId: (a: number) => [number, number];
    readonly serviceaccount_serverConfig: (a: number) => any;
    readonly serviceaccount_vault: (a: number, b: number, c: number, d: number) => any;
    readonly serviceaccount_vaults: (a: number, b: number, c: number) => any;
    readonly serviceaccount_write: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly sha256: (a: number, b: number) => any;
    readonly shareAuth: (a: number, b: number) => [number, number, number];
    readonly shareAuthHash: (a: number, b: number) => any;
    readonly shareContentKey: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly shareKeyFromHash: (a: any) => [number, number, number];
    readonly shareLink: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly sharePasscodeKey: (a: any, b: any, c: number) => [number, number, number];
    readonly shareRefKey: (a: number, b: number) => any;
    readonly shareableFields: (a: any) => [number, number, number];
    readonly shareopen_auth: (a: number) => any;
    readonly shareopen_base: (a: number) => [number, number];
    readonly shareopen_decrypt: (a: number, b: any) => [number, number, number];
    readonly shareopen_id: (a: number) => [number, number];
    readonly shareopen_new: (a: any, b: number, c: number) => [number, number, number];
    readonly shareopen_requestBody: (a: number) => any;
    readonly stretchPassword: (a: any, b: any, c: number) => [number, number, number];
    readonly textSharePayload: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly totpCode: (a: any, b: number) => [number, number, number];
    readonly totpchallenge_attempt: (a: number) => number;
    readonly totpchallenge_lastError: (a: number) => any;
    readonly trustedPublicKeys: (a: any) => [number, number, number];
    readonly unpadShare: (a: number, b: number) => [number, number, number];
    readonly unseal: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly unsealSaMaster: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly unsealVaultKey: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly unwrap: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly unwrapKeyset: (a: number, b: number, c: any) => [number, number, number];
    readonly unwrapSaMaster: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly vaultNameKey: (a: number, b: number) => [number, number, number];
    readonly vault_addCustomIcon: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_addEntry: (a: number, b: number, c: number, d: any) => [number, number, number];
    readonly vault_addEntryWithId: (a: number, b: number, c: number, d: number, e: number, f: any) => [number, number, number];
    readonly vault_addGroup: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_applyAutofillEdits: (a: number, b: any) => [number, number, number];
    readonly vault_attachment: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_conflicts: (a: number) => any;
    readonly vault_copyWithoutRemotes: (a: number, b: any) => [number, number, number];
    readonly vault_createLocal: (a: number, b: number, c: any, d: number) => any;
    readonly vault_customIcon: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_deleteEntry: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_deleteGroup: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_editEntry: (a: number, b: number, c: number, d: any) => [number, number, number];
    readonly vault_emptyRecycleBin: (a: number) => [number, number, number];
    readonly vault_ensureGroup: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_entries: (a: number, b: number) => any;
    readonly vault_entry: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_entryRecords: (a: number, b: number) => any;
    readonly vault_etag: (a: number) => [number, number];
    readonly vault_exportKdbx: (a: number, b: any, c: number, d: number, e: number) => any;
    readonly vault_exportKdbxWith: (a: number, b: any, c: number, d: number, e: any, f: number) => any;
    readonly vault_exportPlain: (a: number, b: any, c: number, d: number) => [number, number, number];
    readonly vault_find: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_groupIdAt: (a: number, b: number, c: number) => [number, number];
    readonly vault_groups: (a: number) => any;
    readonly vault_hasPendingEdits: (a: number) => any;
    readonly vault_history: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_id: (a: number) => [number, number];
    readonly vault_importFrom: (a: number, b: number, c: any) => [number, number, number];
    readonly vault_importPreview: (a: number) => any;
    readonly vault_importTargets: (a: number) => any;
    readonly vault_info: (a: number) => any;
    readonly vault_isInRecycleBin: (a: number, b: number, c: number) => number;
    readonly vault_isOffline: (a: number) => number;
    readonly vault_isReadOnly: (a: number) => number;
    readonly vault_keepEdits: (a: number) => any;
    readonly vault_metaCustomData: (a: number, b: number, c: number) => [number, number];
    readonly vault_moveEntry: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_moveGroup: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_name: (a: number) => [number, number];
    readonly vault_openLocal: (a: number, b: number, c: any, d: number) => any;
    readonly vault_readField: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_removeAttachment: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_renameGroup: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_restoreEntry: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly vault_restoreFromRecycleBin: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_rootGroupId: (a: number) => [number, number];
    readonly vault_saveLocal: (a: number, b: number) => any;
    readonly vault_setAttachment: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly vault_setAttachmentWith: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly vault_setFields: (a: number, b: number, c: number, d: any, e: any) => [number, number, number];
    readonly vault_setGroupIcon: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly vault_setKdf: (a: number, b: any) => [number, number, number];
    readonly vault_setMetaCustomData: (a: number, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly vault_setName: (a: number, b: number, c: number) => [number, number, number];
    readonly vault_sync: (a: number, b: any, c: number) => any;
    readonly vault_versionDifference: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly vault_writeField: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => any;
    readonly verifyJwt: (a: any, b: any, c: any) => [number, number, number];
    readonly verifyPublicKeys: (a: any) => [number, number, number];
    readonly verifyRestoreProof: (a: number, b: number, c: number, d: number, e: any, f: number, g: number) => [number, number, number];
    readonly version: () => [number, number];
    readonly wrap: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly wrapKeyset: (a: number, b: number, c: any, d: number, e: number) => [number, number, number];
    readonly wrapSaMaster: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number, number];
    readonly x25519PublicKey: (a: number, b: number) => [number, number, number];
    readonly x25519RandomSecret: () => [number, number, number];
    readonly x25519Shared: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined_______true_: (a: number, b: number, c: any, d: any) => void;
    readonly wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___wasm_bindgen_90e3c6fa821d6ed___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_90e3c6fa821d6ed___JsError___true_: (a: number, b: number, c: any) => [number, number];
    readonly wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke_______true_: (a: number, b: number) => void;
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __wbindgen_destroy_closure: (a: number, b: number) => void;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
