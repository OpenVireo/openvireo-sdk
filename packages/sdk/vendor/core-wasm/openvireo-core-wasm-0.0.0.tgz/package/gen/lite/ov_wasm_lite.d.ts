/* tslint:disable */
/* eslint-disable */
/** What a share link holds (SPEC §22). Field values are UTF-8. */
export interface SharePayload { v: number; kind: string; title?: string; sharedBy?: string; fields: ShareField[] }
/** `k`: `username`, `password`, `url`, `notes`, `totp`, `custom` or `text` (open set). */
export interface ShareField { k: string; label: string; value: Uint8Array; protected: boolean }
/** A field an entry can share (`name` is the entry field, `kind` the share kind it becomes). */
export interface ShareableField { name: string; kind: string; label: string; value: Uint8Array; protected: boolean }
/** One string field of an entry. */
export interface FieldRecord { name: string; value: Uint8Array; protected: boolean }
/** A parsed share link: `base` (the page), the share `id` and the 32-byte `key` from the fragment. */
export interface ShareLinkParts { base: string; id: string; key: Uint8Array }
/** Steam Guard codes: `encoder: "steam"` (the facade's spelling) or `steam: true` (the SDK's); both are set on output. */
export interface TotpParams { secret: Uint8Array; digits: number; period: number; algorithm: TotpAlgorithm; encoder?: string; steam?: boolean }
/** The code (UTF-8 digits) and the seconds it stays valid. */
export interface TotpCode { code: Uint8Array; remaining: number }


export interface KdfMin {
    m: number;
    t: number;
}


export interface KdfParams {
    alg: string;
    salt: string;
    m: number;
    t: number;
    p: number;
}


export interface ShareRef {
    vault?: string;
    entry?: string;
    title: string;
}


export type Argon2Type = "argon2d" | "argon2i" | "argon2id";
/** The SDK's `Argon2Params`: memory `m` in KiB, output length `dkLen` in bytes. Argon2 version 0x13. */
export interface Argon2Params { type: Argon2Type; password: Uint8Array; salt: Uint8Array; m: number; t: number; p: number; dkLen: number }


export type TotpAlgorithm = "SHA1" | "SHA256" | "SHA512";



/**
 * A share link being opened (the TS `openShare` minus HTTP): built from the link, the share's
 * public `kdf` (when it has a passcode) and the passcode, so the Argon2 work happens once. Send
 * `requestBody()` to `POST {api}/public/shares/{id}/open`, then `decrypt` the returned `ct`.
 * `free()` wipes the keys.
 */
export class ShareOpen {
    free(): void;
    [Symbol.dispose](): void;
    /**
     * Decrypts the share's `ct` (bytes, or base64url as the server sends it).
     */
    decrypt(ct: Uint8Array | string): SharePayload;
    /**
     * `passcode_required` when the share has a `kdf` and no passcode is given, `weak_kdf` below the
     * SPEC minimum, `invalid_link` for a bad link.
     */
    constructor(link: string | Uint8Array, kdf?: KdfParams, passcode?: string | Uint8Array);
    /**
     * The JSON body of the open request (UTF-8): `{"auth":"…"}` or `{}`.
     */
    requestBody(): Uint8Array;
    /**
     * `auth` (base64url) when the share has a passcode.
     */
    readonly auth: Uint8Array | undefined;
    /**
     * The link's base (the share page).
     */
    readonly base: string;
    /**
     * The share id.
     */
    readonly id: string;
}

/**
 * Called once by `index.js` at load: the `OvError` class to construct errors with, and the
 * callback a panic reports to before the module traps.
 */
export function __install(error_class: Function, on_panic: Function): void;

/**
 * Zeroes the shadow stack below the caller (where the frames of the call that just returned were).
 * Hidden from the loaded API; the loaders call it.
 */
export function __scrubStack(): void;

/**
 * Test hook: panics synchronously, so the loader's panic handling can be tested. Hidden from the
 * loaded API.
 */
export function __testPanic(message: string): void;

/**
 * XChaCha20-Poly1305 decryption; `decryption_failed` on a wrong key or tampered input.
 */
export function aeadDecrypt(key: Uint8Array | number[], nonce: Uint8Array | number[], ciphertext: Uint8Array | number[], aad: Uint8Array | number[]): Uint8Array;

/**
 * XChaCha20-Poly1305 encryption: 32-byte key, 24-byte nonce; returns ciphertext ‖ tag.
 */
export function aeadEncrypt(key: Uint8Array | number[], nonce: Uint8Array | number[], plaintext: Uint8Array | number[], aad: Uint8Array | number[]): Uint8Array;

/**
 * Argon2d, Argon2i or Argon2id (version 0x13) with any output length (KDBX files, the SDK's
 * `argon2()`). `weak_kdf` for parameters Argon2 refuses. No minimum-cost check: see `checkKdfParams`.
 */
export function argon2(params: Argon2Params): Uint8Array;

/**
 * Argon2id (v0x13), 32-byte output. `m` in KiB.
 */
export function argon2id(password: Uint8Array | number[], salt: Uint8Array | number[], m: number, t: number, p: number): Uint8Array;

/**
 * RFC 4648 base32 (as TOTP secrets are written): case-insensitive, white space, `=` and `-`
 * ignored; `invalid_totp` otherwise. The SDK's `base32Decode`. The result may be a secret: wipe it.
 */
export function base32Decode(text: string | Uint8Array): Uint8Array;

/**
 * Decrypts a share's `ct` bytes; `decryption_failed` for a wrong key, passcode or id.
 */
export function decryptSharePayload(key: Uint8Array | number[], id: string, ct: Uint8Array | number[], passcode_key?: Uint8Array | number[] | null): SharePayload;

/**
 * Decrypts an owner's reference.
 */
export function decryptShareRef(enc_sk: Uint8Array | number[], id: string, reference: string): ShareRef;

/**
 * The fields an item share includes by default.
 */
export function defaultShareFields(): string[];

/**
 * Encrypts a payload under the link key (and passcode key): the share's `ct` bytes. `nonce` is
 * for test vectors only. `too_large` past 64 KiB.
 */
export function encryptSharePayload(key: Uint8Array | number[], id: string, payload: SharePayload, passcode_key?: Uint8Array | number[] | null, nonce?: Uint8Array | number[] | null): Uint8Array;

/**
 * Encrypts the owner's reference (`{vault, entry, title}`) to base64url. `nonce` for test vectors only.
 */
export function encryptShareRef(enc_sk: Uint8Array | number[], id: string, reference: ShareRef, nonce?: Uint8Array | number[] | null): string;

/**
 * An entry's TOTP URI from its fields (`otp`, or KeePass's `TOTP Seed`/`TOTP Settings`).
 */
export function entryTotpUri(fields: { fields: FieldRecord[] } | FieldRecord[], label: string): Uint8Array | undefined;

/**
 * HKDF-SHA256 (RFC 5869) with `length` output bytes (at most 8160).
 */
export function hkdfSha256(ikm: Uint8Array | number[], salt: Uint8Array | number[], info: Uint8Array | number[], length: number): Uint8Array;

/**
 * The payload of an item share with the named fields.
 */
export function itemSharePayload(entry: { fields: FieldRecord[] } | FieldRecord[], names: string[], shared_by?: string | null): SharePayload;

/**
 * A fresh 32-byte link key.
 */
export function newShareKey(): Uint8Array;

/**
 * Opens a share in one step from its link, `kdf`, passcode and the fetched `ct` (base64url).
 */
export function openShareContent(link: string | Uint8Array, kdf: KdfParams | undefined, passcode: string | Uint8Array | undefined, ct: string): SharePayload;

/**
 * Pads share content to a multiple of 512 bytes (`0x80` then zeroes).
 */
export function padShare(data: Uint8Array | number[]): Uint8Array;

/**
 * Splits a share link; `invalid_link` when it isn't a complete one.
 */
export function parseShareLink(link: string | Uint8Array): ShareLinkParts;

/**
 * Parses an `otpauth://totp/` URI (KeePassXC's `otp` field).
 */
export function parseTotpUri(uri: string | Uint8Array): TotpParams;

/**
 * `n` bytes from the platform CSPRNG (`crypto.getRandomValues`).
 */
export function randomBytes(n: number): Uint8Array;

/**
 * SHA-256.
 */
export function sha256(data: Uint8Array | number[]): Uint8Array;

/**
 * The `auth` value a passcode share's open request sends: HKDF(passcodeKey, "ov-share-auth-v1").
 */
export function shareAuth(passcode_key: Uint8Array | number[]): Uint8Array;

/**
 * SHA-256 of `auth` (what the server stores).
 */
export function shareAuthHash(auth: Uint8Array | number[]): Uint8Array;

/**
 * HKDF(key, salt = passcodeKey or empty, "ov-share-v1"): the content key.
 */
export function shareContentKey(key: Uint8Array | number[], passcode_key?: Uint8Array | number[] | null): Uint8Array;

/**
 * The link key from a URL fragment (`#…` or without the `#`).
 */
export function shareKeyFromHash(hash: string | Uint8Array): Uint8Array;

/**
 * `<base>/<id>#<base64url key>` (UTF-8).
 */
export function shareLink(base: string, id: string, key: Uint8Array | number[]): Uint8Array;

/**
 * Argon2id of the NFKC passcode with the share's `kdf` (SPEC §22). `weak_kdf` below the SPEC §3
 * minimum unless `allowWeak` (test vectors only).
 */
export function sharePasscodeKey(passcode: string | Uint8Array, kdf: KdfParams, allow_weak?: boolean | null): Uint8Array;

/**
 * HKDF(encSk, "ov-share-ref-v1"): the owner's key for share references.
 */
export function shareRefKey(enc_sk: Uint8Array | number[]): Uint8Array;

/**
 * The fields of an entry that can be shared (standard ones first, then the TOTP code source, then
 * custom fields). `entry` is `{ fields: FieldRecord[] }` (an `EntryRecord`) or a `FieldRecord[]`.
 */
export function shareableFields(entry: { fields: FieldRecord[] } | FieldRecord[]): ShareableField[];

/**
 * The payload of a text share.
 */
export function textSharePayload(text: string | Uint8Array, title?: string | null, shared_by?: string | null): SharePayload;

/**
 * The TOTP code at `nowMs` (Unix milliseconds).
 */
export function totpCode(params: TotpParams, now_ms: number): TotpCode;

/**
 * Removes the padding; `decryption_failed` when it is malformed.
 */
export function unpadShare(padded: Uint8Array | number[]): Uint8Array;

/**
 * The core's version (the workspace version, as the full module's `version()`).
 */
export function version(): string;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
    readonly memory: WebAssembly.Memory;
    readonly __install: (a: any, b: any) => void;
    readonly __scrubStack: () => void;
    readonly __testPanic: (a: number, b: number) => void;
    readonly __wbg_shareopen_free: (a: number, b: number) => void;
    readonly aeadDecrypt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly aeadEncrypt: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly argon2: (a: any) => [number, number, number];
    readonly argon2id: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly base32Decode: (a: any) => [number, number, number];
    readonly decryptSharePayload: (a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number) => [number, number, number];
    readonly decryptShareRef: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly defaultShareFields: () => [number, number];
    readonly encryptSharePayload: (a: number, b: number, c: number, d: number, e: any, f: number, g: number, h: number, i: number) => [number, number, number];
    readonly encryptShareRef: (a: number, b: number, c: number, d: number, e: any, f: number, g: number) => [number, number, number, number];
    readonly entryTotpUri: (a: any, b: number, c: number) => [number, number, number];
    readonly hkdfSha256: (a: number, b: number, c: number, d: number, e: number, f: number, g: number) => [number, number, number];
    readonly itemSharePayload: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly newShareKey: () => [number, number, number];
    readonly openShareContent: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly padShare: (a: number, b: number) => any;
    readonly parseShareLink: (a: any) => [number, number, number];
    readonly parseTotpUri: (a: any) => [number, number, number];
    readonly randomBytes: (a: number) => [number, number, number];
    readonly sha256: (a: number, b: number) => any;
    readonly shareAuth: (a: number, b: number) => [number, number, number];
    readonly shareAuthHash: (a: number, b: number) => any;
    readonly shareContentKey: (a: number, b: number, c: number, d: number) => [number, number, number];
    readonly shareKeyFromHash: (a: any) => [number, number, number];
    readonly shareLink: (a: number, b: number, c: number, d: number, e: number, f: number) => [number, number, number];
    readonly sharePasscodeKey: (a: any, b: any, c: number) => [number, number, number];
    readonly shareRefKey: (a: number, b: number) => any;
    readonly shareableFields: (a: any) => [number, number, number];
    readonly shareopen_auth: (a: number) => any;
    readonly shareopen_base: (a: number) => [number, number];
    readonly shareopen_decrypt: (a: number, b: any) => [number, number, number];
    readonly shareopen_id: (a: number) => [number, number];
    readonly shareopen_new: (a: any, b: number, c: number) => [number, number, number];
    readonly shareopen_requestBody: (a: number) => any;
    readonly textSharePayload: (a: any, b: number, c: number, d: number, e: number) => [number, number, number];
    readonly totpCode: (a: any, b: number) => [number, number, number];
    readonly unpadShare: (a: number, b: number) => [number, number, number];
    readonly version: () => [number, number];
    readonly __wbindgen_malloc: (a: number, b: number) => number;
    readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
    readonly __wbindgen_free: (a: number, b: number, c: number) => void;
    readonly __wbindgen_exn_store: (a: number) => void;
    readonly __externref_table_alloc: () => number;
    readonly __wbindgen_externrefs: WebAssembly.Table;
    readonly __externref_table_dealloc: (a: number) => void;
    readonly __externref_drop_slice: (a: number, b: number) => void;
    readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;

/**
 * Instantiates the given `module`, which can either be bytes or
 * a precompiled `WebAssembly.Module`.
 *
 * @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
 *
 * @returns {InitOutput}
 */
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
 * If `module_or_path` is {RequestInfo} or {URL}, makes a request and
 * for everything else, calls `WebAssembly.instantiate` directly.
 *
 * @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
 *
 * @returns {Promise<InitOutput>}
 */
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
