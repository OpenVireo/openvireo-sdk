/* @ts-self-types="./ov_wasm.d.ts" */

/**
 * An account on one server: signed out, signed in but locked, or unlocked.
 */
export class Account {
    static __wrap(ptr) {
        const obj = Object.create(Account.prototype);
        obj.__wbg_ptr = ptr;
        AccountFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        AccountFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_account_free(ptr, 0);
    }
    /**
     * r" Accepts an invitation.
     * @param {Uint8Array | number[]} token
     * @param {any | null} [signal]
     * @returns {Promise<Member>}
     */
    acceptInvitation(token, signal) {
        const ptr0 = passArray8ToWasm0(token, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_acceptInvitation(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" The session's access token (UTF-8), refreshed when needed (contract-v1.6). Never log it.
     * @param {boolean} force_refresh
     * @param {any | null} [signal]
     * @returns {Promise<Uint8Array>}
     */
    accessToken(force_refresh, signal) {
        const val1 = +force_refresh;
        const ret = wasm.account_accessToken(this.__wbg_ptr, val1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Whether In-App Purchase is possible.
     * @param {string | null} [org_id]
     * @param {any | null} [signal]
     * @returns {Promise<AppleEligibility>}
     */
    appleEligibility(org_id, signal) {
        var ptr0 = isLikeNone(org_id) ? 0 : passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_appleEligibility(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" One page of an org's audit log.
     * @param {string} org_id
     * @param {string | null} [before]
     * @param {number | null} [limit]
     * @param {any | null} [signal]
     * @returns {Promise<AuditPage>}
     */
    auditLog(org_id, before, limit, signal) {
        const val3 = +(isLikeNone(limit) ? Number.MAX_SAFE_INTEGER : (limit) >>> 0);
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = isLikeNone(before) ? 0 : passStringToWasm0(before, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_auditLog(this.__wbg_ptr, ptr0, len0, ptr1, len1, val3, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" What AutoFill saved for a vault and the app hasn't taken yet.
     * @param {string} vault_id
     * @returns {Promise<AutoFillEdits | undefined>}
     */
    autofillEdits(vault_id) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_autofillEdits(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * r" The KDF parameters cached at the last sign-in or unlock.
     * @returns {Promise<KdfParams | undefined>}
     */
    cachedKdf() {
        const ret = wasm.account_cachedKdf(this.__wbg_ptr);
        return ret;
    }
    /**
     * r" The vault list from the last successful call, without the network.
     * @returns {Promise<VaultInfo[] | undefined>}
     */
    cachedVaults() {
        const ret = wasm.account_cachedVaults(this.__wbg_ptr);
        return ret;
    }
    /**
     * r" Cancels an invitation.
     * @param {string} org_id
     * @param {string} invitation_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    cancelInvitation(org_id, invitation_id, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(invitation_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_cancelInvitation(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Changes the email with the code that was sent.
     * @param {string} email
     * @param {string} code
     * @param {Uint8Array | number[]} password
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    changeEmail(email, code, password, signal) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passArray8ToWasm0(password, wasm.__wbindgen_malloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_changeEmail(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Changes the master password; returns the new AUK.
     * @param {Uint8Array | number[]} current
     * @param {Uint8Array | number[]} next
     * @param {KdfOverrides | undefined} kdf
     * @param {any | null} [signal]
     * @returns {Promise<Uint8Array>}
     */
    changePassword(current, next, kdf, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passArray8ToWasm0(current, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(next, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_changePassword(this.__wbg_ptr, ptr0, len0, ptr1, len1, kdf, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Changes a member's role on a vault.
     * @param {string} vault_id
     * @param {string} principal
     * @param {VaultRole} role
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    changeRole(vault_id, principal, role, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(principal, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_changeRole(this.__wbg_ptr, ptr0, len0, ptr1, len1, role, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Asks the server about a parked session.
     * @param {string} user_id
     * @param {any | null} [signal]
     * @returns {Promise<ParkedCheck>}
     */
    checkParkedSession(user_id, signal) {
        const ptr0 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_checkParkedSession(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Removes AutoFill edits once taken.
     * @param {AutoFillEdits} edits
     * @returns {Promise<void>}
     */
    clearAutofillEdits(edits) {
        const ret = wasm.account_clearAutofillEdits(this.__wbg_ptr, edits);
        return ret;
    }
    /**
     * How far this device's clock is ahead of the sync server's (ms).
     * @returns {number | undefined}
     */
    clockOffsetMs() {
        const ret = wasm.account_clockOffsetMs(this.__wbg_ptr);
        return ret;
    }
    /**
     * Confirms an accepted member and grants vaults.
     * @param {string} org_id
     * @param {Member} member
     * @param {VaultGrantRequest[]} vaults
     * @param {any | null} [signal]
     * @returns {Promise<Member>}
     */
    confirmMember(org_id, member, vaults, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_confirmMember(this.__wbg_ptr, ptr0, len0, member, vaults, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Confirms two-step setup with a code.
     * @param {string} code
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    confirmTwoStep(code, signal) {
        const ptr0 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_confirmTwoStep(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Creates an org.
     * @param {string} name
     * @param {any | null} [signal]
     * @returns {Promise<Org>}
     */
    createOrg(name, signal) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_createOrg(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Creates a service account (SPEC §9).
     * @param {string} org_id
     * @param {NewServiceAccount} input
     * @param {any | null} [signal]
     * @returns {Promise<CreatedServiceAccount>}
     */
    createServiceAccount(org_id, input, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_createServiceAccount(this.__wbg_ptr, ptr0, len0, input, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Creates a share link (SPEC §22).
     * @param {SharePayload} payload
     * @param {ShareOptions} options
     * @param {any | null} [signal]
     * @returns {Promise<CreatedShare>}
     */
    createShare(payload, options, signal) {
        const ret = wasm.account_createShare(this.__wbg_ptr, payload, options, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Creates a vault (SPEC §7, §13).
     * @param {string} name
     * @param {string | null} [org_id]
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    createVault(name, org_id, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = isLikeNone(org_id) ? 0 : passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_createVault(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Schedules the account's deletion; returns the erase date.
     * @param {Uint8Array | number[]} password
     * @param {string} confirm
     * @param {any | null} [signal]
     * @returns {Promise<Rfc3339>}
     */
    deleteAccount(password, confirm, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passArray8ToWasm0(password, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(confirm, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_deleteAccount(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Deletes an org.
     * @param {string} org_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    deleteOrg(org_id, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_deleteOrg(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Deletes a service account.
     * @param {string} sa_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    deleteServiceAccount(sa_id, signal) {
        const ptr0 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_deleteServiceAccount(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Deletes a vault for everyone (needs `manage`).
     * @param {string} vault_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    deleteVault(vault_id, signal) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_deleteVault(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" What deleting the account would do (SPEC §23).
     * @param {any | null} [signal]
     * @returns {Promise<DeletionPreview>}
     */
    deletionPreview(signal) {
        const ret = wasm.account_deletionPreview(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The erase date while the account is pending deletion (SPEC §23).
     * @returns {string | undefined}
     */
    deletionScheduledFor() {
        const ret = wasm.account_deletionScheduledFor(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * r" Signed-in devices.
     * @param {any | null} [signal]
     * @returns {Promise<Device[]>}
     */
    devices(signal) {
        const ret = wasm.account_devices(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Turns two-step sign-in off.
     * @param {string} code
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    disableTwoStep(code, signal) {
        const ptr0 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_disableTwoStep(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The signed-in email.
     * @returns {string | undefined}
     */
    email() {
        const ret = wasm.account_email(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * This account's public-key fingerprint (SPEC §5).
     * @returns {string}
     */
    fingerprint() {
        const ret = wasm.account_fingerprint(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Removes the kept Secret Key and device id for `email`.
     * @param {string} email
     * @returns {Promise<void>}
     */
    forgetDevice(email) {
        const ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_forgetDevice(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * r" Whether any vault has edits waiting on this device.
     * @returns {Promise<boolean>}
     */
    hasAnyPendingEdits() {
        const ret = wasm.account_hasAnyPendingEdits(this.__wbg_ptr);
        return ret;
    }
    /**
     * r" Whether a vault has edits waiting on this device.
     * @param {string} vault_id
     * @returns {Promise<boolean>}
     */
    hasPendingEdits(vault_id) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_hasPendingEdits(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * r" Whether this device keeps the Secret Key for `email`.
     * @param {string} email
     * @returns {Promise<boolean>}
     */
    hasSecretKey(email) {
        const ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_hasSecretKey(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Imports a `.kdbx` into the account (new vault, merge or copies).
     * @param {Uint8Array | number[]} kdbx
     * @param {KdbxCredentials} credentials
     * @param {ImportMode} mode
     * @param {any | null} [signal]
     * @returns {Promise<ImportOutcome>}
     */
    importKdbx(kdbx, credentials, mode, signal) {
        const ptr0 = passArray8ToWasm0(kdbx, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_importKdbx(this.__wbg_ptr, ptr0, len0, credentials, mode, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Imports an already open vault.
     * @param {Vault} source
     * @param {ImportMode} mode
     * @param {any | null} [signal]
     * @returns {Promise<ImportOutcome>}
     */
    importVault(source, mode, signal) {
        _assertClass(source, Vault);
        const ret = wasm.account_importVault(this.__wbg_ptr, source.__wbg_ptr, mode, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" An org's open invitations.
     * @param {string} org_id
     * @param {any | null} [signal]
     * @returns {Promise<Invitation[]>}
     */
    invitations(org_id, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_invitations(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Invites an email to an org.
     * @param {string} org_id
     * @param {string} email
     * @param {OrgRole} role
     * @param {any | null} [signal]
     * @returns {Promise<Invitation>}
     */
    invite(org_id, email, role, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_invite(this.__wbg_ptr, ptr0, len0, ptr1, len1, role, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Working from the offline cache (SPEC §20).
     * @returns {boolean}
     */
    isOffline() {
        const ret = wasm.account_isOffline(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * A session is loaded (it may be locked).
     * @returns {boolean}
     */
    isSignedIn() {
        const ret = wasm.account_isSignedIn(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * The keyset is in memory.
     * @returns {boolean}
     */
    isUnlocked() {
        const ret = wasm.account_isUnlocked(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * r" Issues a new secret for a service account.
     * @param {string} sa_id
     * @param {string | null} [name]
     * @param {string | null} [expires_at]
     * @param {any | null} [signal]
     * @returns {Promise<IssuedSecret>}
     */
    issueServiceAccountSecret(sa_id, name, expires_at, signal) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = isLikeNone(name) ? 0 : passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = isLikeNone(expires_at) ? 0 : passStringToWasm0(expires_at, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_issueServiceAccountSecret(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Keeps an entry the AutoFill extension saved, for the app to merge later.
     * @param {string} vault_id
     * @param {EntryRecord} entry
     * @param {string} group_path
     * @returns {Promise<void>}
     */
    keepAutofillEdit(vault_id, entry, group_path) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(group_path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_keepAutofillEdit(this.__wbg_ptr, ptr0, len0, entry, ptr1, len1);
        return ret;
    }
    /**
     * r" Your share links.
     * @param {any | null} [signal]
     * @returns {Promise<ShareListing[]>}
     */
    listShares(signal) {
        const ret = wasm.account_listShares(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Clears the keyset and vault keys from memory. The session stays.
     */
    lock() {
        wasm.account_lock(this.__wbg_ptr);
    }
    /**
     * OPAQUE sign-in (SPEC §8), then unlock.
     * @param {LoginInput} input
     * @param {any | null} [signal]
     * @returns {Promise<LoginStep>}
     */
    login(input, signal) {
        const ret = wasm.account_login(this.__wbg_ptr, input, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Looks a user up by email for sharing.
     * @param {string} email
     * @param {any | null} [signal]
     * @returns {Promise<ShareRecipient>}
     */
    lookUp(email, signal) {
        const ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_lookUp(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" The org's vaults an admin manages.
     * @param {string} org_id
     * @param {any | null} [signal]
     * @returns {Promise<VaultInfo[]>}
     */
    managedOrgVaults(org_id, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_managedOrgVaults(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" `GET /me` (SPEC §16).
     * @param {any | null} [signal]
     * @returns {Promise<Profile>}
     */
    me(signal) {
        const ret = wasm.account_me(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" A vault's members.
     * @param {string} vault_id
     * @param {any | null} [signal]
     * @returns {Promise<VaultMember[]>}
     */
    members(vault_id, signal) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_members(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Opens this device's copy of a vault, without AutoFill's edits.
     * @param {string} vault_id
     * @returns {Promise<Vault>}
     */
    openCopy(vault_id) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_openCopy(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * r" Opens a vault from this device's copies only, plus AutoFill's edits.
     * @param {string} vault_id
     * @returns {Promise<Vault>}
     */
    openOffline(vault_id) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_openOffline(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Opens one saved version, read-only. `revision` is an integer.
     * @param {string} vault_id
     * @param {number} revision
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    openVaultVersion(vault_id, revision, signal) {
        const val2 = +revision;
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_openVaultVersion(this.__wbg_ptr, ptr0, len0, val2, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Downloads and opens a vault.
     * @param {string} vault_id
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    openVault(vault_id, signal) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_openVault(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" An org's members.
     * @param {string} org_id
     * @param {any | null} [signal]
     * @returns {Promise<Member[]>}
     */
    orgMembers(org_id, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_orgMembers(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" One org.
     * @param {string} org_id
     * @param {any | null} [signal]
     * @returns {Promise<Org>}
     */
    org(org_id, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_org(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" The orgs this account belongs to (SPEC §12).
     * @param {any | null} [signal]
     * @returns {Promise<OrgMembership[]>}
     */
    orgs(signal) {
        const ret = wasm.account_orgs(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Locks and sets this session aside (SPEC §21).
     * @returns {Promise<boolean>}
     */
    parkSession() {
        const ret = wasm.account_parkSession(this.__wbg_ptr);
        return ret;
    }
    /**
     * r" The account's plan (SPEC §19).
     * @param {any | null} [signal]
     * @returns {Promise<Plan | undefined>}
     */
    plan(signal) {
        const ret = wasm.account_plan(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * `user:<id>`; `signed_out` without a session.
     * @returns {Principal}
     */
    principal() {
        const ret = wasm.account_principal(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" A known principal as a share recipient.
     * @param {string} principal
     * @param {string | null} [display]
     * @param {any | null} [signal]
     * @returns {Promise<ShareRecipient>}
     */
    recipient(principal, display, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(principal, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = isLikeNone(display) ? 0 : passStringToWasm0(display, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_recipient(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Goes back online after working offline.
     * @param {any | null} [signal]
     * @returns {Promise<ReconnectResult>}
     */
    reconnect(signal) {
        const ret = wasm.account_reconnect(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" What a recovery link resets (SPEC §18).
     * @param {Uint8Array | number[]} token
     * @param {any | null} [signal]
     * @returns {Promise<RecoveryReset>}
     */
    recoverInfo(token, signal) {
        const ptr0 = passArray8ToWasm0(token, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_recoverInfo(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Resets the account from a recovery link (SPEC §18).
     * @param {Uint8Array | number[]} token
     * @param {Uint8Array | number[]} password
     * @param {KdfOverrides | undefined} kdf
     * @param {boolean} trust_device
     * @param {any | null} [signal]
     * @returns {Promise<NewAccount>}
     */
    recover(token, password, kdf, trust_device, signal) {
        const val3 = +trust_device;
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passArray8ToWasm0(token, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(password, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_recover(this.__wbg_ptr, ptr0, len0, ptr1, len1, kdf, val3, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Whether an archive from a reset can be restored.
     * @param {any | null} [signal]
     * @returns {Promise<RecoveryStatus>}
     */
    recoveryStatus(signal) {
        const ret = wasm.account_recoveryStatus(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Creates an account (SPEC §2, §3, §5, §8). Show the returned Secret Key once.
     * @param {RegisterInput} input
     * @param {any | null} [signal]
     * @returns {Promise<NewAccount>}
     */
    register(input, signal) {
        const ret = wasm.account_register(this.__wbg_ptr, input, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Removes a member (rotating the vaults they could open).
     * @param {string} org_id
     * @param {string} user_id
     * @param {any | null} [signal]
     * @returns {Promise<RotationReport>}
     */
    removeMember(org_id, user_id, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_removeMember(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Renames an org.
     * @param {string} org_id
     * @param {string} name
     * @param {any | null} [signal]
     * @returns {Promise<Org>}
     */
    renameOrg(org_id, name, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_renameOrg(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Renames a vault (needs `manage`).
     * @param {string} vault_id
     * @param {string} name
     * @param {any | null} [signal]
     * @returns {Promise<VaultInfo>}
     */
    renameVault(vault_id, name, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_renameVault(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Reports an App Store transaction.
     * @param {string} jws
     * @param {any | null} [signal]
     * @returns {Promise<AppleTransactionResult>}
     */
    reportAppleTransaction(jws, signal) {
        const ptr0 = passStringToWasm0(jws, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_reportAppleTransaction(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Sends a code to a new email address.
     * @param {string} email
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    requestEmailChange(email, signal) {
        const ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_requestEmailChange(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Cancels a scheduled deletion.
     * @param {Uint8Array | number[]} password
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    restoreAccount(password, signal) {
        const ptr0 = passArray8ToWasm0(password, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_restoreAccount(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Restores vaults from the archive with the old credentials.
     * @param {Uint8Array | number[]} old_password
     * @param {Uint8Array | number[]} old_secret_key
     * @param {any | null} [signal]
     * @returns {Promise<number>}
     */
    restoreFromArchive(old_password, old_secret_key, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passArray8ToWasm0(old_password, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(old_secret_key, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_restoreFromArchive(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Makes a parked session the active one.
     * @param {string} user_id
     * @returns {Promise<boolean>}
     */
    resumeSession(user_id) {
        const ptr0 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_resumeSession(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * r" Unlocks from keyset secrets saved by `unlockedKeysetSecret`.
     * @param {Uint8Array | number[]} keyset_secret
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    resumeUnlocked(keyset_secret, signal) {
        const ptr0 = passArray8ToWasm0(keyset_secret, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_resumeUnlocked(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Signs a device out.
     * @param {string} device_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    revokeDevice(device_id, signal) {
        const ptr0 = passStringToWasm0(device_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_revokeDevice(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Revokes a service-account secret.
     * @param {string} sa_id
     * @param {string} secret_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    revokeSecret(sa_id, secret_id, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(secret_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_revokeSecret(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Ends a share link.
     * @param {string} share_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    revokeShare(share_id, signal) {
        const ptr0 = passStringToWasm0(share_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_revokeShare(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Revokes members from a vault (rotating its key).
     * @param {string} vault_id
     * @param {string[]} principals
     * @param {any | null} [signal]
     * @returns {Promise<SyncReport>}
     */
    revoke(vault_id, principals, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArrayJsValueToWasm0(principals, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__externref_drop_slice(ptr1, len1); wasm.__wbindgen_free(ptr1, len1 * 4, 4); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_revoke(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Rotates every vault flagged for rotation.
     * @param {string} org_id
     * @param {any | null} [signal]
     * @returns {Promise<RotationReport>}
     */
    rotateFlagged(org_id, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_rotateFlagged(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Rotates a vault's key, optionally removing principals.
     * @param {string} vault_id
     * @param {string[]} remove
     * @param {any | null} [signal]
     * @returns {Promise<SyncReport>}
     */
    rotateVaultKey(vault_id, remove, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArrayJsValueToWasm0(remove, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__externref_drop_slice(ptr1, len1); wasm.__wbindgen_free(ptr1, len1 * 4, 4); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_rotateVaultKey(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" The Secret Key, to show again in settings.
     * @returns {Promise<Uint8Array | undefined>}
     */
    secretKey() {
        const ret = wasm.account_secretKey(this.__wbg_ptr);
        return ret;
    }
    /**
     * The server's discovery document.
     * @returns {ServerConfig}
     */
    serverConfig() {
        const ret = wasm.account_serverConfig(this.__wbg_ptr);
        return ret;
    }
    /**
     * r" A service account's secrets.
     * @param {string} sa_id
     * @param {any | null} [signal]
     * @returns {Promise<SaSecretInfo[]>}
     */
    serviceAccountSecrets(sa_id, signal) {
        const ptr0 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_serviceAccountSecrets(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" An org's service accounts.
     * @param {string} org_id
     * @param {any | null} [signal]
     * @returns {Promise<ServiceAccountInfo[]>}
     */
    serviceAccounts(org_id, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_serviceAccounts(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Promotes or demotes a member.
     * @param {string} org_id
     * @param {Member} member
     * @param {OrgRole} role
     * @param {any | null} [signal]
     * @returns {Promise<Member>}
     */
    setMemberRole(org_id, member, role, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_setMemberRole(this.__wbg_ptr, ptr0, len0, member, role, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Sets an org's item share-link policy.
     * @param {string} org_id
     * @param {ShareLinkPolicy} policy
     * @param {any | null} [signal]
     * @returns {Promise<Org>}
     */
    setOrgShareLinks(org_id, policy, signal) {
        const ptr0 = passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_setOrgShareLinks(this.__wbg_ptr, ptr0, len0, policy, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Changes a service-account secret's expiry.
     * @param {string} sa_id
     * @param {string} secret_id
     * @param {ExpiryChange} expires_at
     * @param {any | null} [signal]
     * @returns {Promise<SaSecretInfo>}
     */
    setSecretExpiry(sa_id, secret_id, expires_at, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(secret_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_setSecretExpiry(this.__wbg_ptr, ptr0, len0, ptr1, len1, expires_at, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The share page's base URL, if the server has one.
     * @returns {string | undefined}
     */
    shareBase() {
        const ret = wasm.account_shareBase(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * r" Why share links are blocked for an org (or personal vaults), if they are.
     * @param {string | null} [org_id]
     * @returns {Promise<string | undefined>}
     */
    shareBlockedReason(org_id) {
        var ptr0 = isLikeNone(org_id) ? 0 : passStringToWasm0(org_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_shareBlockedReason(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Shares a vault with a user (SPEC §7).
     * @param {string} vault_id
     * @param {Grantee} grantee
     * @param {VaultRole} role
     * @param {any | null} [signal]
     * @returns {Promise<GrantResult>}
     */
    shareVault(vault_id, grantee, role, signal) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_shareVault(this.__wbg_ptr, ptr0, len0, grantee, role, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * For a page closing on a shared session: locks and returns the logout request to fire.
     * @returns {HttpRequest | undefined}
     */
    signOutOnUnload() {
        const ret = wasm.account_signOutOnUnload(this.__wbg_ptr);
        return ret;
    }
    /**
     * r" Signs a parked session out.
     * @param {string} user_id
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    signOutParked(user_id, signal) {
        const ptr0 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_signOutParked(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Signs this device out (and with `forgetDevice` drops the kept Secret Key).
     * @param {boolean} forget_device
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    signOut(forget_device, signal) {
        const val1 = +forget_device;
        const ret = wasm.account_signOut(this.__wbg_ptr, val1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Completes the next time the server ends this session. Await it in a loop.
     * @param {any | null} [signal]
     * @returns {Promise<SignedOutReason>}
     */
    signedOut(signal) {
        const ret = wasm.account_signedOut(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Starts two-step sign-in setup (SPEC §8).
     * @param {any | null} [signal]
     * @returns {Promise<TotpSetup>}
     */
    startTwoStep(signal) {
        const ret = wasm.account_startTwoStep(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" The Secret Key this device keeps for `email`.
     * @param {string} email
     * @returns {Promise<Uint8Array | undefined>}
     */
    storedSecretKey(email) {
        const ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_storedSecretKey(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * r" The stored session (without tokens).
     * @returns {Promise<StoredSession | undefined>}
     */
    storedSession() {
        const ret = wasm.account_storedSession(this.__wbg_ptr);
        return ret;
    }
    /**
     * Sends a TOTP code for a waiting sign-in.
     * @param {TotpChallenge} challenge
     * @param {string} code
     * @param {any | null} [signal]
     * @returns {Promise<LoginStep>}
     */
    submitTotp(challenge, code, signal) {
        _assertClass(challenge, TotpChallenge);
        const ptr0 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_submitTotp(this.__wbg_ptr, challenge.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Live updates (SPEC §11).
     * @param {any | null} [signal]
     * @returns {Promise<EventStream>}
     */
    subscribe(signal) {
        const ret = wasm.account_subscribe(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Syncs an account vault held as `.kdbx` bytes (contract-v1.6).
     * @param {string} vault_id
     * @param {Uint8Array | number[]} kdbx
     * @param {Uint8Array | number[] | null | undefined} base
     * @param {SyncOptions | undefined} options
     * @param {any | null} [signal]
     * @returns {Promise<VaultKdbxSyncResult>}
     */
    syncVaultKdbx(vault_id, kdbx, base, options, signal) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(kdbx, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = isLikeNone(base) ? 0 : passArray8ToWasm0(base, wasm.__wbindgen_malloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_syncVaultKdbx(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, options, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Hands a vault to another member before deletion.
     * @param {string} vault_id
     * @param {string} to
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    transferVault(vault_id, to, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(to, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_transferVault(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Unlocks with an AUK kept behind biometrics.
     * @param {Uint8Array | number[]} auk
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    unlockWithAuk(auk, signal) {
        const ptr0 = passArray8ToWasm0(auk, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_unlockWithAuk(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Unlocks a signed-in session with the master password (offline: from the cache).
     * @param {Uint8Array | number[]} password
     * @param {Uint8Array | number[] | null} [secret_key]
     * @param {any | null} [signal]
     * @returns {Promise<Unlocked>}
     */
    unlock(password, secret_key, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passArray8ToWasm0(password, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = isLikeNone(secret_key) ? 0 : passArray8ToWasm0(secret_key, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.account_unlock(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The unlocked keyset's private halves (64 bytes), for the web's `sealUnlocked`.
     * @returns {Uint8Array}
     */
    unlockedKeysetSecret() {
        const ret = wasm.account_unlockedKeysetSecret(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Updates a service account.
     * @param {string} sa_id
     * @param {ServiceAccountUpdate} update
     * @param {any | null} [signal]
     * @returns {Promise<ServiceAccountInfo>}
     */
    updateServiceAccount(sa_id, update, signal) {
        const ptr0 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_updateServiceAccount(this.__wbg_ptr, ptr0, len0, update, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The upgrade page for a `plan_limit` / `quota_exceeded` error.
     * @param {OvError} error
     * @returns {string | undefined}
     */
    upgradeUrl(error) {
        const ret = wasm.account_upgradeUrl(this.__wbg_ptr, error);
        if (ret[3]) {
            throw takeFromExternrefTable0(ret[2]);
        }
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * The signed-in user's id.
     * @returns {string | undefined}
     */
    userId() {
        const ret = wasm.account_userId(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * r" The saved versions of a vault, newest first.
     * @param {string} vault_id
     * @param {any | null} [signal]
     * @returns {Promise<VaultVersion[]>}
     */
    vaultHistory(vault_id, signal) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_vaultHistory(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" The credentials an account vault's `.kdbx` is under (contract-v1.6). Wipe them.
     * @param {string} vault_id
     * @param {any | null} [signal]
     * @returns {Promise<KdbxCredentials>}
     */
    vaultKdbxCredentials(vault_id, signal) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_vaultKdbxCredentials(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" A vault's storage quota in bytes.
     * @param {string} vault_id
     * @returns {Promise<number | undefined>}
     */
    vaultQuota(vault_id) {
        const ptr0 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_vaultQuota(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * r" Every vault this account can open (SPEC §7).
     * @param {any | null} [signal]
     * @returns {Promise<VaultInfo[]>}
     */
    vaults(signal) {
        const ret = wasm.account_vaults(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" A principal's public keys, verified.
     * @param {string} principal
     * @param {any | null} [signal]
     * @returns {Promise<PublicKeys>}
     */
    verifiedPublicKeys(principal, signal) {
        const ptr0 = passStringToWasm0(principal, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_verifiedPublicKeys(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Asks the server whether this device's session still stands.
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    verifySession(signal) {
        const ret = wasm.account_verifySession(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" A one-time URL that signs the web app in.
     * @param {string | null} [next]
     * @param {any | null} [signal]
     * @returns {Promise<Uint8Array>}
     */
    webSessionUrl(next, signal) {
        var ptr0 = isLikeNone(next) ? 0 : passStringToWasm0(next, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.account_webSessionUrl(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
}
if (Symbol.dispose) Account.prototype[Symbol.dispose] = Account.prototype.free;

/**
 * Live updates: `await next()` in a loop until it resolves `undefined`.
 */
export class EventStream {
    static __wrap(ptr) {
        const obj = Object.create(EventStream.prototype);
        obj.__wbg_ptr = ptr;
        EventStreamFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        EventStreamFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_eventstream_free(ptr, 0);
    }
    /**
     * Closes the stream.
     */
    close() {
        wasm.eventstream_close(this.__wbg_ptr);
    }
    /**
     * The next event, or `undefined` once closed.
     * @param {any | null} [signal]
     * @returns {Promise<AccountEvent | undefined>}
     */
    next(signal) {
        const ret = wasm.eventstream_next(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Reconnects now (e.g. after the page comes back online).
     */
    reconnect() {
        wasm.eventstream_reconnect(this.__wbg_ptr);
    }
}
if (Symbol.dispose) EventStream.prototype[Symbol.dispose] = EventStream.prototype.free;

/**
 * One decrypted KDBX database. `Kdbx.read(bytes, key)` → inspect, merge, import → `write()`.
 * `free()` drops it (the decrypted model lives in the module's memory until then).
 */
export class Kdbx {
    static __wrap(ptr) {
        const obj = Object.create(Kdbx.prototype);
        obj.__wbg_ptr = ptr;
        KdbxFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        KdbxFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_kdbx_free(ptr, 0);
    }
    /**
     * Switches to the vault KDF (Argon2id, 1 GiB… as `VAULT_KDF`).
     */
    applyVaultKdf() {
        const ret = wasm.kdbx_applyVaultKdf(this.__wbg_ptr);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * A deep copy (with the same key).
     * @returns {Kdbx}
     */
    clone() {
        const ret = wasm.kdbx_clone(this.__wbg_ptr);
        return Kdbx.__wrap(ret);
    }
    /**
     * A new vault database keyed with a 32-byte vault key (ChaCha20, the vault KDF).
     * @param {string} name
     * @param {Uint8Array | number[]} vault_key
     * @param {number | null} [now_secs]
     * @returns {Kdbx}
     */
    static createVault(name, vault_key, now_secs) {
        const val3 = +(isLikeNone(now_secs) ? 0 : now_secs);
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(vault_key, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.kdbx_createVault(ptr0, len0, ptr1, len1, !isLikeNone(now_secs), val3);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Kdbx.__wrap(ret[0]);
    }
    /**
     * A new, empty database named `name` (KDBX 4, AES, Argon2d). Set a key with `setKey` before `write()`.
     * @param {string} name
     * @param {number | null} [now_secs]
     * @returns {Kdbx}
     */
    static create(name, now_secs) {
        const val2 = +(isLikeNone(now_secs) ? 0 : now_secs);
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.kdbx_create(ptr0, len0, !isLikeNone(now_secs), val2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Kdbx.__wrap(ret[0]);
    }
    /**
     * Removes the desktop's sync-server remotes from the database settings (an imported file).
     */
    dropServerRemotes() {
        wasm.kdbx_dropServerRemotes(this.__wbg_ptr);
    }
    /**
     * Every entry (Recycle Bin included), depth first, as the SDK's `collectAllDbData`.
     * @returns {KdbxEntryInfo[]}
     */
    entries() {
        const ret = wasm.kdbx_entries(this.__wbg_ptr);
        return ret;
    }
    /**
     * Conflicts between this (local) copy and `remote` since `snapshot` (SDK `findConflicts`).
     * @param {Kdbx} remote
     * @param {KdbxSnapshot} snapshot
     * @returns {KdbxSyncConflict[]}
     */
    findConflicts(remote, snapshot) {
        _assertClass(remote, Kdbx);
        const ret = wasm.kdbx_findConflicts(this.__wbg_ptr, remote.__wbg_ptr, snapshot);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Every group, depth first.
     * @returns {KdbxGroupInfo[]}
     */
    groups() {
        const ret = wasm.kdbx_groups(this.__wbg_ptr);
        return ret;
    }
    /**
     * Whether either side has deletions the other hasn't seen (SDK `hasPendingDeletions`).
     * @param {Kdbx} remote
     * @returns {boolean}
     */
    hasPendingDeletions(remote) {
        _assertClass(remote, Kdbx);
        const ret = wasm.kdbx_hasPendingDeletions(this.__wbg_ptr, remote.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * The outer-header settings it is saved with.
     * @returns {KdbxHeaderInfo}
     */
    header() {
        const ret = wasm.kdbx_header(this.__wbg_ptr);
        return ret;
    }
    /**
     * Imports `source`'s entries as new copies under the group `parentId` (SDK `importAsCopies`).
     * @param {Kdbx} source
     * @param {string} parent_id
     * @param {number | null} [now_secs]
     * @returns {KdbxImportSummary}
     */
    importAsCopies(source, parent_id, now_secs) {
        _assertClass(source, Kdbx);
        const val2 = +(isLikeNone(now_secs) ? 0 : now_secs);
        const ptr0 = passStringToWasm0(parent_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.kdbx_importAsCopies(this.__wbg_ptr, source.__wbg_ptr, ptr0, len0, !isLikeNone(now_secs), val2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Imports `source` by UUID, keeping newer versions and deleting nothing (SDK `importInto`).
     * @param {Kdbx} source
     * @returns {KdbxImportSummary}
     */
    importFrom(source) {
        _assertClass(source, Kdbx);
        const ret = wasm.kdbx_importFrom(this.__wbg_ptr, source.__wbg_ptr);
        return ret;
    }
    /**
     * Where entries can be imported to: `{ uuid, path }` for every group outside the Recycle Bin.
     * @returns {{ uuid: string; path: string }[]}
     */
    importTargets() {
        const ret = wasm.kdbx_importTargets(this.__wbg_ptr);
        return ret;
    }
    /**
     * The KDF settings the database is saved with.
     * @returns {KdbxKdfSettings}
     */
    kdfSettings() {
        const ret = wasm.kdbx_kdfSettings(this.__wbg_ptr);
        return ret;
    }
    /**
     * The one-way structure merge of `source` into this database (SDK `mergeInto`).
     * @param {Kdbx} source
     * @param {MergeMode} [mode]
     * @param {MergeIntoOptions} [opts]
     * @returns {KdbxMergeChange[]}
     */
    mergeFrom(source, mode, opts) {
        _assertClass(source, Kdbx);
        const ret = wasm.kdbx_mergeFrom(this.__wbg_ptr, source.__wbg_ptr, isLikeNone(mode) ? 0 : addToExternrefTable0(mode), isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The sync merge against `base`, the copy both last synced from.
     * @param {Kdbx} remote
     * @param {Kdbx} base
     * @param {number | null} [now_secs]
     * @returns {KdbxMergeReport}
     */
    mergeWithBase(remote, base, now_secs) {
        _assertClass(remote, Kdbx);
        _assertClass(base, Kdbx);
        const ret = wasm.kdbx_mergeWithBase(this.__wbg_ptr, remote.__wbg_ptr, base.__wbg_ptr, !isLikeNone(now_secs), isLikeNone(now_secs) ? 0 : now_secs);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The sync merge (SDK `mergeDatabases`) without a base: both copies end up with the same entries.
     * @param {Kdbx} remote
     * @param {number | null} [now_secs]
     * @returns {KdbxMergeReport}
     */
    merge(remote, now_secs) {
        _assertClass(remote, Kdbx);
        const ret = wasm.kdbx_merge(this.__wbg_ptr, remote.__wbg_ptr, !isLikeNone(now_secs), isLikeNone(now_secs) ? 0 : now_secs);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The database name (Meta).
     * @returns {string}
     */
    get name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.kdbx_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Whether the merge needs the common base (SDK `needsCommonBase`).
     * @param {Kdbx} remote
     * @param {KdbxSnapshot} snapshot
     * @returns {boolean}
     */
    needsCommonBase(remote, snapshot) {
        _assertClass(remote, Kdbx);
        const ret = wasm.kdbx_needsCommonBase(this.__wbg_ptr, remote.__wbg_ptr, snapshot);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return ret[0] !== 0;
    }
    /**
     * Opens a vault with the newest of its key versions that fits (SPEC §7): `{ db, keyVersion }`.
     * @param {Uint8Array | number[]} bytes
     * @param {KdbxKeyVersion[]} keys
     * @returns {{ db: Kdbx; keyVersion: number }}
     */
    static openWithKeyVersions(bytes, keys) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.kdbx_openWithKeyVersions(ptr0, len0, keys);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The outer header's settings, without the key.
     * @param {Uint8Array | number[]} bytes
     * @returns {KdbxHeaderInfo}
     */
    static peekHeader(bytes) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.kdbx_peekHeader(ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Opens a KDBX 3.1 or 4.x file. `vault_key_mismatch` for a wrong key, `kdbx_error` for a file
     * that isn't KDBX or is corrupt or unsupported. The key is kept for `write()`.
     * @param {Uint8Array | number[]} bytes
     * @param {KdbxKey} key
     * @returns {Kdbx}
     */
    static read(bytes, key) {
        const ptr0 = passArray8ToWasm0(bytes, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.kdbx_read(ptr0, len0, key);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return Kdbx.__wrap(ret[0]);
    }
    /**
     * Re-keys to a vault key: the vault KDF, and the vault key as the key from now on.
     * @param {Uint8Array | number[]} vault_key
     */
    rekeyToVaultKey(vault_key) {
        const ptr0 = passArray8ToWasm0(vault_key, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.kdbx_rekeyToVaultKey(this.__wbg_ptr, ptr0, len0);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The root group's id.
     * @returns {string}
     */
    get rootGroupId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.kdbx_rootGroupId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Replaces the key `write()` uses.
     * @param {KdbxKey} key
     */
    setKey(key) {
        const ret = wasm.kdbx_setKey(this.__wbg_ptr, key);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * Sets the sync generation.
     * @param {number} generation
     * @param {number | null} [now_secs]
     */
    setSyncGeneration(generation, now_secs) {
        const ret = wasm.kdbx_setSyncGeneration(this.__wbg_ptr, generation, !isLikeNone(now_secs), isLikeNone(now_secs) ? 0 : now_secs);
        if (ret[1]) {
            throw takeFromExternrefTable0(ret[0]);
        }
    }
    /**
     * The snapshot to keep after a sync (SDK `snapshotOf`).
     * @returns {KdbxSnapshot}
     */
    snapshot() {
        const ret = wasm.kdbx_snapshot(this.__wbg_ptr);
        return ret;
    }
    /**
     * The sync generation in the custom data (0 when absent).
     * @returns {number}
     */
    syncGeneration() {
        const ret = wasm.kdbx_syncGeneration(this.__wbg_ptr);
        return ret;
    }
    /**
     * Saves as KDBX 4 with `key`, or the key it was read or created with.
     * @param {KdbxKey} [key]
     * @returns {Uint8Array}
     */
    write(key) {
        const ret = wasm.kdbx_write(this.__wbg_ptr, isLikeNone(key) ? 0 : addToExternrefTable0(key));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
}
if (Symbol.dispose) Kdbx.prototype[Symbol.dispose] = Kdbx.prototype.free;

/**
 * The entry point: one per app (or per test). `new OvClient(config, host)`.
 */
export class OvClient {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        OvClientFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_ovclient_free(ptr, 0);
    }
    /**
     * The settings this client was made with.
     * @returns {ClientConfig}
     */
    config() {
        const ret = wasm.ovclient_config(this.__wbg_ptr);
        return ret;
    }
    /**
     * Discovers the server and loads a stored session (signed in but locked).
     * @param {string} issuer
     * @param {any | null} [signal]
     * @returns {Promise<Account>}
     */
    connect(issuer, signal) {
        const ptr0 = passStringToWasm0(issuer, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ovclient_connect(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Creates a new local database on this client's Host clock (contract-v1.6).
     * @param {string} name
     * @param {KdbxCredentials} credentials
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    createLocal(name, credentials, signal) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ovclient_createLocal(this.__wbg_ptr, ptr0, len0, credentials, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Fetches and checks the discovery document (SPEC §10).
     * @param {string} issuer
     * @param {any | null} [signal]
     * @returns {Promise<ServerConfig>}
     */
    discover(issuer, signal) {
        const ptr0 = passStringToWasm0(issuer, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ovclient_discover(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Removes an account from the remembered list.
     * @param {string} issuer
     * @param {string} user_id
     * @returns {Promise<void>}
     */
    forgetRemembered(issuer, user_id) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(issuer, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.ovclient_forgetRemembered(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * Whether a user's offline cache holds edits not yet uploaded.
     * @param {string} user_id
     * @returns {Promise<boolean>}
     */
    hasPendingEdits(user_id) {
        const ptr0 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ovclient_hasPendingEdits(this.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * Records that the server confirmed the account's parked session now.
     * @param {string} issuer
     * @param {string} user_id
     * @returns {Promise<void>}
     */
    markRememberedChecked(issuer, user_id) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(issuer, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.ovclient_markRememberedChecked(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * A client over `host` (see `host/` in the package for ready-made adapters). Does no I/O.
     * @param {ClientConfig} config
     * @param {Host} host
     */
    constructor(config, host) {
        const ret = wasm.ovclient_new(config, host);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        OvClientFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * Opens a local `.kdbx`; edits are stamped with this client's Host clock (contract-v1.6).
     * @param {Uint8Array | number[]} kdbx
     * @param {KdbxCredentials} credentials
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    openLocal(kdbx, credentials, signal) {
        const ptr0 = passArray8ToWasm0(kdbx, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.ovclient_openLocal(this.__wbg_ptr, ptr0, len0, credentials, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Opens a share link (SPEC §22).
     * @param {string} api
     * @param {Uint8Array | number[]} link
     * @param {Uint8Array | number[] | null | undefined} passcode
     * @param {ShareInfo | undefined} info
     * @param {any | null} [signal]
     * @returns {Promise<OpenedShare>}
     */
    openShare(api, link, passcode, info, signal) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(api, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(link, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = isLikeNone(passcode) ? 0 : passArray8ToWasm0(passcode, wasm.__wbindgen_malloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.ovclient_openShare(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, info, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Adds or refreshes a remembered account.
     * @param {string} email
     * @param {string} issuer
     * @param {string} user_id
     * @returns {Promise<void>}
     */
    rememberAccount(email, issuer, user_id) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(issuer, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.ovclient_rememberAccount(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        return ret;
    }
    /**
     * Remembered accounts, most recently used first (SPEC §21).
     * @returns {Promise<RememberedAccount[]>}
     */
    rememberedAccounts() {
        const ret = wasm.ovclient_rememberedAccounts(this.__wbg_ptr);
        return ret;
    }
    /**
     * Active, parked or no session for a user on this device (no network).
     * @param {string} issuer
     * @param {string} user_id
     * @returns {Promise<SessionState>}
     */
    sessionState(issuer, user_id) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(issuer, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.ovclient_sessionState(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        return ret;
    }
    /**
     * Records (or clears) a remembered account's erase date (SPEC §23).
     * @param {string} issuer
     * @param {string} user_id
     * @param {string | null} [at]
     * @returns {Promise<void>}
     */
    setRememberedDeletion(issuer, user_id, at) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(issuer, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = isLikeNone(at) ? 0 : passStringToWasm0(at, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.ovclient_setRememberedDeletion(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        return ret;
    }
    /**
     * What the public share page knows before opening a share (SPEC §22).
     * @param {string} api
     * @param {string} share_id
     * @param {any | null} [signal]
     * @returns {Promise<ShareInfo>}
     */
    shareInfo(api, share_id, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(api, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(share_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.ovclient_shareInfo(this.__wbg_ptr, ptr0, len0, ptr1, len1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
}
if (Symbol.dispose) OvClient.prototype[Symbol.dispose] = OvClient.prototype.free;

/**
 * A self-hosted sync server (SPEC §13).
 */
export class SelfHosted {
    static __wrap(ptr) {
        const obj = Object.create(SelfHosted.prototype);
        obj.__wbg_ptr = ptr;
        SelfHostedFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        SelfHostedFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_selfhosted_free(ptr, 0);
    }
    /**
     * Connects with a device token.
     * @param {OvClient} client
     * @param {string} server_url
     * @param {Uint8Array | number[]} device_token
     * @returns {SelfHosted}
     */
    static connect(client, server_url, device_token) {
        _assertClass(client, OvClient);
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(server_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(device_token, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.selfhosted_connect(client.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return SelfHosted.__wrap(ret[0]);
    }
    /**
     * A code to pair another device.
     * @param {any | null} [signal]
     * @returns {Promise<PairingCode>}
     */
    createPairingCode(signal) {
        const ret = wasm.selfhosted_createPairingCode(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Live updates from the server.
     * @param {any | null} [signal]
     * @returns {Promise<EventStream>}
     */
    events(signal) {
        const ret = wasm.selfhosted_events(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The server's health text.
     * @param {any | null} [signal]
     * @returns {Promise<string>}
     */
    health(signal) {
        const ret = wasm.selfhosted_health(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The versions the server keeps of a database, newest first (contract-v1.6).
     * @param {string} database_id
     * @param {any | null} [signal]
     * @returns {Promise<VaultVersion[]>}
     */
    history(database_id, signal) {
        const ptr0 = passStringToWasm0(database_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.selfhosted_history(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The databases on the server.
     * @param {any | null} [signal]
     * @returns {Promise<BlobMeta[]>}
     */
    listDatabases(signal) {
        const ret = wasm.selfhosted_listDatabases(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Opens one kept version of a database, read-only (contract-v1.6).
     * @param {string} database_id
     * @param {number} revision
     * @param {KdbxCredentials} credentials
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    openVersion(database_id, revision, credentials, signal) {
        const val2 = +revision;
        const ptr0 = passStringToWasm0(database_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.selfhosted_openVersion(this.__wbg_ptr, ptr0, len0, val2, credentials, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Pairs this device with a pairing code.
     * @param {OvClient} client
     * @param {string} server_url
     * @param {string} code
     * @param {string} device_name
     * @param {any | null} [signal]
     * @returns {Promise<SelfHosted>}
     */
    static pair(client, server_url, code, device_name, signal) {
        _assertClass(client, OvClient);
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(server_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(code, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passStringToWasm0(device_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.selfhosted_pair(client.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Reconnects with the device token kept in the secure store.
     * @param {OvClient} client
     * @param {string} server_url
     * @returns {Promise<SelfHosted | undefined>}
     */
    static restore(client, server_url) {
        _assertClass(client, OvClient);
        const ptr0 = passStringToWasm0(server_url, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.selfhosted_restore(client.__wbg_ptr, ptr0, len0);
        return ret;
    }
    /**
     * The server URL.
     * @returns {string}
     */
    serverUrl() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.selfhosted_serverUrl(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Syncs a local `.kdbx` with the server's copy.
     * @param {string} database_id
     * @param {Uint8Array | number[]} kdbx
     * @param {KdbxCredentials} credentials
     * @param {any | null} [signal]
     * @returns {Promise<SelfHostedSyncResult>}
     */
    syncDatabase(database_id, kdbx, credentials, signal) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(database_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(kdbx, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.selfhosted_syncDatabase(this.__wbg_ptr, ptr0, len0, ptr1, len1, credentials, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
}
if (Symbol.dispose) SelfHosted.prototype[Symbol.dispose] = SelfHosted.prototype.free;

/**
 * A service account signed in with its token (SPEC §9, §15).
 */
export class ServiceAccount {
    static __wrap(ptr) {
        const obj = Object.create(ServiceAccount.prototype);
        obj.__wbg_ptr = ptr;
        ServiceAccountFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ServiceAccountFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_serviceaccount_free(ptr, 0);
    }
    /**
     * Drops the keys from memory.
     */
    close() {
        wasm.serviceaccount_close(this.__wbg_ptr);
    }
    /**
     * Signs in with a service-account token.
     * @param {OvClient} client
     * @param {Uint8Array | number[]} token
     * @param {any | null} [signal]
     * @returns {Promise<ServiceAccount>}
     */
    static fromToken(client, token, signal) {
        _assertClass(client, OvClient);
        const ptr0 = passArray8ToWasm0(token, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serviceaccount_fromToken(client.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Replaces `ov://` references in a template.
     * @param {Uint8Array | number[]} template
     * @param {any | null} [signal]
     * @returns {Promise<Injected>}
     */
    inject(template, signal) {
        const ptr0 = passArray8ToWasm0(template, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serviceaccount_inject(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The server's issuer (contract-v1.6).
     * @returns {string}
     */
    issuer() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.serviceaccount_issuer(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Opens a vault by id or name.
     * @param {string} id_or_name
     * @param {boolean} refresh
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    openVault(id_or_name, refresh, signal) {
        const val2 = +refresh;
        const ptr0 = passStringToWasm0(id_or_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serviceaccount_openVault(this.__wbg_ptr, ptr0, len0, val2, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * `sa:<id>`.
     * @returns {string}
     */
    principal() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.serviceaccount_principal(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Opens a vault, always downloading it.
     * @param {string} id_or_name
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    pull(id_or_name, signal) {
        const ptr0 = passStringToWasm0(id_or_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serviceaccount_pull(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Reads a secret by reference.
     * @param {string} reference
     * @param {any | null} [signal]
     * @returns {Promise<Uint8Array>}
     */
    read(reference, signal) {
        const ptr0 = passStringToWasm0(reference, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serviceaccount_read(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The service account's id.
     * @returns {string}
     */
    saId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.serviceaccount_saId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * The server it signed in to (contract-v1.6).
     * @returns {ServerConfig}
     */
    serverConfig() {
        const ret = wasm.serviceaccount_serverConfig(this.__wbg_ptr);
        return ret;
    }
    /**
     * One vault by id or name.
     * @param {string} id_or_name
     * @param {any | null} [signal]
     * @returns {Promise<SaVault>}
     */
    vault(id_or_name, signal) {
        const ptr0 = passStringToWasm0(id_or_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.serviceaccount_vault(this.__wbg_ptr, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * The vaults it can open.
     * @param {boolean} refresh
     * @param {any | null} [signal]
     * @returns {Promise<SaVault[]>}
     */
    vaults(refresh, signal) {
        const val1 = +refresh;
        const ret = wasm.serviceaccount_vaults(this.__wbg_ptr, val1, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Writes a secret by reference.
     * @param {string} reference
     * @param {Uint8Array | number[]} value
     * @param {boolean} create
     * @param {any | null} [signal]
     * @returns {Promise<void>}
     */
    write(reference, value, create, signal) {
        const val3 = +create;
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(reference, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(value, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.serviceaccount_write(this.__wbg_ptr, ptr0, len0, ptr1, len1, val3, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
}
if (Symbol.dispose) ServiceAccount.prototype[Symbol.dispose] = ServiceAccount.prototype.free;

/**
 * A share link being opened (the TS `openShare` minus HTTP): built from the link, the share's
 * public `kdf` (when it has a passcode) and the passcode, so the Argon2 work happens once. Send
 * `requestBody()` to `POST {api}/public/shares/{id}/open`, then `decrypt` the returned `ct`.
 * `free()` wipes the keys.
 */
export class ShareOpen {
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        ShareOpenFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_shareopen_free(ptr, 0);
    }
    /**
     * `auth` (base64url) when the share has a passcode.
     * @returns {Uint8Array | undefined}
     */
    get auth() {
        const ret = wasm.shareopen_auth(this.__wbg_ptr);
        return ret;
    }
    /**
     * The link's base (the share page).
     * @returns {string}
     */
    get base() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.shareopen_base(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Decrypts the share's `ct` (bytes, or base64url as the server sends it).
     * @param {Uint8Array | string} ct
     * @returns {SharePayload}
     */
    decrypt(ct) {
        const ret = wasm.shareopen_decrypt(this.__wbg_ptr, ct);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The share id.
     * @returns {string}
     */
    get id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.shareopen_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * `passcode_required` when the share has a `kdf` and no passcode is given, `weak_kdf` below the
     * SPEC minimum, `invalid_link` for a bad link.
     * @param {string | Uint8Array} link
     * @param {KdfParams} [kdf]
     * @param {string | Uint8Array} [passcode]
     */
    constructor(link, kdf, passcode) {
        const ret = wasm.shareopen_new(link, isLikeNone(kdf) ? 0 : addToExternrefTable0(kdf), isLikeNone(passcode) ? 0 : addToExternrefTable0(passcode));
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        this.__wbg_ptr = ret[0];
        ShareOpenFinalization.register(this, this.__wbg_ptr, this);
        return this;
    }
    /**
     * The JSON body of the open request (UTF-8): `{"auth":"…"}` or `{}`.
     * @returns {Uint8Array}
     */
    requestBody() {
        const ret = wasm.shareopen_requestBody(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) ShareOpen.prototype[Symbol.dispose] = ShareOpen.prototype.free;

/**
 * A sign-in waiting for a TOTP code. Pass it to `Account.submitTotp`.
 */
export class TotpChallenge {
    static __wrap(ptr) {
        const obj = Object.create(TotpChallenge.prototype);
        obj.__wbg_ptr = ptr;
        TotpChallengeFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        TotpChallengeFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_totpchallenge_free(ptr, 0);
    }
    /**
     * Which try this is, from 1.
     * @returns {number}
     */
    attempt() {
        const ret = wasm.totpchallenge_attempt(this.__wbg_ptr);
        return ret >>> 0;
    }
    /**
     * The previous wrong code's error (`invalid_mfa`), if any.
     * @returns {OvError | undefined}
     */
    lastError() {
        const ret = wasm.totpchallenge_lastError(this.__wbg_ptr);
        return ret;
    }
}
if (Symbol.dispose) TotpChallenge.prototype[Symbol.dispose] = TotpChallenge.prototype.free;

/**
 * One open vault: an account vault, a local file, or a read-only saved version.
 */
export class Vault {
    static __wrap(ptr) {
        const obj = Object.create(Vault.prototype);
        obj.__wbg_ptr = ptr;
        VaultFinalization.register(obj, obj.__wbg_ptr, obj);
        return obj;
    }
    __destroy_into_raw() {
        const ptr = this.__wbg_ptr;
        this.__wbg_ptr = 0;
        VaultFinalization.unregister(this);
        return ptr;
    }
    free() {
        const ptr = this.__destroy_into_raw();
        wasm.__wbg_vault_free(ptr, 0);
    }
    /**
     * r" Adds a custom icon; returns its id.
     * @param {Uint8Array | number[]} png
     * @returns {string}
     */
    addCustomIcon(png) {
        const ptr0 = passArray8ToWasm0(png, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_addCustomIcon(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Adds an entry with an id the caller chose; returns it normalized (contract-v1.6).
     * @param {string} entry_id
     * @param {string} group_id
     * @param {EntryInput} input
     * @returns {string}
     */
    addEntryWithId(entry_id, group_id, input) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(group_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_addEntryWithId(this.__wbg_ptr, ptr0, len0, ptr1, len1, input);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Adds an entry; returns its id.
     * @param {string} group_id
     * @param {EntryInput} input
     * @returns {string}
     */
    addEntry(group_id, input) {
        const ptr0 = passStringToWasm0(group_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_addEntry(this.__wbg_ptr, ptr0, len0, input);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Adds a group; returns its id.
     * @param {string | null | undefined} parent_id
     * @param {string} name
     * @returns {string}
     */
    addGroup(parent_id, name) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = isLikeNone(parent_id) ? 0 : passStringToWasm0(parent_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_addGroup(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Merges AutoFill's edits into this vault.
     * @param {AutoFillEdits} edits
     * @returns {boolean}
     */
    applyAutofillEdits(edits) {
        const ret = wasm.vault_applyAutofillEdits(this.__wbg_ptr, edits);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" An attachment's bytes.
     * @param {string} entry_id
     * @param {string} name
     * @returns {Uint8Array}
     */
    attachment(entry_id, name) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_attachment(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Conflicts from the last sync.
     * @returns {SyncConflict[]}
     */
    conflicts() {
        const ret = wasm.vault_conflicts(this.__wbg_ptr);
        return ret;
    }
    /**
     * A local copy without sync-server remotes; `credentials` default to a local file's own
     * (contract-v1.6).
     * @param {KdbxCredentials | undefined} credentials
     * @returns {Vault}
     */
    copyWithoutRemotes(credentials) {
        const ret = wasm.vault_copyWithoutRemotes(this.__wbg_ptr, credentials);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Creates a new local database.
     * @param {string} name
     * @param {KdbxCredentials} credentials
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    static createLocal(name, credentials, signal) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_createLocal(ptr0, len0, credentials, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" A custom icon's PNG bytes.
     * @param {string} icon_id
     * @returns {Uint8Array}
     */
    customIcon(icon_id) {
        const ptr0 = passStringToWasm0(icon_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_customIcon(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Deletes an entry (to the Recycle Bin when enabled).
     * @param {string} entry_id
     * @returns {undefined}
     */
    deleteEntry(entry_id) {
        const ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_deleteEntry(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Deletes a group.
     * @param {string} group_id
     * @returns {undefined}
     */
    deleteGroup(group_id) {
        const ptr0 = passStringToWasm0(group_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_deleteGroup(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Edits an entry (keeping a history copy).
     * @param {string} entry_id
     * @param {EntryInput} input
     * @returns {undefined}
     */
    editEntry(entry_id, input) {
        const ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_editEntry(this.__wbg_ptr, ptr0, len0, input);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Empties the Recycle Bin.
     * @returns {undefined}
     */
    emptyRecycleBin() {
        const ret = wasm.vault_emptyRecycleBin(this.__wbg_ptr);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" The group at a path, creating missing groups; returns its id.
     * @param {string} path
     * @returns {string}
     */
    ensureGroup(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_ensureGroup(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Every entry (optionally including the Recycle Bin).
     * @param {boolean} include_recycle_bin
     * @returns {EntrySummary[]}
     */
    entries(include_recycle_bin) {
        const ret = wasm.vault_entries(this.__wbg_ptr, include_recycle_bin);
        return ret;
    }
    /**
     * Every entry with its values (contract-v1.6).
     * @param {boolean} include_recycle_bin
     * @returns {EntryRecord[]}
     */
    entryRecords(include_recycle_bin) {
        const ret = wasm.vault_entryRecords(this.__wbg_ptr, include_recycle_bin);
        return ret;
    }
    /**
     * r" One entry by id.
     * @param {string} entry_id
     * @returns {EntryRecord}
     */
    entry(entry_id) {
        const ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_entry(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The ETag of the last sync.
     * @returns {string | undefined}
     */
    etag() {
        const ret = wasm.vault_etag(this.__wbg_ptr);
        let v1;
        if (ret[0] !== 0) {
            v1 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v1;
    }
    /**
     * Exports as a `.kdbx` with a chosen key derivation (contract-v1.6).
     * @param {KdbxCredentials} credentials
     * @param {string[] | null | undefined} group_ids
     * @param {KdbxKdf} kdf
     * @param {any | null} [signal]
     * @returns {Promise<Uint8Array>}
     */
    exportKdbxWith(credentials, group_ids, kdf, signal) {
        var ptr0 = isLikeNone(group_ids) ? 0 : passArrayJsValueToWasm0(group_ids, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_exportKdbxWith(this.__wbg_ptr, credentials, ptr0, len0, kdf, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Exports as a `.kdbx` under new credentials (optionally only some groups).
     * @param {KdbxCredentials} credentials
     * @param {string[] | null} [group_ids]
     * @param {any | null} [signal]
     * @returns {Promise<Uint8Array>}
     */
    exportKdbx(credentials, group_ids, signal) {
        var ptr0 = isLikeNone(group_ids) ? 0 : passArrayJsValueToWasm0(group_ids, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_exportKdbx(this.__wbg_ptr, credentials, ptr0, len0, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * Exports in the clear (CSV or JSON).
     * @param {ExportFormat} format
     * @param {string[] | null} [group_ids]
     * @returns {Uint8Array}
     */
    exportPlain(format, group_ids) {
        var ptr0 = isLikeNone(group_ids) ? 0 : passArrayJsValueToWasm0(group_ids, wasm.__wbindgen_malloc);
        var len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_exportPlain(this.__wbg_ptr, format, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" One entry by reference (`ov://vault/item/field`, id or title).
     * @param {string} reference
     * @returns {EntryRecord}
     */
    find(reference) {
        const ptr0 = passStringToWasm0(reference, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_find(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The group at a `/`-separated path.
     * @param {string} path
     * @returns {string | undefined}
     */
    groupIdAt(path) {
        const ptr0 = passStringToWasm0(path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_groupIdAt(this.__wbg_ptr, ptr0, len0);
        let v2;
        if (ret[0] !== 0) {
            v2 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * Every group.
     * @returns {GroupInfo[]}
     */
    groups() {
        const ret = wasm.vault_groups(this.__wbg_ptr);
        return ret;
    }
    /**
     * Whether this vault has edits waiting for its next upload.
     * @returns {Promise<boolean>}
     */
    hasPendingEdits() {
        const ret = wasm.vault_hasPendingEdits(this.__wbg_ptr);
        return ret;
    }
    /**
     * r" An entry's history, oldest first.
     * @param {string} entry_id
     * @returns {EntryRecord[]}
     */
    history(entry_id) {
        const ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_history(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The vault id (or the local database's id).
     * @returns {string}
     */
    id() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.vault_id(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Imports another open vault into this one (contract-v1.6).
     * @param {Vault} source
     * @param {LocalImportMode} mode
     * @returns {ImportSummary}
     */
    importFrom(source, mode) {
        _assertClass(source, Vault);
        const ret = wasm.vault_importFrom(this.__wbg_ptr, source.__wbg_ptr, mode);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * What importing this vault elsewhere would bring in (contract-v1.6).
     * @returns {ImportPreview}
     */
    importPreview() {
        const ret = wasm.vault_importPreview(this.__wbg_ptr);
        return ret;
    }
    /**
     * The groups an import can go into (contract-v1.6).
     * @returns {ImportTarget[]}
     */
    importTargets() {
        const ret = wasm.vault_importTargets(this.__wbg_ptr);
        return ret;
    }
    /**
     * The account vault's info (`undefined` for a local file).
     * @returns {VaultInfo | undefined}
     */
    info() {
        const ret = wasm.vault_info(this.__wbg_ptr);
        return ret;
    }
    /**
     * Whether an entry or group is in the Recycle Bin.
     * @param {string} id
     * @returns {boolean}
     */
    isInRecycleBin(id) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_isInRecycleBin(this.__wbg_ptr, ptr0, len0);
        return ret !== 0;
    }
    /**
     * Opened from this device's copy because the server couldn't be reached.
     * @returns {boolean}
     */
    isOffline() {
        const ret = wasm.vault_isOffline(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * A saved version, or a vault this account can only read.
     * @returns {boolean}
     */
    isReadOnly() {
        const ret = wasm.vault_isReadOnly(this.__wbg_ptr);
        return ret !== 0;
    }
    /**
     * Keeps local edits in the offline cache without syncing.
     * @returns {Promise<void>}
     */
    keepEdits() {
        const ret = wasm.vault_keepEdits(this.__wbg_ptr);
        return ret;
    }
    /**
     * A database custom data value (contract-v1.6).
     * @param {string} key
     * @returns {string | undefined}
     */
    metaCustomData(key) {
        const ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_metaCustomData(this.__wbg_ptr, ptr0, len0);
        let v2;
        if (ret[0] !== 0) {
            v2 = getStringFromWasm0(ret[0], ret[1]);
            wasm.__wbindgen_free(ret[0], ret[1] * 1, 1);
        }
        return v2;
    }
    /**
     * r" Moves an entry to another group.
     * @param {string} entry_id
     * @param {string} group_id
     * @returns {undefined}
     */
    moveEntry(entry_id, group_id) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(group_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_moveEntry(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Moves a group.
     * @param {string} group_id
     * @param {string} parent_id
     * @returns {undefined}
     */
    moveGroup(group_id, parent_id) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(group_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(parent_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_moveGroup(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The vault's name.
     * @returns {string}
     */
    name() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.vault_name(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Opens a local `.kdbx`.
     * @param {Uint8Array | number[]} kdbx
     * @param {KdbxCredentials} credentials
     * @param {any | null} [signal]
     * @returns {Promise<Vault>}
     */
    static openLocal(kdbx, credentials, signal) {
        const ptr0 = passArray8ToWasm0(kdbx, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_openLocal(ptr0, len0, credentials, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" One field's value by reference.
     * @param {string} reference
     * @returns {Uint8Array}
     */
    readField(reference) {
        const ptr0 = passStringToWasm0(reference, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_readField(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Removes an attachment.
     * @param {string} entry_id
     * @param {string} name
     * @returns {undefined}
     */
    removeAttachment(entry_id, name) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_removeAttachment(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Renames a group.
     * @param {string} group_id
     * @param {string} name
     * @returns {undefined}
     */
    renameGroup(group_id, name) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(group_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_renameGroup(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Restores an entry from a saved version.
     * @param {Vault} version
     * @param {string} entry_id
     * @param {string} group_path
     * @returns {undefined}
     */
    restoreEntry(version, entry_id, group_path) {
        _assertClass(version, Vault);
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(group_path, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_restoreEntry(this.__wbg_ptr, version.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Restores an entry or group from the Recycle Bin.
     * @param {string} id
     * @returns {undefined}
     */
    restoreFromRecycleBin(id) {
        const ptr0 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_restoreFromRecycleBin(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * The root group's id.
     * @returns {string}
     */
    rootGroupId() {
        let deferred1_0;
        let deferred1_1;
        try {
            const ret = wasm.vault_rootGroupId(this.__wbg_ptr);
            deferred1_0 = ret[0];
            deferred1_1 = ret[1];
            return getStringFromWasm0(ret[0], ret[1]);
        } finally {
            wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
        }
    }
    /**
     * Encrypts a local database for saving.
     * @param {any | null} [signal]
     * @returns {Promise<Uint8Array>}
     */
    saveLocal(signal) {
        const ret = wasm.vault_saveLocal(this.__wbg_ptr, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * r" Adds or replaces an attachment with its protected flag; `undefined` keeps the replaced one's
     * r" (contract-v1.6).
     * @param {string} entry_id
     * @param {string} name
     * @param {Uint8Array | number[]} data
     * @param {boolean | null} [_protected]
     * @returns {undefined}
     */
    setAttachmentWith(entry_id, name, data, _protected) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_setAttachmentWith(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2, isLikeNone(_protected) ? 0xFFFFFF : _protected ? 1 : 0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Adds or replaces an attachment.
     * @param {string} entry_id
     * @param {string} name
     * @param {Uint8Array | number[]} data
     * @returns {undefined}
     */
    setAttachment(entry_id, name, data) {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_setAttachment(this.__wbg_ptr, ptr0, len0, ptr1, len1, ptr2, len2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Sets several fields of an entry found by reference.
     * @param {string} reference
     * @param {FieldInput[]} fields
     * @param {CreateMode} create
     * @returns {SetFieldsResult}
     */
    setFields(reference, fields, create) {
        const ptr0 = passStringToWasm0(reference, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_setFields(this.__wbg_ptr, ptr0, len0, fields, create);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Sets a group's icon.
     * @param {string} group_id
     * @param {number} icon_id
     * @returns {undefined}
     */
    setGroupIcon(group_id, icon_id) {
        const val2 = +icon_id;
        const ptr0 = passStringToWasm0(group_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_setGroupIcon(this.__wbg_ptr, ptr0, len0, val2);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Sets a local database's key derivation (contract-v1.6).
     * @param {KdbxKdf} kdf
     * @returns {undefined}
     */
    setKdf(kdf) {
        const ret = wasm.vault_setKdf(this.__wbg_ptr, kdf);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Sets (a string) or removes (`undefined`) a database custom data item (contract-v1.6).
     * @param {string} key
     * @param {string | null} [value]
     * @returns {undefined}
     */
    setMetaCustomData(key, value) {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(key, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = isLikeNone(value) ? 0 : passStringToWasm0(value, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_setMetaCustomData(this.__wbg_ptr, ptr0, len0, ptr1, len1);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * r" Renames a local database (contract-v1.6).
     * @param {string} name
     * @returns {undefined}
     */
    setName(name) {
        const ptr0 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_setName(this.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Syncs with the server (SPEC §11).
     * @param {SyncOptions | undefined} options
     * @param {any | null} [signal]
     * @returns {Promise<SyncReport>}
     */
    sync(options, signal) {
        const ret = wasm.vault_sync(this.__wbg_ptr, options, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
    /**
     * How an entry differs between this vault and a saved version.
     * @param {Vault} version
     * @param {string} entry_id
     * @returns {VersionDifference}
     */
    versionDifference(version, entry_id) {
        _assertClass(version, Vault);
        const ptr0 = passStringToWasm0(entry_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.vault_versionDifference(this.__wbg_ptr, version.__wbg_ptr, ptr0, len0);
        if (ret[2]) {
            throw takeFromExternrefTable0(ret[1]);
        }
        return takeFromExternrefTable0(ret[0]);
    }
    /**
     * Writes one field and syncs (TS `AccountVault.write`).
     * @param {string} reference
     * @param {Uint8Array | number[]} value
     * @param {boolean} create
     * @param {any | null} [signal]
     * @returns {Promise<SyncReport>}
     */
    writeField(reference, value, create, signal) {
        const val3 = +create;
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passStringToWasm0(reference, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(value, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.vault_writeField(this.__wbg_ptr, ptr0, len0, ptr1, len1, val3, isLikeNone(signal) ? 0 : addToExternrefTable0(signal));
        return ret;
    }
}
if (Symbol.dispose) Vault.prototype[Symbol.dispose] = Vault.prototype.free;

/**
 * Called once by `index.js` at load: the `OvError` class to construct errors with, and the
 * callback a panic reports to before the module traps.
 * @param {Function} error_class
 * @param {Function} on_panic
 */
export function __install(error_class, on_panic) {
    wasm.__install(error_class, on_panic);
}

/**
 * Zeroes the shadow stack below the caller (where the frames of the call that just returned were).
 * Hidden from the loaded API; the loaders call it.
 */
export function __scrubStack() {
    wasm.__scrubStack();
}

/**
 * Test hook: panics synchronously, so the loader's panic handling can be tested. Hidden from the
 * loaded API.
 * @param {string} message
 */
export function __testPanic(message) {
    const ptr0 = passStringToWasm0(message, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    wasm.__testPanic(ptr0, len0);
}

/**
 * Test hook: panics inside a future, so the loader's async panic handling can be tested. Hidden
 * from the loaded API.
 * @param {string} message
 * @returns {Promise<any>}
 */
export function __testPanicAsync(message) {
    const ptr0 = passStringToWasm0(message, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.__testPanicAsync(ptr0, len0);
    return ret;
}

/**
 * XChaCha20-Poly1305 decryption; `decryption_failed` on a wrong key or tampered input.
 * @param {Uint8Array | number[]} key
 * @param {Uint8Array | number[]} nonce
 * @param {Uint8Array | number[]} ciphertext
 * @param {Uint8Array | number[]} aad
 * @returns {Uint8Array}
 */
export function aeadDecrypt(key, nonce, ciphertext, aad) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(ciphertext, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = passArray8ToWasm0(aad, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.aeadDecrypt(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * XChaCha20-Poly1305 encryption: 32-byte key, 24-byte nonce; returns ciphertext ‖ tag.
 * @param {Uint8Array | number[]} key
 * @param {Uint8Array | number[]} nonce
 * @param {Uint8Array | number[]} plaintext
 * @param {Uint8Array | number[]} aad
 * @returns {Uint8Array}
 */
export function aeadEncrypt(key, nonce, plaintext, aad) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(plaintext, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = passArray8ToWasm0(aad, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.aeadEncrypt(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Argon2d, Argon2i or Argon2id (version 0x13) with any output length (KDBX files, the SDK's
 * `argon2()`). `weak_kdf` for parameters Argon2 refuses. No minimum-cost check: see `checkKdfParams`.
 * @param {Argon2Params} params
 * @returns {Uint8Array}
 */
export function argon2(params) {
    const ret = wasm.argon2(params);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Argon2id (v0x13), 32-byte output. `m` in KiB.
 * @param {Uint8Array | number[]} password
 * @param {Uint8Array | number[]} salt
 * @param {number} m
 * @param {number} t
 * @param {number} p
 * @returns {Uint8Array}
 */
export function argon2id(password, salt, m, t, p) {
    const val3 = +m;
    const val4 = +t;
    const val5 = +p;
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(password, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(salt, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.argon2id(ptr0, len0, ptr1, len1, val3, val4, val5);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * RFC 4648 base32 (as TOTP secrets are written): case-insensitive, white space, `=` and `-`
 * ignored; `invalid_totp` otherwise. The SDK's `base32Decode`. The result may be a secret: wipe it.
 * @param {string | Uint8Array} text
 * @returns {Uint8Array}
 */
export function base32Decode(text) {
    const ret = wasm.base32Decode(text);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * `ov_sa_<base64url JSON>` (UTF-8).
 * @param {SaTokenParts} p
 * @returns {Uint8Array}
 */
export function buildSaToken(p) {
    const ret = wasm.buildSaToken(p);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Refuses parameters below `min` (default the SPEC floor m = 19456, t = 2) or not Argon2id: `weak_kdf`.
 * @param {KdfParams} kdf
 * @param {KdfMin} [min]
 */
export function checkKdfParams(kdf, min) {
    const ret = wasm.checkKdfParams(kdf, isLikeNone(min) ? 0 : addToExternrefTable0(min));
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

/**
 * Decodes a JWT without verifying it: `{ header, claims }`. `invalid_token` when malformed.
 * @param {string | Uint8Array} token
 * @returns {{ header: Record<string, unknown>; claims: AccessClaims }}
 */
export function decodeJwt(token) {
    const ret = wasm.decodeJwt(token);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decrypts a share's `ct` bytes; `decryption_failed` for a wrong key, passcode or id.
 * @param {Uint8Array | number[]} key
 * @param {string} id
 * @param {Uint8Array | number[]} ct
 * @param {Uint8Array | number[] | null} [passcode_key]
 * @returns {SharePayload}
 */
export function decryptSharePayload(key, id, ct, passcode_key) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(ct, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = isLikeNone(passcode_key) ? 0 : passArray8ToWasm0(passcode_key, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.decryptSharePayload(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decrypts an owner's reference.
 * @param {Uint8Array | number[]} enc_sk
 * @param {string} id
 * @param {string} reference
 * @returns {ShareRef}
 */
export function decryptShareRef(enc_sk, id, reference) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(enc_sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(reference, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.decryptShareRef(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decrypts a vault name.
 * @param {Uint8Array | number[]} vault_key
 * @param {string} vault_id
 * @param {string} encrypted_name
 * @returns {string}
 */
export function decryptVaultName(vault_key, vault_id, encrypted_name) {
    let deferred5_0;
    let deferred5_1;
    try {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passArray8ToWasm0(vault_key, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passStringToWasm0(encrypted_name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.decryptVaultName(ptr0, len0, ptr1, len1, ptr2, len2);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * The fields an item share includes by default.
 * @returns {string[]}
 */
export function defaultShareFields() {
    const ret = wasm.defaultShareFields();
    var v1 = getArrayJsValueFromWasm0(ret[0], ret[1]);
    wasm.__wbindgen_free(ret[0], ret[1] * 4, 4);
    return v1;
}

/**
 * Whether a remembered account's erase date is more than a day past.
 * @param {string | null | undefined} scheduled_for
 * @param {number} now_ms
 * @returns {boolean}
 */
export function deletionExpired(scheduled_for, now_ms) {
    const val2 = +now_ms;
    var ptr0 = isLikeNone(scheduled_for) ? 0 : passStringToWasm0(scheduled_for, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    var len0 = WASM_VECTOR_LEN;
    const ret = wasm.deletionExpired(ptr0, len0, val2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] !== 0;
}

/**
 * The Account Unlock Key: HKDF(stretched password, salt = Secret Key, "ov-auk-v1") (SPEC §3).
 * @param {string | Uint8Array} password
 * @param {KdfParams} kdf
 * @param {Uint8Array | number[]} secret_key
 * @param {DeriveAukOptions} [opts]
 * @returns {Uint8Array}
 */
export function deriveAuk(password, kdf, secret_key, opts) {
    const ptr0 = passArray8ToWasm0(secret_key, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.deriveAuk(password, kdf, ptr0, len0, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The Ed25519 public key of a 32-byte seed.
 * @param {Uint8Array | number[]} seed
 * @returns {Uint8Array}
 */
export function ed25519PublicKey(seed) {
    const ptr0 = passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.ed25519PublicKey(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * An Ed25519 signature (64 bytes) of `message` with a 32-byte seed.
 * @param {Uint8Array | number[]} message
 * @param {Uint8Array | number[]} seed
 * @returns {Uint8Array}
 */
export function ed25519Sign(message, seed) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(message, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.ed25519Sign(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Whether `sig` is a valid (strict) Ed25519 signature of `message` by `pk`. Never throws.
 * @param {Uint8Array | number[]} sig
 * @param {Uint8Array | number[]} message
 * @param {Uint8Array | number[]} pk
 * @returns {boolean}
 */
export function ed25519Verify(sig, message, pk) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(sig, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(message, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(pk, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.ed25519Verify(ptr0, len0, ptr1, len1, ptr2, len2);
    return ret !== 0;
}

/**
 * Encrypts a payload under the link key (and passcode key): the share's `ct` bytes. `nonce` is
 * for test vectors only. `too_large` past 64 KiB.
 * @param {Uint8Array | number[]} key
 * @param {string} id
 * @param {SharePayload} payload
 * @param {Uint8Array | number[] | null} [passcode_key]
 * @param {Uint8Array | number[] | null} [nonce]
 * @returns {Uint8Array}
 */
export function encryptSharePayload(key, id, payload, passcode_key, nonce) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = isLikeNone(passcode_key) ? 0 : passArray8ToWasm0(passcode_key, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = isLikeNone(nonce) ? 0 : passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.encryptSharePayload(ptr0, len0, ptr1, len1, payload, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Encrypts the owner's reference (`{vault, entry, title}`) to base64url. `nonce` for test vectors only.
 * @param {Uint8Array | number[]} enc_sk
 * @param {string} id
 * @param {ShareRef} reference
 * @param {Uint8Array | number[] | null} [nonce]
 * @returns {string}
 */
export function encryptShareRef(enc_sk, id, reference, nonce) {
    let deferred5_0;
    let deferred5_1;
    try {
        let ptr0, len0, ptr1, len1, ptr2, len2;
        try {
            ptr0 = passArray8ToWasm0(enc_sk, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = isLikeNone(nonce) ? 0 : passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
            len2 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.encryptShareRef(ptr0, len0, ptr1, len1, reference, ptr2, len2);
        var ptr4 = ret[0];
        var len4 = ret[1];
        if (ret[3]) {
            ptr4 = 0; len4 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred5_0 = ptr4;
        deferred5_1 = len4;
        return getStringFromWasm0(ptr4, len4);
    } finally {
        wasm.__wbindgen_free(deferred5_0, deferred5_1, 1);
    }
}

/**
 * Encrypts a vault name (base64url, SPEC §7).
 * @param {Uint8Array | number[]} vault_key
 * @param {string} vault_id
 * @param {string} name
 * @param {Uint8Array | number[] | null} [nonce]
 * @returns {string}
 */
export function encryptVaultName(vault_key, vault_id, name, nonce) {
    let deferred6_0;
    let deferred6_1;
    try {
        let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
        try {
            ptr0 = passArray8ToWasm0(vault_key, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passStringToWasm0(name, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len2 = WASM_VECTOR_LEN;
            ptr3 = isLikeNone(nonce) ? 0 : passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
            len3 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.encryptVaultName(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
        var ptr5 = ret[0];
        var len5 = ret[1];
        if (ret[3]) {
            ptr5 = 0; len5 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred6_0 = ptr5;
        deferred6_1 = len5;
        return getStringFromWasm0(ptr5, len5);
    } finally {
        wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
    }
}

/**
 * An entry's TOTP URI from its fields (`otp`, or KeePass's `TOTP Seed`/`TOTP Settings`).
 * @param {{ fields: FieldRecord[] } | FieldRecord[]} fields
 * @param {string} label
 * @returns {Uint8Array | undefined}
 */
export function entryTotpUri(fields, label) {
    const ptr0 = passStringToWasm0(label, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.entryTotpUri(fields, ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The fingerprint `xxxx xxxx …` (first 20 bytes of SHA-256(encPk ‖ signPk), hex in groups).
 * @param {Uint8Array | number[]} enc_pk
 * @param {Uint8Array | number[]} sign_pk
 * @returns {string}
 */
export function fingerprint(enc_pk, sign_pk) {
    let deferred3_0;
    let deferred3_1;
    try {
        let ptr0, len0, ptr1, len1;
        try {
            ptr0 = passArray8ToWasm0(enc_pk, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passArray8ToWasm0(sign_pk, wasm.__wbindgen_malloc);
            len1 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.fingerprint(ptr0, len0, ptr1, len1);
        deferred3_0 = ret[0];
        deferred3_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * The display form `K1-XXXXXX-…` (UTF-8).
 * @param {Uint8Array | number[]} raw
 * @returns {Uint8Array}
 */
export function formatSecretKey(raw) {
    const ptr0 = passArray8ToWasm0(raw, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.formatSecretKey(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * A fresh random keyset.
 * @returns {Keyset}
 */
export function generateKeyset() {
    const ret = wasm.generateKeyset();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * A fresh 16-byte Secret Key (SPEC §2).
 * @returns {Uint8Array}
 */
export function generateSecretKey() {
    const ret = wasm.generateSecretKey();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * HKDF-SHA256 (RFC 5869) with `length` output bytes (at most 8160).
 * @param {Uint8Array | number[]} ikm
 * @param {Uint8Array | number[]} salt
 * @param {Uint8Array | number[]} info
 * @param {number} length
 * @returns {Uint8Array}
 */
export function hkdfSha256(ikm, salt, info, length) {
    const val4 = +length;
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(ikm, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(salt, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(info, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.hkdfSha256(ptr0, len0, ptr1, len1, ptr2, len2, val4);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Whether a token looks like a JWT (three dot-separated parts).
 * @param {string | Uint8Array} token
 * @returns {boolean}
 */
export function isJwt(token) {
    const ret = wasm.isJwt(token);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] !== 0;
}

/**
 * The payload of an item share with the named fields.
 * @param {{ fields: FieldRecord[] } | FieldRecord[]} entry
 * @param {string[]} names
 * @param {string | null} [shared_by]
 * @returns {SharePayload}
 */
export function itemSharePayload(entry, names, shared_by) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArrayJsValueToWasm0(names, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = isLikeNone(shared_by) ? 0 : passStringToWasm0(shared_by, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__externref_drop_slice(ptr0, len0); wasm.__wbindgen_free(ptr0, len0 * 4, 4); }
        throw e;
    }
    const ret = wasm.itemSharePayload(entry, ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The sync merge on file bytes: reads `local`, `remote` and `base` (when given) with `key`, merges,
 * and writes both copies back with the same key. `{ local, remote, report }`; upload `remote` when
 * `report.remoteChanged`.
 * @param {Uint8Array | number[]} local
 * @param {Uint8Array | number[]} remote
 * @param {Uint8Array | number[] | null | undefined} base
 * @param {KdbxKey} key
 * @param {number | null} [now_secs]
 * @returns {{ local: Uint8Array; remote: Uint8Array; report: KdbxMergeReport }}
 */
export function kdbxMerge(local, remote, base, key, now_secs) {
    const val4 = +(isLikeNone(now_secs) ? 0 : now_secs);
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(local, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(remote, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = isLikeNone(base) ? 0 : passArray8ToWasm0(base, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.kdbxMerge(ptr0, len0, ptr1, len1, ptr2, len2, key, !isLikeNone(now_secs), val4);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * SHA-256 of a password as KDBX uses it (the SDK's `passwordHash`).
 * @param {string | Uint8Array} password
 * @returns {Uint8Array}
 */
export function kdbxPasswordHash(password) {
    const ret = wasm.kdbxPasswordHash(password);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The keyset of two 32-byte secrets (computes and signs the public keys).
 * @param {Uint8Array | number[]} enc_sk
 * @param {Uint8Array | number[]} sign_seed
 * @returns {Keyset}
 */
export function keysetFromSecrets(enc_sk, sign_seed) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(enc_sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(sign_seed, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.keysetFromSecrets(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * KDF parameters for a new account: the defaults (m = 64 MiB, t = 3, p = 1) with any overrides,
 * and a random salt.
 * @param {KdfOverrides} [overrides]
 * @returns {KdfParams}
 */
export function newKdfParams(overrides) {
    const ret = wasm.newKdfParams(isLikeNone(overrides) ? 0 : addToExternrefTable0(overrides));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * A fresh `ov_rt_…` refresh token (UTF-8).
 * @returns {Uint8Array}
 */
export function newRefreshToken() {
    const ret = wasm.newRefreshToken();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * A new SA secret: the token and the request body.
 * @param {NewSaSecretInput} p
 * @returns {NewSaSecret}
 */
export function newSaSecret(p) {
    const ret = wasm.newSaSecret(p);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * A fresh 32-byte link key.
 * @returns {Uint8Array}
 */
export function newShareKey() {
    const ret = wasm.newShareKey();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Client login step 2: `authU` for `/auth/login/finish`. `opaque_failed` ("wrong password") for a
 * wrong password or the fake record of an unknown email. Consumes `state`.
 * @param {Uint8Array | number[]} state
 * @param {Uint8Array | number[]} ke2
 * @param {OpaqueIds} ids
 * @param {string | null} [context]
 * @param {Uint8Array | number[] | null} [seed]
 * @returns {OpaqueLoginFinish}
 */
export function opaqueFinishLogin(state, ke2, ids, context, seed) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(state, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(ke2, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = isLikeNone(context) ? 0 : passStringToWasm0(context, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = isLikeNone(seed) ? 0 : passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.opaqueFinishLogin(ptr0, len0, ptr1, len1, ids, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Client registration step 2: the `record` for `/auth/register/finish`. Consumes `state`.
 * @param {Uint8Array | number[]} state
 * @param {Uint8Array | number[]} response
 * @param {OpaqueIds} ids
 * @param {Uint8Array | number[] | null} [seed]
 * @returns {OpaqueRegistrationFinish}
 */
export function opaqueFinishRegistration(state, response, ids, seed) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(state, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(response, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = isLikeNone(seed) ? 0 : passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.opaqueFinishRegistration(ptr0, len0, ptr1, len1, ids, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * `{ idU, idS }` from an email and the issuer URL or host.
 * @param {string} email
 * @param {string} issuer_or_host
 * @returns {OpaqueIds}
 */
export function opaqueIds(email, issuer_or_host) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passStringToWasm0(email, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(issuer_or_host, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.opaqueIds(ptr0, len0, ptr1, len1);
    return ret;
}

/**
 * Test server: `ke2` and the login state `sec`.
 * @param {Uint8Array | number[]} ke1
 * @param {Uint8Array | number[]} stored_record
 * @param {OpaqueIds} ids
 * @param {string | null} [context]
 * @param {Uint8Array | number[] | null} [seed]
 * @returns {{ ke2: Uint8Array; sec: Uint8Array }}
 */
export function opaqueServerCredentialResponse(ke1, stored_record, ids, context, seed) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(ke1, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(stored_record, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = isLikeNone(context) ? 0 : passStringToWasm0(context, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = isLikeNone(seed) ? 0 : passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.opaqueServerCredentialResponse(ptr0, len0, ptr1, len1, ids, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Test server: the registration response, and `sec` (a new per-user `ServerSetup`).
 * @param {Uint8Array | number[]} request
 * @param {Uint8Array | number[] | null} [seed]
 * @returns {{ sec: Uint8Array; response: Uint8Array }}
 */
export function opaqueServerRegistrationResponse(request, seed) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(request, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = isLikeNone(seed) ? 0 : passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.opaqueServerRegistrationResponse(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Test server: the stored record (`sec` ‖ the client's registration upload).
 * @param {Uint8Array | number[]} sec
 * @param {Uint8Array | number[]} record
 * @returns {Uint8Array}
 */
export function opaqueServerStoreRecord(sec, record) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(sec, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(record, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.opaqueServerStoreRecord(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Test server: checks `authU`; the server's session key, or `undefined` when it is wrong.
 * @param {Uint8Array | number[]} sec
 * @param {Uint8Array | number[]} auth_u
 * @returns {Uint8Array | undefined}
 */
export function opaqueServerUserAuth(sec, auth_u) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(sec, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(auth_u, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.opaqueServerUserAuth(ptr0, len0, ptr1, len1);
    return ret;
}

/**
 * Client login step 1: `ke1` for `/auth/login/start`.
 * @param {string | Uint8Array} password
 * @param {Uint8Array | number[] | null} [seed]
 * @returns {OpaqueLoginStart}
 */
export function opaqueStartLogin(password, seed) {
    var ptr0 = isLikeNone(seed) ? 0 : passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
    var len0 = WASM_VECTOR_LEN;
    const ret = wasm.opaqueStartLogin(password, ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Client registration step 1: `request` for `/auth/register/start`.
 * @param {string | Uint8Array} password
 * @param {Uint8Array | number[] | null} [seed]
 * @returns {OpaqueRegistrationStart}
 */
export function opaqueStartRegistration(password, seed) {
    var ptr0 = isLikeNone(seed) ? 0 : passArray8ToWasm0(seed, wasm.__wbindgen_malloc);
    var len0 = WASM_VECTOR_LEN;
    const ret = wasm.opaqueStartRegistration(password, ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Opens a share in one step from its link, `kdf`, passcode and the fetched `ct` (base64url).
 * @param {string | Uint8Array} link
 * @param {KdfParams | undefined} kdf
 * @param {string | Uint8Array | undefined} passcode
 * @param {string} ct
 * @returns {SharePayload}
 */
export function openShareContent(link, kdf, passcode, ct) {
    const ptr0 = passStringToWasm0(ct, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.openShareContent(link, isLikeNone(kdf) ? 0 : addToExternrefTable0(kdf), isLikeNone(passcode) ? 0 : addToExternrefTable0(passcode), ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Pads share content to a multiple of 512 bytes (`0x80` then zeroes).
 * @param {Uint8Array | number[]} data
 * @returns {Uint8Array}
 */
export function padShare(data) {
    const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.padShare(ptr0, len0);
    return ret;
}

/**
 * Parses a service account token; `invalid_token`.
 * @param {string | Uint8Array} token
 * @returns {SaTokenParts}
 */
export function parseSaToken(token) {
    const ret = wasm.parseSaToken(token);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Parses a displayed Secret Key; `invalid_secret_key` when it is malformed.
 * @param {string | Uint8Array} display
 * @returns {Uint8Array}
 */
export function parseSecretKey(display) {
    const ret = wasm.parseSecretKey(display);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Splits a share link; `invalid_link` when it isn't a complete one.
 * @param {string | Uint8Array} link
 * @returns {ShareLinkParts}
 */
export function parseShareLink(link) {
    const ret = wasm.parseShareLink(link);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Parses an `otpauth://totp/` URI (KeePassXC's `otp` field).
 * @param {string | Uint8Array} uri
 * @returns {TotpParams}
 */
export function parseTotpUri(uri) {
    const ret = wasm.parseTotpUri(uri);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * UTF-8 of the NFKC-normalised password (SPEC §3; also the OPAQUE input).
 * @param {string | Uint8Array} password
 * @returns {Uint8Array}
 */
export function passwordBytes(password) {
    const ret = wasm.passwordBytes(password);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decodes server JSON (no signature check; see `trustedPublicKeys`). `invalid_public_keys`.
 * @param {PublicKeysJson} j
 * @returns {PublicKeys}
 */
export function publicKeysFromJson(j) {
    const ret = wasm.publicKeysFromJson(j);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Public keys as server JSON.
 * @param {PublicKeys} _public
 * @returns {PublicKeysJson}
 */
export function publicKeysToJson(_public) {
    const ret = wasm.publicKeysToJson(_public);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * `n` bytes from the platform CSPRNG (`crypto.getRandomValues`).
 * @param {number} n
 * @returns {Uint8Array}
 */
export function randomBytes(n) {
    const ret = wasm.randomBytes(n);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Hex SHA-256 of a refresh token.
 * @param {string | Uint8Array} token
 * @returns {string}
 */
export function refreshTokenHash(token) {
    let deferred2_0;
    let deferred2_1;
    try {
        const ret = wasm.refreshTokenHash(token);
        var ptr1 = ret[0];
        var len1 = ret[1];
        if (ret[3]) {
            ptr1 = 0; len1 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred2_0 = ptr1;
        deferred2_1 = len1;
        return getStringFromWasm0(ptr1, len1);
    } finally {
        wasm.__wbindgen_free(deferred2_0, deferred2_1, 1);
    }
}

/**
 * Re-seals an archived vault key to the current keyset.
 * @param {Uint8Array | number[]} old_enc_sk
 * @param {Uint8Array | number[]} current_enc_pk
 * @param {string} vault_id
 * @param {Uint8Array | number[]} sealed
 * @param {SealOptions} [opts]
 * @returns {Uint8Array}
 */
export function resealVaultKey(old_enc_sk, current_enc_pk, vault_id, sealed, opts) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(old_enc_sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(current_enc_pk, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = passArray8ToWasm0(sealed, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.resealVaultKey(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The restore proof: the archived keyset's Ed25519 signature over the message.
 * @param {Uint8Array | number[]} old_sign_seed
 * @param {string} user_id
 * @param {CurrentKeys} current_keys
 * @returns {Uint8Array}
 */
export function restoreProof(old_sign_seed, user_id, current_keys) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(old_sign_seed, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.restoreProof(ptr0, len0, ptr1, len1, current_keys);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * `"ov-restore-v1" ‖ userId ‖ encPk ‖ signPk` (SPEC §18).
 * @param {string} user_id
 * @param {CurrentKeys} current_keys
 * @returns {Uint8Array}
 */
export function restoreProofMessage(user_id, current_keys) {
    const ptr0 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.restoreProofMessage(ptr0, len0, current_keys);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Hex SHA-256 of an SA secret (what the server stores).
 * @param {Uint8Array | number[]} secret
 * @returns {string}
 */
export function saSecretHash(secret) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(secret, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.saSecretHash(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * The first 8 base64url characters of an SA secret (shown in lists).
 * @param {Uint8Array | number[]} secret
 * @returns {string}
 */
export function saSecretPrefix(secret) {
    let deferred3_0;
    let deferred3_1;
    try {
        const ptr0 = passArray8ToWasm0(secret, wasm.__wbindgen_malloc);
        const len0 = WASM_VECTOR_LEN;
        const ret = wasm.saSecretPrefix(ptr0, len0);
        var ptr2 = ret[0];
        var len2 = ret[1];
        if (ret[3]) {
            ptr2 = 0; len2 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred3_0 = ptr2;
        deferred3_1 = len2;
        return getStringFromWasm0(ptr2, len2);
    } finally {
        wasm.__wbindgen_free(deferred3_0, deferred3_1, 1);
    }
}

/**
 * Seals to an X25519 public key (SPEC §6); `low_order_point` for a bad key.
 * @param {Uint8Array | number[]} recipient_enc_pk
 * @param {Uint8Array | number[]} plaintext
 * @param {string} aad
 * @param {SealOptions} [opts]
 * @returns {Uint8Array}
 */
export function seal(recipient_enc_pk, plaintext, aad, opts) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(recipient_enc_pk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(plaintext, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(aad, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.seal(ptr0, len0, ptr1, len1, ptr2, len2, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The derived key of a sealed blob (for vectors and debugging).
 * @param {Uint8Array | number[]} recipient_enc_sk
 * @param {Uint8Array | number[]} sealed
 * @returns {Uint8Array}
 */
export function sealDerivedKey(recipient_enc_sk, sealed) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(recipient_enc_sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(sealed, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.sealDerivedKey(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Seals a service account's master key (AAD `ov-sa-master-v1|<saId>`).
 * @param {Uint8Array | number[]} recipient_enc_pk
 * @param {string} sa_id
 * @param {Uint8Array | number[]} master
 * @param {SealOptions} [opts]
 * @returns {Uint8Array}
 */
export function sealSaMaster(recipient_enc_pk, sa_id, master, opts) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(recipient_enc_pk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(master, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.sealSaMaster(ptr0, len0, ptr1, len1, ptr2, len2, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Seals a vault key (AAD `ov-vault-key|<vaultId>`).
 * @param {Uint8Array | number[]} recipient_enc_pk
 * @param {string} vault_id
 * @param {Uint8Array | number[]} vault_key
 * @param {SealOptions} [opts]
 * @returns {Uint8Array}
 */
export function sealVaultKey(recipient_enc_pk, vault_id, vault_key, opts) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(recipient_enc_pk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(vault_key, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.sealVaultKey(ptr0, len0, ptr1, len1, ptr2, len2, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * SHA-256.
 * @param {Uint8Array | number[]} data
 * @returns {Uint8Array}
 */
export function sha256(data) {
    const ptr0 = passArray8ToWasm0(data, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.sha256(ptr0, len0);
    return ret;
}

/**
 * The `auth` value a passcode share's open request sends: HKDF(passcodeKey, "ov-share-auth-v1").
 * @param {Uint8Array | number[]} passcode_key
 * @returns {Uint8Array}
 */
export function shareAuth(passcode_key) {
    const ptr0 = passArray8ToWasm0(passcode_key, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.shareAuth(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * SHA-256 of `auth` (what the server stores).
 * @param {Uint8Array | number[]} auth
 * @returns {Uint8Array}
 */
export function shareAuthHash(auth) {
    const ptr0 = passArray8ToWasm0(auth, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.shareAuthHash(ptr0, len0);
    return ret;
}

/**
 * HKDF(key, salt = passcodeKey or empty, "ov-share-v1"): the content key.
 * @param {Uint8Array | number[]} key
 * @param {Uint8Array | number[] | null} [passcode_key]
 * @returns {Uint8Array}
 */
export function shareContentKey(key, passcode_key) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = isLikeNone(passcode_key) ? 0 : passArray8ToWasm0(passcode_key, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.shareContentKey(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The link key from a URL fragment (`#…` or without the `#`).
 * @param {string | Uint8Array} hash
 * @returns {Uint8Array}
 */
export function shareKeyFromHash(hash) {
    const ret = wasm.shareKeyFromHash(hash);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * `<base>/<id>#<base64url key>` (UTF-8).
 * @param {string} base
 * @param {string} id
 * @param {Uint8Array | number[]} key
 * @returns {Uint8Array}
 */
export function shareLink(base, id, key) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passStringToWasm0(base, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.shareLink(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Argon2id of the NFKC passcode with the share's `kdf` (SPEC §22). `weak_kdf` below the SPEC §3
 * minimum unless `allowWeak` (test vectors only).
 * @param {string | Uint8Array} passcode
 * @param {KdfParams} kdf
 * @param {boolean | null} [allow_weak]
 * @returns {Uint8Array}
 */
export function sharePasscodeKey(passcode, kdf, allow_weak) {
    const ret = wasm.sharePasscodeKey(passcode, kdf, isLikeNone(allow_weak) ? 0xFFFFFF : allow_weak ? 1 : 0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * HKDF(encSk, "ov-share-ref-v1"): the owner's key for share references.
 * @param {Uint8Array | number[]} enc_sk
 * @returns {Uint8Array}
 */
export function shareRefKey(enc_sk) {
    const ptr0 = passArray8ToWasm0(enc_sk, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.shareRefKey(ptr0, len0);
    return ret;
}

/**
 * The fields of an entry that can be shared (standard ones first, then the TOTP code source, then
 * custom fields). `entry` is `{ fields: FieldRecord[] }` (an `EntryRecord`) or a `FieldRecord[]`.
 * @param {{ fields: FieldRecord[] } | FieldRecord[]} entry
 * @returns {ShareableField[]}
 */
export function shareableFields(entry) {
    const ret = wasm.shareableFields(entry);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Argon2id of the NFKC password with `kdf` (checked against `opts.min` unless `opts.allowWeak`).
 * @param {string | Uint8Array} password
 * @param {KdfParams} kdf
 * @param {DeriveAukOptions} [opts]
 * @returns {Uint8Array}
 */
export function stretchPassword(password, kdf, opts) {
    const ret = wasm.stretchPassword(password, kdf, isLikeNone(opts) ? 0 : addToExternrefTable0(opts));
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The payload of a text share.
 * @param {string | Uint8Array} text
 * @param {string | null} [title]
 * @param {string | null} [shared_by]
 * @returns {SharePayload}
 */
export function textSharePayload(text, title, shared_by) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = isLikeNone(title) ? 0 : passStringToWasm0(title, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = isLikeNone(shared_by) ? 0 : passStringToWasm0(shared_by, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.textSharePayload(text, ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * The TOTP code at `nowMs` (Unix milliseconds).
 * @param {TotpParams} params
 * @param {number} now_ms
 * @returns {TotpCode}
 */
export function totpCode(params, now_ms) {
    const ret = wasm.totpCode(params, now_ms);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Decodes server JSON and checks the signature: `invalid_public_keys` when it doesn't verify.
 * @param {PublicKeysJson} j
 * @returns {PublicKeys}
 */
export function trustedPublicKeys(j) {
    const ret = wasm.trustedPublicKeys(j);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Removes the padding; `decryption_failed` when it is malformed.
 * @param {Uint8Array | number[]} padded
 * @returns {Uint8Array}
 */
export function unpadShare(padded) {
    const ptr0 = passArray8ToWasm0(padded, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.unpadShare(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Opens a sealed blob.
 * @param {Uint8Array | number[]} recipient_enc_sk
 * @param {Uint8Array | number[]} sealed
 * @param {string} aad
 * @returns {Uint8Array}
 */
export function unseal(recipient_enc_sk, sealed, aad) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(recipient_enc_sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(sealed, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(aad, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.unseal(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Opens a sealed SA master key.
 * @param {Uint8Array | number[]} enc_sk
 * @param {string} sa_id
 * @param {Uint8Array | number[]} sealed
 * @returns {Uint8Array}
 */
export function unsealSaMaster(enc_sk, sa_id, sealed) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(enc_sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(sealed, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.unsealSaMaster(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Opens a sealed vault key (32 bytes).
 * @param {Uint8Array | number[]} enc_sk
 * @param {string} vault_id
 * @param {Uint8Array | number[]} sealed
 * @returns {Uint8Array}
 */
export function unsealVaultKey(enc_sk, vault_id, sealed) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(enc_sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(vault_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(sealed, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.unsealVaultKey(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Opens a [`wrap`] blob; `unsupported_version`/`decryption_failed`.
 * @param {Uint8Array | number[]} key
 * @param {Uint8Array | number[]} blob
 * @param {string} aad
 * @returns {Uint8Array}
 */
export function unwrap(key, blob, aad) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(blob, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(aad, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.unwrap(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Unwraps a server keyset and checks it against its public keys.
 * @param {Uint8Array | number[]} key
 * @param {WrappedKeysetJson} w
 * @returns {Keyset}
 */
export function unwrapKeyset(key, w) {
    const ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.unwrapKeyset(ptr0, len0, w);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Unwraps an SA master key.
 * @param {Uint8Array | number[]} kek
 * @param {string} sa_id
 * @param {string} wrapped
 * @returns {Uint8Array}
 */
export function unwrapSaMaster(kek, sa_id, wrapped) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(kek, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(wrapped, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.unwrapSaMaster(ptr0, len0, ptr1, len1, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * HKDF(vaultKey, "ov-vault-name-v1").
 * @param {Uint8Array | number[]} vault_key
 * @returns {Uint8Array}
 */
export function vaultNameKey(vault_key) {
    const ptr0 = passArray8ToWasm0(vault_key, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.vaultNameKey(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Verifies an EdDSA access token against a JWKS (signature, `iss`, `aud`, `exp`/`nbf` with skew):
 * the claims, or `unauthorized` (status 401).
 * @param {string | Uint8Array} token
 * @param {Jwks} jwks
 * @param {VerifyJwtOptions} opts
 * @returns {AccessClaims}
 */
export function verifyJwt(token, jwks, opts) {
    const ret = wasm.verifyJwt(token, jwks, opts);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Whether the public keys' signature verifies (`sig` by `signPk` over both keys).
 * @param {PublicKeys} _public
 * @returns {boolean}
 */
export function verifyPublicKeys(_public) {
    const ret = wasm.verifyPublicKeys(_public);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] !== 0;
}

/**
 * Whether a restore proof verifies against the archived signing key.
 * @param {Uint8Array | number[]} proof
 * @param {string} user_id
 * @param {CurrentKeys} current_keys
 * @param {Uint8Array | number[]} old_sign_pk
 * @returns {boolean}
 */
export function verifyRestoreProof(proof, user_id, current_keys, old_sign_pk) {
    let ptr0, len0, ptr1, len1, ptr2, len2;
    try {
        ptr0 = passArray8ToWasm0(proof, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passStringToWasm0(user_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passArray8ToWasm0(old_sign_pk, wasm.__wbindgen_malloc);
        len2 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.verifyRestoreProof(ptr0, len0, ptr1, len1, current_keys, ptr2, len2);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return ret[0] !== 0;
}

/**
 * The core's version (`ov-core` crate version).
 * @returns {string}
 */
export function version() {
    let deferred1_0;
    let deferred1_1;
    try {
        const ret = wasm.version();
        deferred1_0 = ret[0];
        deferred1_1 = ret[1];
        return getStringFromWasm0(ret[0], ret[1]);
    } finally {
        wasm.__wbindgen_free(deferred1_0, deferred1_1, 1);
    }
}

/**
 * `0x01 ‖ nonce ‖ XChaCha20-Poly1305(key, plaintext, aad)` (SPEC §4).
 * @param {Uint8Array | number[]} key
 * @param {Uint8Array | number[]} plaintext
 * @param {string} aad
 * @param {Uint8Array | number[] | null} [nonce]
 * @returns {Uint8Array}
 */
export function wrap(key, plaintext, aad, nonce) {
    let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(plaintext, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
        ptr2 = passStringToWasm0(aad, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        len2 = WASM_VECTOR_LEN;
        ptr3 = isLikeNone(nonce) ? 0 : passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
        len3 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
        if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.wrap(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Wraps a keyset under `key` (the AUK or an SA master) for the server.
 * @param {Uint8Array | number[]} key
 * @param {Keyset} ks
 * @param {Uint8Array | number[] | null} [nonce]
 * @returns {WrappedKeysetJson}
 */
export function wrapKeyset(key, ks, nonce) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(key, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = isLikeNone(nonce) ? 0 : passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.wrapKeyset(ptr0, len0, ks, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * Wraps an SA master key under a token's KEK (base64url).
 * @param {Uint8Array | number[]} kek
 * @param {string} sa_id
 * @param {Uint8Array | number[]} master
 * @param {Uint8Array | number[] | null} [nonce]
 * @returns {string}
 */
export function wrapSaMaster(kek, sa_id, master, nonce) {
    let deferred6_0;
    let deferred6_1;
    try {
        let ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3;
        try {
            ptr0 = passArray8ToWasm0(kek, wasm.__wbindgen_malloc);
            len0 = WASM_VECTOR_LEN;
            ptr1 = passStringToWasm0(sa_id, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            len1 = WASM_VECTOR_LEN;
            ptr2 = passArray8ToWasm0(master, wasm.__wbindgen_malloc);
            len2 = WASM_VECTOR_LEN;
            ptr3 = isLikeNone(nonce) ? 0 : passArray8ToWasm0(nonce, wasm.__wbindgen_malloc);
            len3 = WASM_VECTOR_LEN;
        } catch (e) {
            if (ptr3) { wasm.__wbindgen_free(ptr3, len3 * 1, 1); }
            if (ptr2) { wasm.__wbindgen_free(ptr2, len2 * 1, 1); }
            if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
            if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
            throw e;
        }
        const ret = wasm.wrapSaMaster(ptr0, len0, ptr1, len1, ptr2, len2, ptr3, len3);
        var ptr5 = ret[0];
        var len5 = ret[1];
        if (ret[3]) {
            ptr5 = 0; len5 = 0;
            throw takeFromExternrefTable0(ret[2]);
        }
        deferred6_0 = ptr5;
        deferred6_1 = len5;
        return getStringFromWasm0(ptr5, len5);
    } finally {
        wasm.__wbindgen_free(deferred6_0, deferred6_1, 1);
    }
}

/**
 * The X25519 public key of a 32-byte secret key.
 * @param {Uint8Array | number[]} sk
 * @returns {Uint8Array}
 */
export function x25519PublicKey(sk) {
    const ptr0 = passArray8ToWasm0(sk, wasm.__wbindgen_malloc);
    const len0 = WASM_VECTOR_LEN;
    const ret = wasm.x25519PublicKey(ptr0, len0);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * A random X25519 secret key (clamped).
 * @returns {Uint8Array}
 */
export function x25519RandomSecret() {
    const ret = wasm.x25519RandomSecret();
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}

/**
 * X25519(sk, pk); `low_order_point` when the result is all zeroes.
 * @param {Uint8Array | number[]} sk
 * @param {Uint8Array | number[]} pk
 * @returns {Uint8Array}
 */
export function x25519Shared(sk, pk) {
    let ptr0, len0, ptr1, len1;
    try {
        ptr0 = passArray8ToWasm0(sk, wasm.__wbindgen_malloc);
        len0 = WASM_VECTOR_LEN;
        ptr1 = passArray8ToWasm0(pk, wasm.__wbindgen_malloc);
        len1 = WASM_VECTOR_LEN;
    } catch (e) {
        if (ptr1) { wasm.__wbindgen_free(ptr1, len1 * 1, 1); }
        if (ptr0) { wasm.__wbindgen_free(ptr0, len0 * 1, 1); }
        throw e;
    }
    const ret = wasm.x25519Shared(ptr0, len0, ptr1, len1);
    if (ret[2]) {
        throw takeFromExternrefTable0(ret[1]);
    }
    return takeFromExternrefTable0(ret[0]);
}
function __wbg_get_imports() {
    const import0 = {
        __proto__: null,
        __wbg___wbindgen_boolean_get_4f1baf9a00be3c74: function(arg0) {
            const v = arg0;
            const ret = typeof(v) === 'boolean' ? v : undefined;
            return isLikeNone(ret) ? 0xFFFFFF : ret ? 1 : 0;
        },
        __wbg___wbindgen_is_function_741ff2bb612836f5: function(arg0) {
            const ret = typeof(arg0) === 'function';
            return ret;
        },
        __wbg___wbindgen_is_null_c22311b1cc228e3a: function(arg0) {
            const ret = arg0 === null;
            return ret;
        },
        __wbg___wbindgen_is_object_8b968c3ab8e96595: function(arg0) {
            const val = arg0;
            const ret = typeof(val) === 'object' && val !== null;
            return ret;
        },
        __wbg___wbindgen_is_string_fc456fee5d3317de: function(arg0) {
            const ret = typeof(arg0) === 'string';
            return ret;
        },
        __wbg___wbindgen_is_undefined_be5b34249ff1fc15: function(arg0) {
            const ret = arg0 === undefined;
            return ret;
        },
        __wbg___wbindgen_number_get_934b640d0889af78: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'number' ? obj : undefined;
            getDataViewMemory0().setFloat64((arg0 >>> 0) + 8 * 1, isLikeNone(ret) ? 0 : ret, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, !isLikeNone(ret), true);
        },
        __wbg___wbindgen_string_get_7ce8eee7fd327545: function(arg0, arg1) {
            const obj = arg1;
            const ret = typeof(obj) === 'string' ? obj : undefined;
            var ptr1 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
            var len1 = WASM_VECTOR_LEN;
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 1, len1, true);
            getDataViewMemory0().setInt32((arg0 >>> 0) + 4 * 0, ptr1, true);
        },
        __wbg___wbindgen_throw_4c88d8bf264fd984: function(arg0, arg1) {
            throw new Error(getStringFromWasm0(arg0, arg1));
        },
        __wbg__wbg_cb_unref_09736879a3f67559: function(arg0) {
            arg0._wbg_cb_unref();
        },
        __wbg_aborted_4ddb6c7588191dbe: function(arg0) {
            const ret = arg0.aborted;
            return ret;
        },
        __wbg_account_new: function(arg0) {
            const ret = Account.__wrap(arg0);
            return ret;
        },
        __wbg_addEventListener_2f25e5e17cf3eceb: function(arg0, arg1, arg2, arg3) {
            arg0.addEventListener(getStringFromWasm0(arg1, arg2), arg3);
        },
        __wbg_apply_bfe2b07b146427e2: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.apply(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_call_a410eb4b59ed5965: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = arg0.call(arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_construct_8670bb4c2b062969: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.construct(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_crypto_23f565a907d30078: function(arg0) {
            const ret = arg0.crypto;
            return ret;
        },
        __wbg_entries_7bb1459bd9b5c2b9: function(arg0) {
            const ret = Object.entries(arg0);
            return ret;
        },
        __wbg_eventstream_new: function(arg0) {
            const ret = EventStream.__wrap(arg0);
            return ret;
        },
        __wbg_getRandomValues_d2908e0b99612b91: function() { return handleError(function (arg0, arg1) {
            arg0.getRandomValues(arg1);
        }, arguments); },
        __wbg_get_2080c49015e35254: function() { return handleError(function (arg0, arg1) {
            const ret = Reflect.get(arg0, arg1);
            return ret;
        }, arguments); },
        __wbg_get_d7176cfb76d71114: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_get_unchecked_e6325ad374eff861: function(arg0, arg1) {
            const ret = arg0[arg1 >>> 0];
            return ret;
        },
        __wbg_instanceof_Error_74e3cca0c4a69161: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Error;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_instanceof_Uint8Array_d7aeb0dcb3108fea: function(arg0) {
            let result;
            try {
                result = arg0 instanceof Uint8Array;
            } catch (_) {
                result = false;
            }
            const ret = result;
            return ret;
        },
        __wbg_isArray_bcf1376d0d732d08: function(arg0) {
            const ret = Array.isArray(arg0);
            return ret;
        },
        __wbg_kdbx_new: function(arg0) {
            const ret = Kdbx.__wrap(arg0);
            return ret;
        },
        __wbg_length_186163212ffe79c3: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_length_b03a0fabb109b1e9: function(arg0) {
            const ret = arg0.length;
            return ret;
        },
        __wbg_message_43d8c8f1d543a349: function(arg0) {
            const ret = arg0.message;
            return ret;
        },
        __wbg_msCrypto_d5f06fad6bf1409b: function(arg0) {
            const ret = arg0.msCrypto;
            return ret;
        },
        __wbg_new_37eb45aaf5eeb820: function() {
            const ret = new Array();
            return ret;
        },
        __wbg_new_787b9fb330d55d78: function(arg0, arg1) {
            const ret = new Error(getStringFromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_cd4348290afae586: function() {
            const ret = new Object();
            return ret;
        },
        __wbg_new_from_slice_b8daf545a41c6aa0: function(arg0, arg1) {
            const ret = new Uint8Array(getArrayU8FromWasm0(arg0, arg1));
            return ret;
        },
        __wbg_new_typed_e09da9dae6ee5935: function(arg0, arg1) {
            try {
                var state0 = {a: arg0, b: arg1};
                var cb0 = (arg0, arg1) => {
                    const a = state0.a;
                    state0.a = 0;
                    try {
                        return wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined_______true_(a, state0.b, arg0, arg1);
                    } finally {
                        state0.a = a;
                    }
                };
                const ret = new Promise(cb0);
                return ret;
            } finally {
                state0.a = 0;
            }
        },
        __wbg_new_with_length_01b143a7e5dd5a3e: function(arg0) {
            const ret = new Uint8Array(arg0 >>> 0);
            return ret;
        },
        __wbg_node_86166ff8ce1f2002: function(arg0) {
            const ret = arg0.node;
            return ret;
        },
        __wbg_now_463ac581d2fc7ea3: function() {
            const ret = Date.now();
            return ret;
        },
        __wbg_of_4cc373bef1f715a4: function(arg0, arg1, arg2) {
            const ret = Array.of(arg0, arg1, arg2);
            return ret;
        },
        __wbg_of_e7ea0fcd535c1444: function(arg0, arg1) {
            const ret = Array.of(arg0, arg1);
            return ret;
        },
        __wbg_parse_c3f72b5a24f83c01: function() { return handleError(function (arg0, arg1) {
            const ret = JSON.parse(getStringFromWasm0(arg0, arg1));
            return ret;
        }, arguments); },
        __wbg_process_91f425a63f58e399: function(arg0) {
            const ret = arg0.process;
            return ret;
        },
        __wbg_prototypesetcall_13162965d1fe7aa3: function(arg0, arg1, arg2) {
            Uint8Array.prototype.set.call(getArrayU8FromWasm0(arg0, arg1), arg2);
        },
        __wbg_push_c9f4893fc209f768: function(arg0, arg1) {
            const ret = arg0.push(arg1);
            return ret;
        },
        __wbg_queueMicrotask_1e8503a8a690f0a3: function(arg0) {
            const ret = arg0.queueMicrotask;
            return ret;
        },
        __wbg_queueMicrotask_4a1a4d8dd332373b: function(arg0) {
            queueMicrotask(arg0);
        },
        __wbg_randomFillSync_34b023059e3363de: function() { return handleError(function (arg0, arg1) {
            arg0.randomFillSync(arg1);
        }, arguments); },
        __wbg_removeEventListener_0bca49596b04af6d: function(arg0, arg1, arg2, arg3) {
            arg0.removeEventListener(getStringFromWasm0(arg1, arg2), arg3);
        },
        __wbg_require_9a7d8cc2e1d275c0: function() { return handleError(function () {
            const ret = module.require;
            return ret;
        }, arguments); },
        __wbg_resolve_dbf78ab4942478b0: function(arg0) {
            const ret = Promise.resolve(arg0);
            return ret;
        },
        __wbg_selfhosted_new: function(arg0) {
            const ret = SelfHosted.__wrap(arg0);
            return ret;
        },
        __wbg_serviceaccount_new: function(arg0) {
            const ret = ServiceAccount.__wrap(arg0);
            return ret;
        },
        __wbg_set_2793479888329cb6: function() { return handleError(function (arg0, arg1, arg2) {
            const ret = Reflect.set(arg0, arg1, arg2);
            return ret;
        }, arguments); },
        __wbg_set_name_822e3903f3184979: function(arg0, arg1, arg2) {
            arg0.name = getStringFromWasm0(arg1, arg2);
        },
        __wbg_static_accessor_GLOBAL_THIS_003ee833af9699fc: function() {
            const ret = typeof globalThis === 'undefined' ? undefined : globalThis;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_GLOBAL_e4293fb22cbe77da: function() {
            const ret = typeof global === 'undefined' ? undefined : global;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_SELF_53bb20457401453d: function() {
            const ret = typeof self === 'undefined' ? undefined : self;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_static_accessor_WINDOW_b5e0810bfecb7feb: function() {
            const ret = typeof window === 'undefined' ? undefined : window;
            return isLikeNone(ret) ? 0 : addToExternrefTable0(ret);
        },
        __wbg_stringify_0a0fbf2ef722380a: function() { return handleError(function (arg0) {
            const ret = JSON.stringify(arg0);
            return ret;
        }, arguments); },
        __wbg_subarray_58f388a9247ac0bb: function(arg0, arg1, arg2) {
            const ret = arg0.subarray(arg1 >>> 0, arg2 >>> 0);
            return ret;
        },
        __wbg_then_656f253a5dd7d8ea: function(arg0, arg1, arg2) {
            const ret = arg0.then(arg1, arg2);
            return ret;
        },
        __wbg_then_e3f7f2d365708be8: function(arg0, arg1) {
            const ret = arg0.then(arg1);
            return ret;
        },
        __wbg_totpchallenge_new: function(arg0) {
            const ret = TotpChallenge.__wrap(arg0);
            return ret;
        },
        __wbg_vault_new: function(arg0) {
            const ret = Vault.__wrap(arg0);
            return ret;
        },
        __wbg_versions_6e128a981b0df859: function(arg0) {
            const ret = arg0.versions;
            return ret;
        },
        __wbindgen_generic_0000000000000001: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [Externref], shim_idx: 1037, ret: Result(Unit), inner_ret: Some(Result(Unit)) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___wasm_bindgen_90e3c6fa821d6ed___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_90e3c6fa821d6ed___JsError___true_);
            return ret;
        },
        __wbindgen_generic_0000000000000002: function(arg0, arg1) {
            // Cast intrinsic for `Closure(Closure { owned: true, function: Function { arguments: [], shim_idx: 7, ret: Unit, inner_ret: Some(Unit) }, mutable: true }) -> Externref`.
            const ret = makeMutClosure(arg0, arg1, wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke_______true_);
            return ret;
        },
        __wbindgen_generic_0000000000000003: function(arg0) {
            // Cast intrinsic for `F64 -> Externref`.
            const ret = arg0;
            return ret;
        },
        __wbindgen_generic_0000000000000004: function(arg0, arg1) {
            // Cast intrinsic for `Ref(Slice(U8)) -> NamedExternref("Uint8Array")`.
            const ret = getArrayU8FromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_generic_0000000000000005: function(arg0, arg1) {
            // Cast intrinsic for `Ref(String) -> Externref`.
            const ret = getStringFromWasm0(arg0, arg1);
            return ret;
        },
        __wbindgen_init_externref_table: function() {
            const table = wasm.__wbindgen_externrefs;
            table.set(0, undefined);
            table.set(1024, undefined);
            table.set(1025, null);
            table.set(1026, true);
            table.set(1027, false);
        },
    };
    return {
        __proto__: null,
        "./ov_wasm_bg.js": import0,
    };
}

function wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke_______true_(arg0, arg1) {
    wasm.wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke_______true_(arg0, arg1);
}

function wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___wasm_bindgen_90e3c6fa821d6ed___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_90e3c6fa821d6ed___JsError___true_(arg0, arg1, arg2) {
    const ret = wasm.wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___wasm_bindgen_90e3c6fa821d6ed___JsValue__core_ed718c3d60ebd546___result__Result_____wasm_bindgen_90e3c6fa821d6ed___JsError___true_(arg0, arg1, arg2);
    if (ret[1]) {
        throw takeFromExternrefTable0(ret[0]);
    }
}

function wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined_______true_(arg0, arg1, arg2, arg3) {
    wasm.wasm_bindgen_90e3c6fa821d6ed___convert__closures_____invoke___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined___js_sys_55b20e57578d6297___Function_fn_wasm_bindgen_90e3c6fa821d6ed___JsValue_____wasm_bindgen_90e3c6fa821d6ed___sys__Undefined_______true_(arg0, arg1, arg2, arg3);
}

const AccountFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_account_free(ptr, 1));
const EventStreamFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_eventstream_free(ptr, 1));
const KdbxFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_kdbx_free(ptr, 1));
const OvClientFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_ovclient_free(ptr, 1));
const SelfHostedFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_selfhosted_free(ptr, 1));
const ServiceAccountFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_serviceaccount_free(ptr, 1));
const ShareOpenFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_shareopen_free(ptr, 1));
const TotpChallengeFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_totpchallenge_free(ptr, 1));
const VaultFinalization = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(ptr => wasm.__wbg_vault_free(ptr, 1));

function addToExternrefTable0(obj) {
    const idx = wasm.__externref_table_alloc();
    wasm.__wbindgen_externrefs.set(idx, obj);
    return idx;
}

function _assertClass(instance, klass) {
    if (!(instance instanceof klass)) {
        throw new Error(`expected instance of ${klass.name}`);
    }
}

const CLOSURE_DTORS = (typeof FinalizationRegistry === 'undefined')
    ? { register: () => {}, unregister: () => {} }
    : new FinalizationRegistry(state => wasm.__wbindgen_destroy_closure(state.a, state.b));

function getArrayJsValueFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    const mem = getDataViewMemory0();
    const result = [];
    for (let i = ptr; i < ptr + 4 * len; i += 4) {
        result.push(wasm.__wbindgen_externrefs.get(mem.getUint32(i, true)));
    }
    wasm.__externref_drop_slice(ptr, len);
    return result;
}

function getArrayU8FromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return getUint8ArrayMemory0().subarray(ptr / 1, ptr / 1 + len);
}

let cachedDataViewMemory0 = null;
function getDataViewMemory0() {
    if (cachedDataViewMemory0 === null || cachedDataViewMemory0.buffer.detached === true || (cachedDataViewMemory0.buffer.detached === undefined && cachedDataViewMemory0.buffer !== wasm.memory.buffer)) {
        cachedDataViewMemory0 = new DataView(wasm.memory.buffer);
    }
    return cachedDataViewMemory0;
}

function getStringFromWasm0(ptr, len) {
    ptr = ptr >>> 0;
    return decodeText(getUint8ArrayMemory0().subarray(ptr, ptr + len));
}

let cachedUint8ArrayMemory0 = null;
function getUint8ArrayMemory0() {
    if (cachedUint8ArrayMemory0 === null || cachedUint8ArrayMemory0.byteLength === 0) {
        cachedUint8ArrayMemory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachedUint8ArrayMemory0;
}

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        const idx = addToExternrefTable0(e);
        wasm.__wbindgen_exn_store(idx);
    }
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

function makeMutClosure(arg0, arg1, f) {
    const state = { a: arg0, b: arg1, cnt: 1 };
    const real = (...args) => {

        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            state.a = a;
            real._wbg_cb_unref();
        }
    };
    real._wbg_cb_unref = () => {
        if (--state.cnt === 0) {
            wasm.__wbindgen_destroy_closure(state.a, state.b);
            state.a = 0;
            CLOSURE_DTORS.unregister(state);
        }
    };
    CLOSURE_DTORS.register(real, state, state);
    return real;
}

function passArray8ToWasm0(arg, malloc) {
    const ptr = malloc(arg.length * 1, 1) >>> 0;
    getUint8ArrayMemory0().set(arg, ptr / 1);
    WASM_VECTOR_LEN = arg.length;
    return ptr;
}

function passArrayJsValueToWasm0(array, malloc) {
    const ptr = malloc(array.length * 4, 4) >>> 0;
    for (let i = 0; i < array.length; i++) {
        const add = addToExternrefTable0(array[i]);
        getDataViewMemory0().setUint32(ptr + 4 * i, add, true);
    }
    WASM_VECTOR_LEN = array.length;
    return ptr;
}

function passStringToWasm0(arg, malloc, realloc) {
    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length, 1) >>> 0;
        getUint8ArrayMemory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len, 1) >>> 0;

    const mem = getUint8ArrayMemory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }
    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3, 1) >>> 0;
        const view = getUint8ArrayMemory0().subarray(ptr + offset, ptr + len);
        const ret = cachedTextEncoder.encodeInto(arg, view);

        offset += ret.written;
        ptr = realloc(ptr, len, offset, 1) >>> 0;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function takeFromExternrefTable0(idx) {
    const value = wasm.__wbindgen_externrefs.get(idx);
    wasm.__externref_table_dealloc(idx);
    return value;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true });
cachedTextDecoder.decode();
const MAX_SAFARI_DECODE_BYTES = 2146435072;
let numBytesDecoded = 0;
function decodeText(bytes) {
    numBytesDecoded += bytes.length;
    if (numBytesDecoded >= MAX_SAFARI_DECODE_BYTES) {
        cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true });
        cachedTextDecoder.decode();
        numBytesDecoded = bytes.length;
    }
    return cachedTextDecoder.decode(bytes);
}

const cachedTextEncoder = new TextEncoder();

if (!('encodeInto' in cachedTextEncoder)) {
    cachedTextEncoder.encodeInto = function (arg, view) {
        const buf = cachedTextEncoder.encode(arg);
        view.set(buf);
        return {
            read: arg.length,
            written: buf.length
        };
    };
}

let WASM_VECTOR_LEN = 0;

let wasmModule, wasmInstance, wasm;
function __wbg_finalize_init(instance, module) {
    wasmInstance = instance;
    wasm = instance.exports;
    wasmModule = module;
    cachedDataViewMemory0 = null;
    cachedUint8ArrayMemory0 = null;
    wasm.__wbindgen_start();
    return wasm;
}

async function __wbg_load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (!module.ok) {
            throw new Error(`failed to fetch Wasm: ${module.status} ${module.statusText} fetching '${module.url}'`);
        }

        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);
            } catch (e) {
                const validResponse = expectedResponseType(module.type);

                if (validResponse && module.headers.get('Content-Type') !== 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve Wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else { throw e; }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);
    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };
        } else {
            return instance;
        }
    }

    function expectedResponseType(type) {
        switch (type) {
            case 'basic': case 'cors': case 'default': return true;
        }
        return false;
    }
}

function initSync(module) {
    if (wasm !== undefined) return wasm;


    if (module !== undefined) {
        if (Object.getPrototypeOf(module) === Object.prototype) {
            ({module} = module)
        } else {
            console.warn('using deprecated parameters for `initSync()`; pass a single object instead')
        }
    }

    const imports = __wbg_get_imports();
    if (!(module instanceof WebAssembly.Module)) {
        module = new WebAssembly.Module(module);
    }
    const instance = new WebAssembly.Instance(module, imports);
    return __wbg_finalize_init(instance, module);
}

let __wbg_init_promise;
async function __wbg_init(module_or_path) {
    if (wasm !== undefined) return wasm;
    if (__wbg_init_promise === undefined) {
        __wbg_init_promise = __wbg_init_once(module_or_path);
        __wbg_init_promise.catch(() => { __wbg_init_promise = undefined; });
    }
    return __wbg_init_promise;
}

async function __wbg_init_once(module_or_path) {

    if (module_or_path !== undefined) {
        if (Object.getPrototypeOf(module_or_path) === Object.prototype) {
            ({module_or_path} = module_or_path)
        } else {
            console.warn('using deprecated parameters for the initialization function; pass a single object instead')
        }
    }

    if (module_or_path === undefined) {
        module_or_path = new URL('ov_wasm_bg.wasm', import.meta.url);
    }
    const imports = __wbg_get_imports();

    if (typeof module_or_path === 'string' || (typeof Request === 'function' && module_or_path instanceof Request) || (typeof URL === 'function' && module_or_path instanceof URL)) {
        module_or_path = fetch(module_or_path);
    }

    const { instance, module } = await __wbg_load(await module_or_path, imports);

    return __wbg_finalize_init(instance, module);
}

export { initSync, __wbg_init as default };
